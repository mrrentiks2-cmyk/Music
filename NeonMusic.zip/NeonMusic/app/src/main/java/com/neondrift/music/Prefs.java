package com.neondrift.music;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** Настройки, избранное и позиции длинных треков. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------------ внешний вид и медиатека
    int accent() { return sp.getInt("accent", 0); }
    int minDuration() { return sp.getInt("minDuration", 30); }           // секунды; короче — не показываем
    int trackSort() { return sp.getInt("trackSort", 0); }                // 0 название, 1 исполнитель, 2 альбом, 3 дата, 4 длина
    int albumSort() { return sp.getInt("albumSort", 0); }                // 0 название, 1 исполнитель, 2 год
    int tab() { return sp.getInt("tab", 0); }

    // ------------------------------------------------------------------ воспроизведение
    int crossfade() { return sp.getInt("crossfade", 0); }                // секунды, 0 — выкл
    boolean resumeOnPlug() { return sp.getBoolean("resumeOnPlug", false); }
    boolean rememberLong() { return sp.getBoolean("rememberLong", true); } // аудиокниги и подкасты
    int replayGain() { return sp.getInt("replayGain", 0); }              // 0 выкл, 1 трек, 2 альбом
    boolean keepPitch() { return sp.getBoolean("keepPitch", true); }
    boolean visualizer() { return sp.getBoolean("visualizer", false); }
    float speed() { return sp.getFloat("speed", 1f); }

    // ------------------------------------------------------------------ эффекты
    boolean eqOn() { return sp.getBoolean("eqOn", false); }
    int eqPreset() { return sp.getInt("eqPreset", 0); }                  // -2 — своя настройка
    String eqBands() { return sp.getString("eqBands", ""); }
    int bass() { return sp.getInt("bass", 0); }                          // 0..1000
    int virtualizer() { return sp.getInt("virt", 0); }                   // 0..1000
    int loudness() { return sp.getInt("loud", 0); }                      // мБ, 0..1500

    void put(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void put(String k, float v) { sp.edit().putFloat(k, v).apply(); }
    void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    void put(String k, String v) { sp.edit().putString(k, v).apply(); }

    // ------------------------------------------------------------------ избранное и скрытые папки
    Set<String> favorites() { return new HashSet<>(sp.getStringSet("favorites", new HashSet<>())); }

    boolean isFavorite(String key) { return sp.getStringSet("favorites", new HashSet<>()).contains(key); }

    boolean toggleFavorite(String key) {
        Set<String> f = favorites();
        boolean now;
        if (f.contains(key)) {
            f.remove(key);
            now = false;
        } else {
            f.add(key);
            now = true;
        }
        sp.edit().putStringSet("favorites", f).apply();
        return now;
    }

    Set<String> hiddenFolders() { return new HashSet<>(sp.getStringSet("hidden", new HashSet<>())); }

    void setHidden(String folder, boolean hidden) {
        Set<String> s = hiddenFolders();
        if (hidden) s.add(folder);
        else s.remove(folder);
        sp.edit().putStringSet("hidden", s).apply();
    }

    // ------------------------------------------------------------------ позиции длинных треков
    long longPosition(String key) { return sp.getLong("lp:" + key, 0L); }

    void saveLongPosition(String key, long pos, long dur) {
        SharedPreferences.Editor e = sp.edit();
        if (pos < 10_000 || pos > dur - 15_000) e.remove("lp:" + key);
        else e.putLong("lp:" + key, pos);
        e.apply();
    }
}
