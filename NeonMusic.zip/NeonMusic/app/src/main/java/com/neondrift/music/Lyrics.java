package com.neondrift.music;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Разбор текстов песен из файлов пользователя: LRC с метками времени или обычный текст. */
final class Lyrics {
    static final class Line {
        final long time; // мс; -1 — без метки
        final String text;

        Line(long time, String text) {
            this.time = time;
            this.text = text;
        }
    }

    final List<Line> lines = new ArrayList<>();
    boolean synced;

    private static final Pattern STAMP = Pattern.compile("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?]");
    private static final Pattern OFFSET = Pattern.compile("\\[offset:\\s*([+-]?\\d+)\\s*]", Pattern.CASE_INSENSITIVE);
    private static final Pattern TAG = Pattern.compile("^\\[[a-zA-Z]+:.*]$");

    static Lyrics parse(String text) {
        Lyrics l = new Lyrics();
        if (text == null) return l;
        long offset = 0;
        Matcher om = OFFSET.matcher(text);
        if (om.find()) {
            try {
                offset = Long.parseLong(om.group(1));
            } catch (NumberFormatException ignored) {
            }
        }
        ArrayList<Line> timed = new ArrayList<>();
        ArrayList<Line> plain = new ArrayList<>();
        for (String raw : text.split("\\r?\\n")) {
            String s = raw.trim();
            if (s.isEmpty()) continue;
            Matcher m = STAMP.matcher(s);
            ArrayList<Long> stamps = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                long min = Long.parseLong(m.group(1)), sec = Long.parseLong(m.group(2));
                long frac = 0;
                String f = m.group(3);
                if (f != null) {
                    frac = Long.parseLong(f);
                    if (f.length() == 1) frac *= 100;
                    else if (f.length() == 2) frac *= 10;
                }
                stamps.add(min * 60_000 + sec * 1000 + frac);
                end = m.end();
            }
            if (!stamps.isEmpty()) {
                String body = s.substring(end).trim();
                for (long t : stamps) timed.add(new Line(Math.max(0, t - offset), body));
            } else if (!TAG.matcher(s).matches()) {
                plain.add(new Line(-1, s));
            }
        }
        if (!timed.isEmpty()) {
            Collections.sort(timed, (a, b) -> Long.compare(a.time, b.time));
            l.lines.addAll(timed);
            l.synced = true;
        } else {
            l.lines.addAll(plain);
        }
        return l;
    }

    /** Индекс строки, которая звучит в момент time; -1 — ещё до первой. */
    int lineAt(long time) {
        if (!synced) return -1;
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).time <= time) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return ans;
    }

    boolean isEmpty() {
        return lines.isEmpty();
    }
}
