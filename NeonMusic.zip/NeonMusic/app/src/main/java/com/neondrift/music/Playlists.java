package com.neondrift.music;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Плейлисты пользователя — хранятся в файле приложения. */
final class Playlists {
    static final class Playlist {
        long id;
        String name;
        final ArrayList<String> keys = new ArrayList<>();
    }

    private static Playlists instance;

    static synchronized Playlists get(Context c) {
        if (instance == null) instance = new Playlists(c.getApplicationContext());
        return instance;
    }

    private final File file;
    private final ArrayList<Playlist> lists = new ArrayList<>();

    private Playlists(Context c) {
        file = new File(c.getFilesDir(), "playlists.json");
        load();
    }

    synchronized List<Playlist> all() {
        return new ArrayList<>(lists);
    }

    synchronized Playlist byId(long id) {
        for (Playlist p : lists) if (p.id == id) return p;
        return null;
    }

    synchronized Playlist create(String name) {
        Playlist p = new Playlist();
        p.id = System.currentTimeMillis();
        p.name = name;
        lists.add(0, p);
        save();
        return p;
    }

    synchronized void rename(Playlist p, String name) {
        p.name = name;
        save();
    }

    synchronized void delete(Playlist p) {
        lists.remove(p);
        save();
    }

    synchronized int add(Playlist p, List<Track> tracks) {
        int n = 0;
        for (Track t : tracks) {
            if (!p.keys.contains(t.key())) {
                p.keys.add(t.key());
                n++;
            }
        }
        save();
        return n;
    }

    synchronized void remove(Playlist p, int index) {
        if (index >= 0 && index < p.keys.size()) p.keys.remove(index);
        save();
    }

    synchronized void move(Playlist p, int from, int to) {
        if (from < 0 || to < 0 || from >= p.keys.size() || to >= p.keys.size()) return;
        String k = p.keys.remove(from);
        p.keys.add(to, k);
        save();
    }

    /** Треки плейлиста, которые есть в медиатеке. */
    static List<Track> tracks(Playlist p) {
        ArrayList<Track> out = new ArrayList<>();
        Library lib = Library.get();
        for (String k : p.keys) {
            Track t = lib.find(k);
            if (t != null) out.add(t);
        }
        return out;
    }

    private void load() {
        lists.clear();
        if (!file.exists()) return;
        try (InputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[(int) file.length()];
            int off = 0, n;
            while (off < buf.length && (n = in.read(buf, off, buf.length - off)) > 0) off += n;
            JSONArray arr = new JSONArray(new String(buf, 0, off, StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Playlist p = new Playlist();
                p.id = o.optLong("id", System.currentTimeMillis() + i);
                p.name = o.optString("name", "Плейлист");
                JSONArray k = o.optJSONArray("keys");
                if (k != null) for (int j = 0; j < k.length(); j++) p.keys.add(k.getString(j));
                lists.add(p);
            }
        } catch (Exception ignored) {
        }
    }

    private void save() {
        try {
            JSONArray arr = new JSONArray();
            for (Playlist p : lists) {
                JSONObject o = new JSONObject();
                o.put("id", p.id);
                o.put("name", p.name);
                JSONArray k = new JSONArray();
                for (String s : p.keys) k.put(s);
                o.put("keys", k);
                arr.put(o);
            }
            File tmp = new File(file.getPath() + ".tmp");
            try (OutputStream os = new FileOutputStream(tmp)) {
                os.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            }
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(file);
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ M3U

    static String toM3u(List<Track> tracks) {
        StringBuilder sb = new StringBuilder("#EXTM3U\n");
        for (Track t : tracks) {
            sb.append("#EXTINF:").append(t.duration / 1000).append(',')
                    .append(t.artistName()).append(" - ").append(t.title).append('\n');
            sb.append(t.path != null ? t.path : String.valueOf(t.uri)).append('\n');
        }
        return sb.toString();
    }

    /** Сопоставить строки M3U с медиатекой: по полному пути, иначе по имени файла. */
    static List<Track> fromM3u(String text) {
        ArrayList<Track> out = new ArrayList<>();
        Library lib = Library.get();
        List<Track> all = lib.tracks();
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            line = line.replace('\\', '/');
            Track t = lib.find(line);
            if (t == null) {
                String name = line.substring(line.lastIndexOf('/') + 1);
                for (Track c : all) {
                    if (c.path != null && c.path.endsWith("/" + name)) {
                        t = c;
                        break;
                    }
                }
            }
            if (t != null && !out.contains(t)) out.add(t);
        }
        return out;
    }
}
