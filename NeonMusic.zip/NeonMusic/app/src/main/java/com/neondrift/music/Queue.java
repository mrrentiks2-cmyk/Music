package com.neondrift.music;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Очередь воспроизведения: перемешивание, повтор, «играть следующим». Без зависимостей от Android. */
final class Queue {
    static final int REPEAT_OFF = 0, REPEAT_ALL = 1, REPEAT_ONE = 2;

    final ArrayList<Track> items = new ArrayList<>();
    private final ArrayList<Track> original = new ArrayList<>();
    int index = -1;
    boolean shuffle;
    int repeat = REPEAT_OFF;
    private final Random rnd;

    Queue() { this(new Random()); }

    Queue(Random r) { rnd = r; }

    boolean isEmpty() { return items.isEmpty(); }

    int size() { return items.size(); }

    Track current() {
        return index >= 0 && index < items.size() ? items.get(index) : null;
    }

    void set(List<Track> list, int start, boolean shuffleOn) {
        items.clear();
        original.clear();
        original.addAll(list);
        items.addAll(list);
        index = list.isEmpty() ? -1 : Math.max(0, Math.min(start, list.size() - 1));
        shuffle = false;
        if (shuffleOn) setShuffle(true);
    }

    /** Следующий индекс; -1 — дальше нечего. user=true — нажата кнопка, повтор одного не держит. */
    int peekNext(boolean user) {
        if (items.isEmpty()) return -1;
        if (!user && repeat == REPEAT_ONE) return index;
        if (index + 1 < items.size()) return index + 1;
        if (repeat == REPEAT_ALL || (user && repeat == REPEAT_ONE)) return 0;
        return -1;
    }

    int peekPrev() {
        if (items.isEmpty()) return -1;
        if (index > 0) return index - 1;
        if (repeat != REPEAT_OFF) return items.size() - 1;
        return 0;
    }

    void jump(int i) {
        if (i >= 0 && i < items.size()) index = i;
    }

    /** Включение перемешивания: текущий трек остаётся, остальные — в случайном порядке после него. */
    void setShuffle(boolean on) {
        if (on == shuffle) return;
        Track cur = current();
        shuffle = on;
        if (on) {
            ArrayList<Track> rest = new ArrayList<>(items);
            if (cur != null) rest.remove(index);
            Collections.shuffle(rest, rnd);
            items.clear();
            if (cur != null) items.add(cur);
            items.addAll(rest);
            index = cur != null ? 0 : -1;
        } else {
            // вернуть исходный порядок за O(n); один и тот же трек может стоять в очереди дважды
            java.util.IdentityHashMap<Track, Integer> left = new java.util.IdentityHashMap<>();
            for (Track t : items) left.merge(t, 1, Integer::sum);
            ArrayList<Track> back = new ArrayList<>(items.size());
            for (Track t : original) {
                Integer n = left.get(t);
                if (n != null && n > 0) {
                    back.add(t);
                    left.put(t, n - 1);
                }
            }
            for (Track t : items) {
                Integer n = left.get(t);
                if (n != null && n > 0) {
                    back.add(t);
                    left.put(t, n - 1);
                }
            }
            items.clear();
            items.addAll(back);
            index = cur != null ? items.indexOf(cur) : -1;
        }
    }

    void cycleRepeat() {
        repeat = (repeat + 1) % 3;
    }

    void playNext(Track t) {
        if (items.isEmpty()) {
            set(Collections.singletonList(t), 0, false);
            return;
        }
        items.add(index + 1, t);
        int oi = original.indexOf(current());
        original.add(oi >= 0 ? oi + 1 : original.size(), t);
    }

    void add(Track t) {
        if (items.isEmpty()) {
            set(Collections.singletonList(t), 0, false);
            return;
        }
        items.add(t);
        original.add(t);
    }

    void addAll(List<Track> list) {
        for (Track t : list) add(t);
    }

    void remove(int i) {
        if (i < 0 || i >= items.size()) return;
        Track t = items.remove(i);
        original.remove(t);
        if (i < index) index--;
        else if (i == index && index >= items.size()) index = items.size() - 1;
        if (items.isEmpty()) index = -1;
    }

    void move(int from, int to) {
        if (from < 0 || from >= items.size() || to < 0 || to >= items.size() || from == to) return;
        Track t = items.remove(from);
        items.add(to, t);
        if (index == from) index = to;
        else if (from < index && to >= index) index--;
        else if (from > index && to <= index) index++;
    }

    /** Оставить только текущий трек. */
    void clearOthers() {
        Track cur = current();
        items.clear();
        original.clear();
        if (cur != null) {
            items.add(cur);
            original.add(cur);
            index = 0;
        } else {
            index = -1;
        }
    }

    List<Track> originalOrder() {
        return new ArrayList<>(original);
    }

    /** Восстановление после перезапуска. */
    void restore(List<Track> order, List<Track> orig, int idx, boolean shuffled, int rep) {
        items.clear();
        items.addAll(order);
        original.clear();
        original.addAll(orig.isEmpty() ? order : orig);
        index = order.isEmpty() ? -1 : Math.max(0, Math.min(idx, order.size() - 1));
        shuffle = shuffled;
        repeat = rep;
    }
}
