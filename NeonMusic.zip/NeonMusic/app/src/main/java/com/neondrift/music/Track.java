package com.neondrift.music;

import android.net.Uri;

/** Один трек или поток. */
final class Track {
    long id = -1;
    Uri uri;
    String path;
    String title = "";
    String artist;
    String album;
    String genre;
    String folder = "";
    long albumId = -1;
    long duration, size, added;
    int trackNo, year;

    /** Стабильный ключ: путь, если он есть, иначе адрес. */
    String key() {
        return path != null ? path : String.valueOf(uri);
    }

    String artistName() {
        return artist == null || artist.isEmpty() || artist.equals("<unknown>") ? "Неизвестный исполнитель" : artist;
    }

    String albumName() {
        return album == null || album.isEmpty() || album.equals("<unknown>") ? "Без альбома" : album;
    }

    String genreName() {
        return genre == null || genre.trim().isEmpty() ? "Без жанра" : genre.trim();
    }

    boolean isStream() {
        String s = uri == null ? null : uri.getScheme();
        return s != null && !s.equals("content") && !s.equals("file");
    }

    /** Ключ альбома: альбомы с одинаковым названием у разных исполнителей не склеиваются. */
    String albumKey() {
        return albumId >= 0 ? "a" + albumId : albumName() + "|" + artistName();
    }

    static String cleanTitle(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        return dot > 0 && name.length() - dot <= 5 ? name.substring(0, dot) : name;
    }
}
