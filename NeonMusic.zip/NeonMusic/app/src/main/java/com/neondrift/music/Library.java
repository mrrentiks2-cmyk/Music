package com.neondrift.music;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Медиатека в памяти: треки и группировки по альбомам, исполнителям, жанрам и папкам. */
final class Library {
    private static final Library INSTANCE = new Library();

    static Library get() {
        return INSTANCE;
    }

    /** Группа треков: альбом, исполнитель, жанр или папка. */
    static final class Group {
        String id, name, sub;
        final ArrayList<Track> tracks = new ArrayList<>();
        long duration;
        int year;
        final ArrayList<String> albums = new ArrayList<>();

        Track cover() {
            return tracks.isEmpty() ? null : tracks.get(0);
        }
    }

    private volatile List<Track> tracks = new ArrayList<>();
    private final HashMap<String, Track> byKey = new HashMap<>();
    private List<Group> albums = new ArrayList<>(), artists = new ArrayList<>(), genres = new ArrayList<>(),
            folders = new ArrayList<>();
    private volatile boolean loaded;

    boolean isLoaded() {
        return loaded;
    }

    synchronized List<Track> tracks() {
        return tracks;
    }

    synchronized Track find(String key) {
        return byKey.get(key);
    }

    synchronized List<Group> albums() { return albums; }
    synchronized List<Group> artists() { return artists; }
    synchronized List<Group> genres() { return genres; }
    synchronized List<Group> folders() { return folders; }

    synchronized Group album(String key) {
        for (Group g : albums) if (g.id.equals(key)) return g;
        return null;
    }

    synchronized Group artist(String name) {
        for (Group g : artists) if (g.id.equals(name)) return g;
        return null;
    }

    // ------------------------------------------------------------------ сканирование

    static Uri collection() {
        return Build.VERSION.SDK_INT >= 29
                ? MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    }

    @SuppressWarnings("deprecation")
    static List<Track> scan(Context ctx, int minDurationSec, Set<String> hidden) {
        ArrayList<Track> out = new ArrayList<>();
        Uri col = collection();
        ArrayList<String> proj = new ArrayList<>();
        String[] base = {
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.TRACK, MediaStore.Audio.Media.YEAR, MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DISPLAY_NAME,
        };
        Collections.addAll(proj, base);
        if (Build.VERSION.SDK_INT >= 30) proj.add(MediaStore.Audio.Media.GENRE);
        String sel = MediaStore.Audio.Media.DURATION + " >= ?";
        String[] args = {String.valueOf(Math.max(0, minDurationSec) * 1000L)};
        ContentResolver cr = ctx.getContentResolver();
        try (Cursor c = cr.query(col, proj.toArray(new String[0]), sel, args, null)) {
            if (c == null) return out;
            int iId = c.getColumnIndex(MediaStore.Audio.Media._ID);
            int iTitle = c.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int iArtist = c.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int iAlbum = c.getColumnIndex(MediaStore.Audio.Media.ALBUM);
            int iAlbumId = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID);
            int iDur = c.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int iTrack = c.getColumnIndex(MediaStore.Audio.Media.TRACK);
            int iYear = c.getColumnIndex(MediaStore.Audio.Media.YEAR);
            int iSize = c.getColumnIndex(MediaStore.Audio.Media.SIZE);
            int iData = c.getColumnIndex(MediaStore.Audio.Media.DATA);
            int iAdded = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED);
            int iName = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME);
            int iGenre = Build.VERSION.SDK_INT >= 30 ? c.getColumnIndex(MediaStore.Audio.Media.GENRE) : -1;
            while (c.moveToNext()) {
                Track t = new Track();
                t.id = c.getLong(iId);
                t.uri = ContentUris.withAppendedId(col, t.id);
                t.path = str(c, iData);
                t.folder = t.path != null && new File(t.path).getParent() != null ? new File(t.path).getParent() : "";
                if (hidden != null && hidden.contains(t.folder)) continue;
                t.title = str(c, iTitle);
                if (t.title == null || t.title.isEmpty()) t.title = Track.cleanTitle(str(c, iName));
                t.artist = str(c, iArtist);
                t.album = str(c, iAlbum);
                t.albumId = num(c, iAlbumId);
                t.duration = num(c, iDur);
                int tn = (int) num(c, iTrack);
                t.trackNo = tn % 1000;
                t.year = (int) num(c, iYear);
                t.size = num(c, iSize);
                t.added = num(c, iAdded) * 1000L;
                t.genre = iGenre >= 0 ? str(c, iGenre) : null;
                out.add(t);
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static String str(Cursor c, int i) {
        try {
            return i >= 0 && !c.isNull(i) ? c.getString(i) : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static long num(Cursor c, int i) {
        try {
            return i >= 0 && !c.isNull(i) ? c.getLong(i) : 0L;
        } catch (Exception e) {
            return 0L;
        }
    }

    // ------------------------------------------------------------------ группировка

    synchronized void set(List<Track> list) {
        tracks = new ArrayList<>(list);
        byKey.clear();
        for (Track t : tracks) byKey.put(t.key(), t);
        albums = group(tracks, t -> t.albumKey(), Track::albumName);
        for (Group g : albums) {
            Collections.sort(g.tracks, (a, b) -> a.trackNo != b.trackNo ? Integer.compare(a.trackNo, b.trackNo)
                    : a.title.compareToIgnoreCase(b.title));
            g.sub = g.cover() != null ? g.cover().artistName() : "";
            for (Track t : g.tracks) g.year = Math.max(g.year, t.year);
        }
        artists = group(tracks, Track::artistName, Track::artistName);
        for (Group g : artists) {
            for (Track t : g.tracks) if (!g.albums.contains(t.albumKey())) g.albums.add(t.albumKey());
            sortByAlbumThenTrack(g.tracks);
        }
        genres = group(tracks, t -> t.genreName().toLowerCase(Locale.ROOT), Track::genreName);
        folders = group(tracks, t -> t.folder, t -> {
            String f = t.folder;
            int s = f.lastIndexOf('/');
            return s >= 0 && s < f.length() - 1 ? f.substring(s + 1) : (f.isEmpty() ? "Без папки" : f);
        });
        for (Group g : folders) {
            g.sub = g.id;
            Collections.sort(g.tracks, (a, b) -> a.title.compareToIgnoreCase(b.title));
        }
        Comparator<Group> byName = (a, b) -> a.name.compareToIgnoreCase(b.name);
        Collections.sort(artists, byName);
        Collections.sort(genres, byName);
        Collections.sort(folders, byName);
        Collections.sort(albums, byName);
        loaded = true;
    }

    private static void sortByAlbumThenTrack(List<Track> list) {
        Collections.sort(list, (a, b) -> {
            int c = a.albumName().compareToIgnoreCase(b.albumName());
            if (c != 0) return c;
            return Integer.compare(a.trackNo, b.trackNo);
        });
    }

    private interface Key { String of(Track t); }

    private static List<Group> group(List<Track> list, Key id, Key name) {
        LinkedHashMap<String, Group> map = new LinkedHashMap<>();
        for (Track t : list) {
            String k = id.of(t);
            Group g = map.get(k);
            if (g == null) {
                g = new Group();
                g.id = k;
                g.name = name.of(t);
                map.put(k, g);
            }
            g.tracks.add(t);
            g.duration += t.duration;
        }
        return new ArrayList<>(map.values());
    }

    static void sortTracks(List<Track> list, int mode) {
        Comparator<Track> c;
        switch (mode) {
            case 1: c = (a, b) -> {
                int r = a.artistName().compareToIgnoreCase(b.artistName());
                return r != 0 ? r : a.title.compareToIgnoreCase(b.title);
            }; break;
            case 2: c = (a, b) -> {
                int r = a.albumName().compareToIgnoreCase(b.albumName());
                return r != 0 ? r : Integer.compare(a.trackNo, b.trackNo);
            }; break;
            case 3: c = (a, b) -> Long.compare(b.added, a.added); break;
            case 4: c = (a, b) -> Long.compare(b.duration, a.duration); break;
            default: c = (a, b) -> a.title.compareToIgnoreCase(b.title); break;
        }
        Collections.sort(list, c);
    }

    static void sortAlbums(List<Group> list, int mode) {
        Comparator<Group> c;
        switch (mode) {
            case 1: c = (a, b) -> {
                int r = a.sub.compareToIgnoreCase(b.sub);
                return r != 0 ? r : a.name.compareToIgnoreCase(b.name);
            }; break;
            case 2: c = (a, b) -> Integer.compare(b.year, a.year); break;
            default: c = (a, b) -> a.name.compareToIgnoreCase(b.name); break;
        }
        Collections.sort(list, c);
    }

    /** Найти треки по совпадению в названии, исполнителе или альбоме. */
    synchronized List<Track> search(String q) {
        String s = q.toLowerCase(Locale.ROOT).trim();
        ArrayList<Track> out = new ArrayList<>();
        if (s.isEmpty()) return out;
        for (Track t : tracks) {
            if (t.title.toLowerCase(Locale.ROOT).contains(s)
                    || t.artistName().toLowerCase(Locale.ROOT).contains(s)
                    || t.albumName().toLowerCase(Locale.ROOT).contains(s)) out.add(t);
        }
        return out;
    }

    static Map<String, Integer> index(List<Track> list) {
        HashMap<String, Integer> m = new HashMap<>();
        for (int i = 0; i < list.size(); i++) m.put(list.get(i).key(), i);
        return m;
    }
}
