package com.neondrift.music;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Где лежат тексты песен: в папке приложения (загруженные) или рядом с аудиофайлом (.lrc). */
final class LyricsStore {
    private LyricsStore() {}

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "lyrics");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    static File fileFor(Context c, Track t) {
        return new File(dir(c), hash(t.key()) + ".lrc");
    }

    private static String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 12; i++) sb.append(String.format("%02x", d[i] & 255));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    /** Загруженный текст, иначе .lrc рядом с песней, иначе null. */
    static String load(Context c, Track t) {
        if (t == null) return null;
        File own = fileFor(c, t);
        if (own.exists()) return read(own);
        if (t.path != null) {
            int dot = t.path.lastIndexOf('.');
            String base = dot > 0 ? t.path.substring(0, dot) : t.path;
            for (String ext : new String[]{".lrc", ".LRC", ".txt"}) {
                File f = new File(base + ext);
                if (f.canRead()) {
                    String s = read(f);
                    if (s != null) return s;
                }
            }
        }
        return null;
    }

    static boolean save(Context c, Track t, String text) {
        try (FileOutputStream out = new FileOutputStream(fileFor(c, t))) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean hasOwn(Context c, Track t) {
        return t != null && fileFor(c, t).exists();
    }

    static void delete(Context c, Track t) {
        //noinspection ResultOfMethodCallIgnored
        fileFor(c, t).delete();
    }

    private static String read(File f) {
        if (f.length() > 512 * 1024) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            return decode(MainActivity.readAll(in));
        } catch (Exception e) {
            return null;
        }
    }

    /** UTF-8, а если файл в старой кодировке Windows — cp1251 (частый случай для русских .lrc). */
    static String decode(byte[] b) {
        int off = b.length >= 3 && (b[0] & 255) == 0xEF && (b[1] & 255) == 0xBB && (b[2] & 255) == 0xBF ? 3 : 0;
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(b, off, b.length - off)).toString();
        } catch (CharacterCodingException e) {
            try {
                return new String(b, Charset.forName("windows-1251"));
            } catch (Exception e2) {
                return new String(b, StandardCharsets.ISO_8859_1);
            }
        }
    }
}
