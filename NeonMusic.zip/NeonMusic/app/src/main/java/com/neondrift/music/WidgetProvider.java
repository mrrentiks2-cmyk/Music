package com.neondrift.music;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.widget.RemoteViews;

/** Виджет на рабочем столе: обложка, название и кнопки управления. */
public class WidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        SharedPreferences sp = c.getSharedPreferences("state", Context.MODE_PRIVATE);
        RemoteViews v = build(c, sp.getString("lastTitle", null), sp.getString("lastArtist", null), false, null);
        for (int id : ids) m.updateAppWidget(id, v);
    }

    static void update(Context c, Track t, boolean playing, Bitmap art) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, WidgetProvider.class));
            if (ids == null || ids.length == 0) return;
            RemoteViews v = build(c, t != null ? t.title : null, t != null ? t.artistName() : null, playing, art);
            m.updateAppWidget(ids, v);
        } catch (Exception ignored) {
        }
    }

    private static RemoteViews build(Context c, String title, String artist, boolean playing, Bitmap art) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_title, title != null ? title : "Neon Music Player");
        v.setTextViewText(R.id.w_artist, artist != null ? artist : "Нажмите, чтобы открыть медиатеку");
        if (art != null) v.setImageViewBitmap(R.id.w_art, art);
        else v.setImageViewResource(R.id.w_art, R.drawable.widget_art);
        v.setImageViewResource(R.id.w_play, playing ? R.drawable.ic_n_pause : R.drawable.ic_n_play);
        v.setOnClickPendingIntent(R.id.w_play, service(c, PlaybackService.ACTION_TOGGLE));
        v.setOnClickPendingIntent(R.id.w_next, service(c, PlaybackService.ACTION_NEXT));
        v.setOnClickPendingIntent(R.id.w_prev, service(c, PlaybackService.ACTION_PREV));
        Intent open = new Intent(c, title != null ? NowPlayingActivity.class : MainActivity.class);
        v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 3, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        return v;
    }

    private static PendingIntent service(Context c, String action) {
        Intent i = new Intent(c, PlaybackService.class).setAction(action);
        return PendingIntent.getForegroundService(c, 100 + action.hashCode() % 1000, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
