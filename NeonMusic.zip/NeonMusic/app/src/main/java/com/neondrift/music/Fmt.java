package com.neondrift.music;

import java.util.Locale;

/** Форматирование времени, размеров и чисел. */
final class Fmt {
    private Fmt() {}

    static String time(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        long h = s / 3600, m = (s / 60) % 60, sec = s % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(Locale.US, "%d:%02d", m, sec);
    }

    static String delta(long ms) {
        return (ms < 0 ? "−" : "+") + time(Math.abs(ms));
    }

    static String size(long bytes) {
        if (bytes <= 0) return "";
        if (bytes < 1024L * 1024L) return Math.max(1, bytes / 1024) + " КБ";
        double mb = bytes / (1024.0 * 1024.0);
        if (mb < 1024) return String.format(Locale.US, "%.0f МБ", mb).replace('.', ',');
        return String.format(Locale.US, "%.1f ГБ", mb / 1024.0).replace('.', ',');
    }

    static String resolution(int w, int h) {
        int s = Math.min(w, h);
        if (s <= 0) return "";
        if (s >= 2100) return "4K";
        if (s >= 1400) return "1440p";
        if (s >= 1000) return "1080p";
        if (s >= 700) return "720p";
        return s + "p";
    }

    static String rate(float r) {
        String s = String.format(Locale.US, "%.2f", r);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        if (s.endsWith(".")) s = s.substring(0, s.length() - 1);
        return s.replace('.', ',') + "×";
    }

    static String seconds(long ms) {
        return String.format(Locale.US, "%+.2f с", ms / 1000.0).replace('.', ',');
    }

    static int plural(long n, int one, int few, int many) {
        long a = Math.abs(n) % 100, b = a % 10;
        if (a > 10 && a < 20) return many;
        if (b > 1 && b < 5) return few;
        if (b == 1) return one;
        return many;
    }

    static String tracks(int n) {
        String[] w = {"трек", "трека", "треков"};
        return n + " " + w[plural(n, 0, 1, 2)];
    }

    static String albums(int n) {
        String[] w = {"альбом", "альбома", "альбомов"};
        return n + " " + w[plural(n, 0, 1, 2)];
    }

    static String plays(int n) {
        String[] w = {"прослушивание", "прослушивания", "прослушиваний"};
        return n + " " + w[plural(n, 0, 1, 2)];
    }

    /** «3 ч 12 мин», «47 мин» — общая длительность. */
    static String total(long ms) {
        long min = ms / 60_000;
        if (min < 60) return min + " мин";
        long h = min / 60, m = min % 60;
        return m == 0 ? h + " ч" : h + " ч " + m + " мин";
    }
}
