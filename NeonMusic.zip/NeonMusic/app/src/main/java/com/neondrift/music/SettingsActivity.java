package com.neondrift.music;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Настройки: оформление, переходы между треками, громкость, медиатека, статистика. */
public class SettingsActivity extends Activity {
    private static final int REQ_MIC = 21;
    private static final int[] MIN_DUR = {0, 10, 30, 60, 120};

    private Ui ui;
    private Prefs prefs;
    private LinearLayout box;
    private ScrollView scroll;
    private PlaybackService svc;
    private boolean bound;
    private final Handler h = new Handler(Looper.getMainLooper());

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName n, IBinder b) {
            svc = ((PlaybackService.LocalBinder) b).service();
            bound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName n) {
            svc = null;
        }
    };

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Theme.load(this);
        ui = new Ui(this);
        prefs = new Prefs(this);
        getWindow().setStatusBarColor(Theme.BG);
        getWindow().setNavigationBarColor(Theme.BG);
        LinearLayout page = ui.col();
        page.setBackgroundColor(Theme.BG);
        LinearLayout top = ui.row();
        top.setPadding(ui.dp(8), ui.dp(10), ui.dp(16), ui.dp(6));
        top.addView(ui.iconButton("back", Theme.TEXT, 44, 11, v -> finish()));
        top.addView(ui.text("Настройки", 20, Theme.TEXT, true), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(8), 0, 0, 0));
        page.addView(top);
        scroll = new ScrollView(this);
        box = ui.col();
        box.setPadding(ui.dp(20), 0, ui.dp(20), ui.dp(40));
        scroll.addView(box, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        page.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f));
        setContentView(page);
        bindService(new Intent(this, PlaybackService.class), conn, BIND_AUTO_CREATE);
        build();
    }

    @Override
    protected void onDestroy() {
        if (bound) unbindService(conn);
        super.onDestroy();
    }

    private void rebuild() {
        int y = scroll.getScrollY();
        build();
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    private void build() {
        box.removeAllViews();

        // ----------------------------------------------------------- оформление
        section("ОФОРМЛЕНИЕ");
        LinearLayout swatches = ui.row();
        for (int i = 0; i < Theme.ACCENTS.length; i++) {
            final int idx = i;
            LinearLayout sw = ui.col();
            sw.setGravity(Gravity.CENTER_HORIZONTAL);
            View dot = new View(this);
            boolean on = prefs.accent() == i;
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    new int[]{Theme.ACCENTS[i], Theme.ACCENTS2[i]});
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            if (on) g.setStroke(ui.dp(3), 0xFFFFFFFF);
            dot.setBackground(g);
            sw.addView(dot, Ui.lp(ui.dp(40), ui.dp(40)));
            sw.addView(ui.text(Theme.ACCENT_NAMES[i], 11, on ? Theme.TEXT : Theme.MUTED, on),
                    Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(6), 0, 0));
            sw.setOnClickListener(v -> {
                prefs.put("accent", idx);
                Theme.load(this);
                recreate();
            });
            swatches.addView(sw, Ui.lp(0, Ui.WRAP, 1f));
        }
        box.addView(swatches, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, 0));

        // ----------------------------------------------------------- воспроизведение
        section("ВОСПРОИЗВЕДЕНИЕ");
        int cf = prefs.crossfade();
        stepper("Плавный переход между треками", cf == 0 ? "Выкл" : cf + " с",
                () -> {
                    prefs.put("crossfade", Math.max(0, prefs.crossfade() - 1));
                    rebuild();
                }, () -> {
                    prefs.put("crossfade", Math.min(12, prefs.crossfade() + 1));
                    rebuild();
                });
        note("Конец трека затихает, следующий плавно нарастает — без пауз. Альбомы без пауз (live, классика) лучше слушать с выключенным переходом.");

        label("Выравнивание громкости (ReplayGain)");
        LinearLayout rg = chipRow();
        String[] rgNames = {"Выкл", "По трекам", "По альбомам"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            chip(rg, rgNames[i], prefs.replayGain() == i, () -> {
                prefs.put("replayGain", idx);
                if (svc != null) svc.rebuildEngine();
                rebuild();
            });
        }
        note("Использует теги ReplayGain в файлах, чтобы громкие и тихие треки звучали одинаково.");

        toggle("Сохранять высоту голоса при смене скорости", null, prefs.keepPitch(), on -> {
            prefs.put("keepPitch", on);
            if (svc != null) svc.rebuildEngine();
        });
        toggle("Продолжать при подключении наушников", "Если музыку остановило отключение наушников",
                prefs.resumeOnPlug(), on -> prefs.put("resumeOnPlug", on));
        toggle("Запоминать место в длинных треках", "Аудиокниги, подкасты и миксы длиннее 20 минут",
                prefs.rememberLong(), on -> prefs.put("rememberLong", on));
        toggle("Визуализатор спектра", "Нужно разрешение «Микрофон»: плеер анализирует только свой звук",
                prefs.visualizer(), on -> {
                    if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                        return;
                    }
                    prefs.put("visualizer", on);
                });

        // ----------------------------------------------------------- медиатека
        section("МЕДИАТЕКА");
        label("Не показывать файлы короче");
        LinearLayout md = chipRow();
        for (int s : MIN_DUR) {
            chip(md, s == 0 ? "Показывать все" : s < 60 ? s + " с" : s / 60 + " мин", prefs.minDuration() == s, () -> {
                prefs.put("minDuration", s);
                rescan();
                rebuild();
            });
        }
        note("Так звонки, уведомления и голосовые сообщения не попадают в медиатеку.");
        List<String> hidden = new ArrayList<>(prefs.hiddenFolders());
        label("Скрытые папки");
        if (hidden.isEmpty()) {
            note("Нет. Скрыть папку можно на вкладке «Папки» через меню ⋮.");
        } else {
            for (String f : hidden) {
                LinearLayout row = ui.row();
                row.setPadding(ui.dp(4), ui.dp(6), 0, ui.dp(6));
                TextView t = ui.text(f, 13, Theme.TEXT, false);
                t.setMaxLines(2);
                row.addView(t, Ui.lp(0, Ui.WRAP, 1f));
                row.addView(ui.chip("Показать", false, v -> {
                    prefs.setHidden(f, false);
                    rescan();
                    rebuild();
                }));
                box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
            }
        }
        box.addView(ui.button("Обновить медиатеку", false, v -> {
            rescan();
            Toast.makeText(this, "Сканирую…", Toast.LENGTH_SHORT).show();
        }), Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(12), 0, 0));

        // ----------------------------------------------------------- статистика
        section("СТАТИСТИКА");
        Stats st = new Stats(this);
        note("Всего " + Fmt.plays(st.totalPlays()) + ". Трек засчитывается после 30 секунд или половины длительности.");
        box.addView(ui.button("Очистить статистику", false, v -> new AlertDialog.Builder(this,
                android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Очистить статистику?")
                .setMessage("Подборки «Часто слушаю» и «Недавно игравшие» станут пустыми.")
                .setPositiveButton("Очистить", (d, w) -> {
                    st.clear();
                    rebuild();
                })
                .setNegativeButton("Отмена", null)
                .show()), Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(10), 0, 0));

        // ----------------------------------------------------------- о приложении
        section("О ПРИЛОЖЕНИИ");
        String ver = "";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        TextView name = ui.text("Neon Music Player " + ver, 16, Theme.TEXT, true);
        box.addView(name, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), 0, 0, 0));
        note("Форматы: MP3, FLAC, ALAC, AAC/M4A, OGG Vorbis, Opus, WAV, AIFF, APE, WavPack, DSD (DSF/DFF), "
                + "WMA, AC3, DTS, MPC, TTA, трекерная музыка (MOD/XM/IT/S3M) и звук из видеофайлов. "
                + "Потоки: HTTP, HTTPS, HLS, Icecast/SHOUTcast, плейлисты M3U и PLS.");
        note("Звуковой движок — libVLC от VideoLAN (лицензия LGPL 2.1). Эквалайзер на 10 полос, плавные переходы, "
                + "выравнивание громкости, таймер сна, тексты песен из ваших .lrc-файлов, виджет на рабочий стол.");
    }

    // ------------------------------------------------------------------ строительные блоки

    private void section(String s) {
        box.addView(ui.label(s), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(26), 0, ui.dp(10)));
    }

    private void label(String s) {
        box.addView(ui.text(s, 15, Theme.TEXT, false), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(14), 0, ui.dp(6)));
    }

    private void note(String s) {
        TextView t = ui.text(s, 12, Theme.MUTED, false);
        t.setLineSpacing(0, 1.3f);
        box.addView(t, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(4), ui.dp(6), 0, 0));
    }

    private LinearLayout chipRow() {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        hs.addView(row);
        box.addView(hs, Ui.lp(Ui.MATCH, Ui.WRAP));
        return row;
    }

    private void chip(LinearLayout row, String s, boolean on, Runnable r) {
        LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
        lp.rightMargin = ui.dp(8);
        row.addView(ui.chip(s, on, v -> r.run()), lp);
    }

    private void stepper(String title, String value, Runnable minus, Runnable plus) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(4), ui.dp(6), 0, ui.dp(6));
        row.addView(ui.text(title, 15, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        android.widget.ImageView m = ui.iconButton("minus", Theme.TEXT, 40, 11, v -> minus.run());
        m.setBackground(Ui.ripple(Ui.oval(Theme.SURFACE2), Ui.oval(0xFFFFFFFF)));
        row.addView(m);
        TextView v = ui.text(value, 15, Theme.ACCENT, true);
        v.setGravity(Gravity.CENTER);
        row.addView(v, Ui.lp(ui.dp(64), Ui.WRAP));
        android.widget.ImageView p = ui.iconButton("plus", Theme.TEXT, 40, 11, x -> plus.run());
        p.setBackground(Ui.ripple(Ui.oval(Theme.SURFACE2), Ui.oval(0xFFFFFFFF)));
        row.addView(p);
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
    }

    private void toggle(String title, String sub, boolean checked, Consumer<Boolean> changed) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(4), ui.dp(12), 0, ui.dp(12));
        LinearLayout tx = ui.col();
        TextView t = ui.text(title, 15, Theme.TEXT, false);
        tx.addView(t);
        if (sub != null) tx.addView(ui.text(sub, 12, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        row.addView(tx, Ui.lp(0, Ui.WRAP, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{Theme.ACCENT, 0xFFB8B0D0}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{Theme.alpha(Theme.ACCENT, 120), 0xFF3A3352}));
        sw.setOnCheckedChangeListener((b, on) -> changed.accept(on));
        row.addView(sw);
        row.setOnClickListener(v -> sw.toggle());
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
    }

    private void rescan() {
        final int min = prefs.minDuration();
        final java.util.Set<String> hidden = prefs.hiddenFolders();
        new Thread(() -> {
            List<Track> found = Library.scan(this, min, hidden);
            h.post(() -> {
                Library.get().set(found);
                ArtCache.get(this).clearMissing();
            });
        }, "rescan").start();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_MIC) {
            boolean ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            prefs.put("visualizer", ok);
            rebuild();
        }
    }
}
