package com.neondrift.music;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Сколько раз и когда слушали каждый трек. */
final class Stats {
    private final SharedPreferences plays, last;

    Stats(Context c) {
        plays = c.getSharedPreferences("plays", Context.MODE_PRIVATE);
        last = c.getSharedPreferences("lastPlayed", Context.MODE_PRIVATE);
    }

    void count(Track t) {
        String k = t.key();
        plays.edit().putInt(k, plays.getInt(k, 0) + 1).apply();
        last.edit().putLong(k, System.currentTimeMillis()).apply();
    }

    int plays(Track t) {
        return plays.getInt(t.key(), 0);
    }

    List<Track> mostPlayed(int limit) {
        ArrayList<Track> out = new ArrayList<>();
        Library lib = Library.get();
        for (Map.Entry<String, ?> e : plays.getAll().entrySet()) {
            Track t = lib.find(e.getKey());
            if (t != null) out.add(t);
        }
        Collections.sort(out, (a, b) -> Integer.compare(plays(b), plays(a)));
        return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
    }

    List<Track> recentlyPlayed(int limit) {
        ArrayList<Track> out = new ArrayList<>();
        Library lib = Library.get();
        for (Map.Entry<String, ?> e : last.getAll().entrySet()) {
            Track t = lib.find(e.getKey());
            if (t != null) out.add(t);
        }
        Collections.sort(out, (a, b) -> Long.compare(last.getLong(b.key(), 0), last.getLong(a.key(), 0)));
        return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
    }

    static List<Track> recentlyAdded(int limit) {
        ArrayList<Track> out = new ArrayList<>(Library.get().tracks());
        Collections.sort(out, (a, b) -> Long.compare(b.added, a.added));
        return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
    }

    int totalPlays() {
        int n = 0;
        for (Object v : plays.getAll().values()) if (v instanceof Integer) n += (Integer) v;
        return n;
    }

    void clear() {
        plays.edit().clear().apply();
        last.edit().clear().apply();
    }
}
