package com.neondrift.music;

import android.content.Context;
import android.content.Intent;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.BassBoost;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.Virtualizer;

/**
 * Системные звуковые эффекты Android на аудиосессии плеера: усиление баса,
 * объёмный звук и громкость. Эквалайзер — отдельно, встроенный в libVLC.
 */
final class Effects {
    private final Context ctx;
    final int session;
    private BassBoost bass;
    private Virtualizer virt;
    private LoudnessEnhancer loud;

    Effects(Context c, int session) {
        ctx = c.getApplicationContext();
        this.session = session;
        try {
            bass = new BassBoost(0, session);
        } catch (Throwable t) {
            bass = null;
        }
        try {
            virt = new Virtualizer(0, session);
        } catch (Throwable t) {
            virt = null;
        }
        try {
            loud = new LoudnessEnhancer(session);
        } catch (Throwable t) {
            loud = null;
        }
        announce(true);
    }

    boolean hasBass() { return bass != null; }
    boolean hasVirtualizer() { return virt != null; }
    boolean hasLoudness() { return loud != null; }

    /** 0..1000 */
    void setBass(int strength) {
        if (bass == null) return;
        try {
            bass.setStrength((short) Math.max(0, Math.min(1000, strength)));
            bass.setEnabled(strength > 0);
        } catch (Throwable ignored) {
        }
    }

    /** 0..1000 */
    void setVirtualizer(int strength) {
        if (virt == null) return;
        try {
            virt.setStrength((short) Math.max(0, Math.min(1000, strength)));
            virt.setEnabled(strength > 0);
        } catch (Throwable ignored) {
        }
    }

    /** Миллибелы: 0..1500 (до +15 дБ). */
    void setLoudness(int mb) {
        if (loud == null) return;
        try {
            loud.setTargetGain(Math.max(0, Math.min(1500, mb)));
            loud.setEnabled(mb > 0);
        } catch (Throwable ignored) {
        }
    }

    void apply(Prefs p) {
        setBass(p.bass());
        setVirtualizer(p.virtualizer());
        setLoudness(p.loudness());
    }

    /** Сообщить системе и сторонним эквалайзерам о нашей аудиосессии. */
    private void announce(boolean open) {
        try {
            Intent i = new Intent(open ? AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION
                    : AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
            i.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, session);
            i.putExtra(AudioEffect.EXTRA_PACKAGE_NAME, ctx.getPackageName());
            i.putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC);
            ctx.sendBroadcast(i);
        } catch (Throwable ignored) {
        }
    }

    void release() {
        announce(false);
        for (AudioEffect e : new AudioEffect[]{bass, virt, loud}) {
            if (e != null) {
                try {
                    e.release();
                } catch (Throwable ignored) {
                }
            }
        }
        bass = null;
        virt = null;
        loud = null;
    }
}
