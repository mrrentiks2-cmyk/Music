package com.neondrift.music;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Тонкая полоска прогресса просмотра на миниатюре. */
final class ProgressLine extends View {
    private float progress = -1f;
    private final Paint track = new Paint(), bar = new Paint();

    ProgressLine(Context c) {
        super(c);
        track.setColor(0x66FFFFFF);
        bar.setColor(Theme.ACCENT);
    }

    void setProgress(float p) {
        progress = p;
        setVisibility(p >= 0f ? VISIBLE : GONE);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (progress < 0f) return;
        float w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, track);
        c.drawRect(0, 0, w * Math.max(0.02f, Math.min(1f, progress)), h, bar);
    }
}
