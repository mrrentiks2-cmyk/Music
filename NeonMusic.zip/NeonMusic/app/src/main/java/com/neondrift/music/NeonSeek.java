package com.neondrift.music;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** Неоновая полоса перемотки с крупным бегунком — удобно пальцем. */
final class NeonSeek extends View {
    interface Listener {
        void onSeekMove(float f);
        void onSeekEnd(float f);
    }

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float dp;
    private float value;
    private boolean dragging;
    private Listener listener;
    private int shaderW = -1;

    NeonSeek(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        track.setColor(0x33FFFFFF);
        knob.setColor(0xFFFFFFFF);
        glow.setColor(Theme.alpha(Theme.ACCENT, 70));
    }

    void setListener(Listener l) {
        listener = l;
    }

    void setValue(float f) {
        if (dragging) return;
        value = Math.max(0f, Math.min(1f, f));
        invalidate();
    }

    boolean isDragging() {
        return dragging;
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(32 * dp));
    }

    @Override
    protected void onDraw(Canvas c) {
        float pad = 10 * dp;
        float w = getWidth() - pad * 2, cy = getHeight() / 2f;
        float th = (dragging ? 6 : 4) * dp;
        if (shaderW != getWidth()) {
            shaderW = getWidth();
            bar.setShader(new LinearGradient(pad, 0, pad + w, 0, Theme.ACCENT, Theme.ACCENT2, Shader.TileMode.CLAMP));
        }
        r.set(pad, cy - th / 2, pad + w, cy + th / 2);
        c.drawRoundRect(r, th, th, track);
        float x = pad + w * value;
        r.set(pad, cy - th / 2, Math.max(pad + th, x), cy + th / 2);
        c.drawRoundRect(r, th, th, bar);
        float kr = (dragging ? 10 : 7) * dp;
        c.drawCircle(x, cy, kr * 1.9f, glow);
        c.drawCircle(x, cy, kr, knob);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!isEnabled()) return false;
        float pad = 10 * dp;
        float f = Math.max(0f, Math.min(1f, (e.getX() - pad) / Math.max(1f, getWidth() - pad * 2)));
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                value = f;
                if (listener != null) listener.onSeekMove(f);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                value = f;
                if (listener != null) listener.onSeekMove(f);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                value = f;
                if (listener != null) listener.onSeekEnd(f);
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
