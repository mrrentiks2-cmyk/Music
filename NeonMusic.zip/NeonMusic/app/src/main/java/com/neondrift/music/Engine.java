package com.neondrift.music;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Звуковой движок на libVLC с двумя «деками»: пока одна доигрывает трек,
 * вторая уже начинает следующий — так получается плавный переход (кроссфейд).
 */
final class Engine {
    interface Callback {
        void onStateChanged();
        void onTime(long time);
        void onLength(long length);
        void onTrackEnded();
        void onError();
    }

    private final Context ctx;
    private final Callback cb;
    private final Handler h = new Handler(Looper.getMainLooper());
    private LibVLC lib;
    private final Deck[] decks = new Deck[2];
    private int cur;
    private float rate = 1f;
    private int volume = 100;       // базовая громкость: 100 — без изменений
    private MediaPlayer.Equalizer eq;

    // кроссфейд
    private Deck fadeOut;
    private long fadeStart, fadeMs;
    private final Runnable fader = this::fadeStep;

    Engine(Context ctx, Callback cb, ArrayList<String> options) {
        this.ctx = ctx;
        this.cb = cb;
        try {
            lib = new LibVLC(ctx, options);
        } catch (Throwable t) {
            lib = new LibVLC(ctx, new ArrayList<String>());
        }
        decks[0] = new Deck();
        decks[1] = new Deck();
    }

    private Deck current() {
        return decks[cur];
    }

    // ------------------------------------------------------------------ управление

    void load(Track t, long startMs, boolean play) {
        finishFade();
        Deck d = current();
        decks[1 - cur].stop();
        d.open(t, startMs);
        d.applyVolume(volume);
        if (play) d.mp.play();
    }

    /** Начать следующий трек на второй деке и плавно перейти к нему. */
    void crossfadeTo(Track next, long ms) {
        finishFade();
        Deck old = current();
        cur = 1 - cur;
        Deck d = current();
        d.open(next, 0);
        d.applyVolume(0);
        d.mp.play();
        fadeOut = old;
        fadeStart = SystemClock.uptimeMillis();
        fadeMs = Math.max(300, ms);
        h.post(fader);
    }

    boolean isFading() {
        return fadeOut != null;
    }

    private void fadeStep() {
        if (fadeOut == null) return;
        float p = Math.min(1f, (SystemClock.uptimeMillis() - fadeStart) / (float) fadeMs);
        // равная мощность: синус/косинус звучат ровнее линейного перехода
        float in = (float) Math.sin(p * Math.PI / 2), out = (float) Math.cos(p * Math.PI / 2);
        current().applyVolume(Math.round(volume * in));
        fadeOut.applyVolume(Math.round(volume * out));
        if (p >= 1f) finishFade();
        else h.postDelayed(fader, 40);
    }

    private void finishFade() {
        h.removeCallbacks(fader);
        if (fadeOut != null) {
            fadeOut.stop();
            fadeOut = null;
            current().applyVolume(volume);
        }
    }

    void play() {
        current().mp.play();
    }

    void pause() {
        finishFade();
        current().mp.pause();
    }

    void stop() {
        finishFade();
        decks[0].stop();
        decks[1].stop();
    }

    boolean isPlaying() {
        return current().mp.isPlaying();
    }

    boolean hasMedia() {
        return current().opened;
    }

    long time() {
        return current().time;
    }

    long length() {
        return current().length;
    }

    void seek(long ms) {
        Deck d = current();
        d.mp.setTime(Math.max(0, ms));
        d.time = Math.max(0, ms);
    }

    void setRate(float r) {
        rate = r;
        for (Deck d : decks) d.mp.setRate(r);
    }

    /** Базовая громкость 0..100 — для приглушения и затухания таймера сна. */
    void setVolume(int v) {
        volume = Math.max(0, Math.min(100, v));
        if (fadeOut == null) current().applyVolume(volume);
    }

    void setEqualizer(MediaPlayer.Equalizer e) {
        eq = e;
        for (Deck d : decks) d.mp.setEqualizer(e);
    }

    void release() {
        finishFade();
        for (Deck d : decks) d.release();
        if (lib != null) lib.release();
        lib = null;
    }

    // ------------------------------------------------------------------ дека

    private final class Deck implements MediaPlayer.EventListener {
        final MediaPlayer mp;
        ParcelFileDescriptor pfd;
        long time, length;
        boolean opened;

        Deck() {
            mp = new MediaPlayer(lib);
            mp.setEventListener(this);
        }

        void open(Track t, long startMs) {
            closePfd();
            Media m = makeMedia(t);
            if (m == null) {
                opened = false;
                h.post(cb::onError);
                return;
            }
            m.addOption(":no-video");
            if (t.isStream()) m.addOption(":network-caching=2000");
            if (startMs > 0) m.addOption(String.format(Locale.US, ":start-time=%.3f", startMs / 1000.0));
            mp.setMedia(m);
            m.release();
            mp.setRate(rate);
            if (eq != null) mp.setEqualizer(eq);
            time = Math.max(0, startMs);
            length = t.duration;
            opened = true;
        }

        private Media makeMedia(Track t) {
            try {
                if (t.path != null && new File(t.path).canRead()) return new Media(lib, t.path);
                String scheme = t.uri.getScheme();
                if ("content".equals(scheme)) {
                    pfd = ctx.getContentResolver().openFileDescriptor(t.uri, "r");
                    if (pfd == null) return null;
                    return new Media(lib, Uri.parse("fd://" + pfd.getFd()));
                }
                if ("file".equals(scheme)) return new Media(lib, t.uri.getPath());
                return new Media(lib, t.uri);
            } catch (Throwable e) {
                return null;
            }
        }

        void applyVolume(int v) {
            mp.setVolume(v);
        }

        void stop() {
            try {
                mp.stop();
            } catch (Exception ignored) {
            }
            opened = false;
            closePfd();
        }

        void release() {
            mp.setEventListener(null);
            stop();
            mp.release();
        }

        private void closePfd() {
            if (pfd != null) {
                try {
                    pfd.close();
                } catch (Exception ignored) {
                }
                pfd = null;
            }
        }

        @Override
        public void onEvent(MediaPlayer.Event e) {
            boolean active = this == current();
            switch (e.type) {
                case MediaPlayer.Event.TimeChanged:
                    time = e.getTimeChanged();
                    if (active) cb.onTime(time);
                    break;
                case MediaPlayer.Event.LengthChanged:
                    length = e.getLengthChanged();
                    if (active) cb.onLength(length);
                    break;
                case MediaPlayer.Event.Playing:
                case MediaPlayer.Event.Paused:
                    if (active) cb.onStateChanged();
                    break;
                case MediaPlayer.Event.EndReached:
                    if (active) {
                        opened = false;
                        cb.onTrackEnded();
                    } else if (this == fadeOut) {
                        finishFade();
                    }
                    break;
                case MediaPlayer.Event.EncounteredError:
                    if (active) cb.onError();
                    break;
                default:
                    break;
            }
        }
    }
}
