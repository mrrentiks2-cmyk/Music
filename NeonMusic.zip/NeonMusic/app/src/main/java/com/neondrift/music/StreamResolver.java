package com.neondrift.music;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/**
 * Интернет-радио часто дают ссылкой на маленький плейлист (.pls или .m3u), внутри которого
 * адрес настоящего потока. Достаём этот адрес, чтобы движок сразу играл звук.
 * HLS (.m3u8) не трогаем — его движок понимает сам.
 */
final class StreamResolver {
    private StreamResolver() {}

    static boolean needsResolve(String url) {
        String u = url.toLowerCase(Locale.ROOT);
        int q = u.indexOf('?');
        if (q >= 0) u = u.substring(0, q);
        return (u.startsWith("http://") || u.startsWith("https://")) && (u.endsWith(".pls") || u.endsWith(".m3u"));
    }

    /** Вызывать не в главном потоке. При любой ошибке возвращает исходный адрес. */
    static String resolve(String url) {
        if (!needsResolve(url)) return url;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "NeonMusicPlayer/1.0");
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[65536];
                int n = 0, r;
                while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
                String found = firstStream(new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8));
                return found != null ? found : url;
            }
        } catch (Exception e) {
            return url;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Первый адрес потока из текста PLS или M3U. */
    static String firstStream(String text) {
        for (String raw : text.split("\\r?\\n")) {
            String s = raw.trim();
            if (s.isEmpty() || s.startsWith("#") || s.startsWith("[")) continue;
            if (s.regionMatches(true, 0, "File", 0, 4)) {
                int eq = s.indexOf('=');
                if (eq > 0) s = s.substring(eq + 1).trim();
                else continue;
            } else if (s.indexOf('=') > 0 && !s.contains("://")) {
                continue; // Title1=..., Length1=..., NumberOfEntries=...
            }
            if (s.contains("://")) return s;
        }
        return null;
    }
}
