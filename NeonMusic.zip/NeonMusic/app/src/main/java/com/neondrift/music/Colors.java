package com.neondrift.music;

import android.graphics.Bitmap;
import android.graphics.Color;

/** Цвет обложки для фона экрана плеера. */
final class Colors {
    private Colors() {}

    /** Самый насыщенный заметный цвет картинки, приглушённый для фона. */
    static int dominant(Bitmap b, int fallback) {
        if (b == null) return fallback;
        try {
            Bitmap s = Bitmap.createScaledBitmap(b, 24, 24, true);
            float bestScore = -1f;
            float[] best = null;
            float[] hsv = new float[3];
            long r = 0, g = 0, bl = 0;
            int n = 0;
            for (int y = 0; y < 24; y++) {
                for (int x = 0; x < 24; x++) {
                    int p = s.getPixel(x, y);
                    r += Color.red(p);
                    g += Color.green(p);
                    bl += Color.blue(p);
                    n++;
                    Color.colorToHSV(p, hsv);
                    float score = hsv[1] * (0.35f + 0.65f * Math.min(1f, hsv[2] * 1.4f));
                    if (hsv[2] < 0.12f) score *= 0.2f;
                    if (score > bestScore) {
                        bestScore = score;
                        best = hsv.clone();
                    }
                }
            }
            if (best == null || bestScore < 0.12f) {
                Color.colorToHSV(Color.rgb((int) (r / n), (int) (g / n), (int) (bl / n)), hsv);
                best = hsv;
            }
            best[1] = Math.min(0.85f, Math.max(best[1], 0.35f));
            best[2] = Math.min(0.62f, Math.max(best[2], 0.38f));
            return Color.HSVToColor(best);
        } catch (Throwable t) {
            return fallback;
        }
    }
}
