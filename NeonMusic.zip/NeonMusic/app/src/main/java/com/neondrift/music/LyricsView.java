package com.neondrift.music;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Текст песни из файла пользователя (.lrc или .txt). Для LRC текущая строка подсвечивается
 * и плавно встаёт по центру; тап по строке — перемотка к ней.
 */
final class LyricsView extends ScrollView {
    interface Listener {
        void onSeekTo(long ms);
        void onLoadRequested();
    }

    private final Ui ui;
    private final LinearLayout box;
    private final ArrayList<TextView> rows = new ArrayList<>();
    private Lyrics lyrics;
    private int current = -2;
    private Listener listener;

    LyricsView(Context c, Ui ui) {
        super(c);
        this.ui = ui;
        setVerticalScrollBarEnabled(false);
        setFillViewport(true);
        box = ui.col();
        box.setPadding(ui.dp(24), ui.dp(24), ui.dp(24), ui.dp(24));
        addView(box, new LayoutParams(Ui.MATCH, Ui.WRAP));
    }

    void setListener(Listener l) {
        listener = l;
    }

    boolean hasLyrics() {
        return lyrics != null && !lyrics.isEmpty();
    }

    void setLyrics(Lyrics l) {
        lyrics = l;
        rows.clear();
        box.removeAllViews();
        current = -2;
        if (l == null || l.isEmpty()) {
            box.setGravity(Gravity.CENTER);
            TextView t = ui.text("Текста для этого трека нет", 17, Theme.TEXT, true);
            t.setGravity(Gravity.CENTER);
            box.addView(t);
            TextView s = ui.text("Загрузите свой файл .lrc (с таймингом) или .txt — он сохранится для этого трека. "
                    + "Файл .lrc с тем же именем рядом с песней подхватится сам.", 13, Theme.MUTED, false);
            s.setGravity(Gravity.CENTER);
            s.setLineSpacing(0, 1.3f);
            box.addView(s, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(10), 0, 0));
            TextView b = ui.button("Загрузить текст", true, v -> {
                if (listener != null) listener.onLoadRequested();
            });
            box.addView(b, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(20), 0, 0));
            return;
        }
        box.setGravity(Gravity.START);
        // отступ сверху и снизу, чтобы первая и последняя строки могли встать по центру
        View topPad = new View(getContext());
        box.addView(topPad, Ui.lp(1, ui.dp(l.synced ? 140 : 8)));
        for (Lyrics.Line line : l.lines) {
            TextView t = ui.text(line.text.isEmpty() ? "♪" : line.text, l.synced ? 21 : 17,
                    l.synced ? 0x66F2EEFF : 0xDDF2EEFF, l.synced);
            t.setLineSpacing(0, 1.15f);
            t.setPadding(0, ui.dp(l.synced ? 9 : 4), 0, ui.dp(l.synced ? 9 : 4));
            if (l.synced && line.time >= 0) {
                final long time = line.time;
                t.setOnClickListener(v -> {
                    if (listener != null) listener.onSeekTo(time);
                });
            }
            rows.add(t);
            box.addView(t, Ui.lp(Ui.MATCH, Ui.WRAP));
        }
        View bottomPad = new View(getContext());
        box.addView(bottomPad, Ui.lp(1, ui.dp(l.synced ? 220 : 24)));
        scrollTo(0, 0);
    }

    void setTime(long ms) {
        if (lyrics == null || !lyrics.synced) return;
        int idx = lyrics.lineAt(ms);
        if (idx == current) return;
        if (current >= 0 && current < rows.size()) style(rows.get(current), false);
        current = idx;
        if (idx >= 0 && idx < rows.size()) {
            TextView t = rows.get(idx);
            style(t, true);
            int y = t.getTop() - getHeight() / 2 + t.getHeight() / 2;
            smoothScrollTo(0, Math.max(0, y));
        }
    }

    private void style(TextView t, boolean on) {
        t.setTextColor(on ? Theme.TEXT : 0x66F2EEFF);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.animate().scaleX(on ? 1.04f : 1f).scaleY(on ? 1.04f : 1f).setDuration(200).start();
        t.setPivotX(0);
        t.setShadowLayer(on ? ui.dp(10) : 0, 0, 0, on ? Theme.alpha(Theme.ACCENT, 200) : 0);
    }
}
