package com.neondrift.music;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.Visualizer;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.videolan.libvlc.MediaPlayer;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Экран «Сейчас играет»: обложка, перемотка, очередь, текст, эквалайзер, таймер, скорость. */
public class NowPlayingActivity extends Activity implements PlaybackService.Listener {
    private static final int REQ_LYRICS = 11, REQ_MIC = 12;
    private static final float[] SPEEDS = {0.5f, 0.75f, 0.9f, 1f, 1.1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f};
    private static final int[] SLEEP = {5, 10, 15, 20, 30, 45, 60, 90, 120};

    private Ui ui;
    private Prefs prefs;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PlaybackService svc;
    private boolean bound;

    private FrameLayout root;
    private GradientDrawable bg;
    private int bgColor = 0xFF2B2442;
    private ValueAnimator bgAnim;
    private TextView topSub, title, artist, curTime, totalTime, sleepLabel;
    private FrameLayout artArea;
    private FitSquare artFrame;
    private ImageView art, heart, playBtn, shuffleBtn, repeatBtn, lyricsBtn, eqBtn, timerBtn, speedBtn;
    private TextView speedBadge;
    private LyricsView lyricsView;
    private VisualizerView vizView;
    private Visualizer viz;
    private NeonSeek seek;
    private SidePanel panel;
    private LinearLayout emptyBox, mainBox;

    private String shownKey;
    private Bitmap shownArt;
    private boolean lyricsOn;
    private String lastError;
    private LinearLayout queueBox;

    // ================================================================== жизненный цикл

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Theme.load(this);
        ui = new Ui(this);
        prefs = new Prefs(this);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Theme.BG);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        build();
        setContentView(root);
        bindService(new Intent(this, PlaybackService.class), conn, BIND_AUTO_CREATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(tick);
        if (svc != null) {
            onPlaybackChanged();
            startViz();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
        stopViz();
    }

    @Override
    protected void onDestroy() {
        if (svc != null) svc.removeListener(this);
        if (bound) unbindService(conn);
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (panel.isOpen()) panel.close();
        else close();
    }

    private void close() {
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName n, IBinder b) {
            svc = ((PlaybackService.LocalBinder) b).service();
            bound = true;
            svc.addListener(NowPlayingActivity.this);
            onPlaybackChanged();
            startViz();
        }

        @Override
        public void onServiceDisconnected(ComponentName n) {
            svc = null;
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateTime();
            h.postDelayed(this, 250);
        }
    };

    // ================================================================== интерфейс

    /** Квадрат по меньшей стороне — для обложки. */
    static final class FitSquare extends FrameLayout {
        FitSquare(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec), hh = MeasureSpec.getSize(hSpec);
            int s = MeasureSpec.getMode(hSpec) == MeasureSpec.UNSPECIFIED ? w : Math.min(w, hh);
            int spec = MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY);
            super.onMeasure(spec, spec);
        }
    }

    private void build() {
        root = new FrameLayout(this);
        bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{tone(bgColor), Theme.BG});
        root.setBackground(bg);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });

        boolean land = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels;
        mainBox = land ? ui.row() : ui.col();

        // обложка или текст песни
        artArea = new FrameLayout(this);
        artArea.setPadding(ui.dp(28), ui.dp(12), ui.dp(28), ui.dp(12));
        artFrame = new FitSquare(this);
        art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setClipToOutline(true);
        art.setOutlineProvider(Ui.rounded(ui.dp(26)));
        art.setElevation(ui.dp(18));
        artFrame.addView(art, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        artArea.addView(artFrame, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
        lyricsView = new LyricsView(this, ui);
        lyricsView.setVisibility(View.GONE);
        lyricsView.setListener(new LyricsView.Listener() {
            @Override
            public void onSeekTo(long ms) {
                if (svc != null) svc.seek(ms);
            }

            @Override
            public void onLoadRequested() {
                pickLyrics();
            }
        });
        artArea.addView(lyricsView, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        setupArtGestures();

        LinearLayout controls = ui.col();
        controls.setPadding(ui.dp(24), 0, ui.dp(24), ui.dp(12));
        controls.setGravity(Gravity.CENTER_VERTICAL);

        vizView = new VisualizerView(this);
        vizView.setVisibility(View.GONE);
        controls.addView(vizView, Ui.margins(Ui.MATCH, ui.dp(56), 0, 0, 0, ui.dp(6)));

        // название, исполнитель, «сердце»
        LinearLayout info = ui.row();
        LinearLayout texts = ui.col();
        title = ui.text("", 22, Theme.TEXT, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        title.setMarqueeRepeatLimit(-1);
        title.setHorizontallyScrolling(true);
        title.setSelected(true);
        artist = ui.oneLine("", 15, 0xCCF2EEFF, false);
        artist.setOnClickListener(v -> openInLibrary("artist"));
        texts.addView(title, Ui.lp(Ui.MATCH, Ui.WRAP));
        texts.addView(artist, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, 0));
        info.addView(texts, Ui.lp(0, Ui.WRAP, 1f));
        heart = ui.iconButton("heart", Theme.TEXT, 48, 11, v -> toggleFavorite());
        info.addView(heart);
        controls.addView(info, Ui.lp(Ui.MATCH, Ui.WRAP));

        // перемотка
        seek = new NeonSeek(this);
        seek.setListener(new NeonSeek.Listener() {
            @Override
            public void onSeekMove(float f) {
                if (svc != null) curTime.setText(Fmt.time((long) (f * svc.duration())));
            }

            @Override
            public void onSeekEnd(float f) {
                if (svc != null && svc.duration() > 0) svc.seek((long) (f * svc.duration()));
            }
        });
        controls.addView(seek, Ui.margins(Ui.MATCH, Ui.WRAP, -ui.dp(10), ui.dp(16), -ui.dp(10), 0));
        LinearLayout times = ui.row();
        curTime = ui.text("0:00", 12, Theme.MUTED, false);
        totalTime = ui.text("0:00", 12, Theme.MUTED, false);
        times.addView(curTime, Ui.lp(0, Ui.WRAP, 1f));
        times.addView(totalTime);
        controls.addView(times, Ui.lp(Ui.MATCH, Ui.WRAP));

        // кнопки
        LinearLayout buttons = ui.row();
        buttons.setGravity(Gravity.CENTER);
        shuffleBtn = ui.iconButton("shuffle", Theme.TEXT, 48, 12, v -> {
            if (svc == null) return;
            svc.setShuffle(!svc.queue().shuffle);
            toast(svc.queue().shuffle ? "Перемешивание включено" : "Перемешивание выключено");
        });
        ImageView prev = ui.iconButton("prev", Theme.TEXT, 60, 13, v -> {
            if (svc != null) svc.prev();
        });
        playBtn = ui.iconButton("play", Theme.BG, 78, 22, v -> {
            if (svc != null) svc.playPause();
            v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()).start();
        });
        GradientDrawable pbg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Theme.ACCENT, Theme.ACCENT2});
        pbg.setShape(GradientDrawable.OVAL);
        playBtn.setBackground(Ui.ripple(pbg, Ui.oval(0xFFFFFFFF)));
        playBtn.setElevation(ui.dp(10));
        ImageView next = ui.iconButton("next", Theme.TEXT, 60, 13, v -> {
            if (svc != null) svc.next();
        });
        repeatBtn = ui.iconButton("repeat", Theme.TEXT, 48, 12, v -> {
            if (svc == null) return;
            svc.cycleRepeat();
            int r = svc.queue().repeat;
            toast(r == Queue.REPEAT_ALL ? "Повтор очереди" : r == Queue.REPEAT_ONE ? "Повтор трека" : "Без повтора");
        });
        buttons.addView(shuffleBtn);
        buttons.addView(spacer(), Ui.lp(0, 1, 1f));
        buttons.addView(prev);
        buttons.addView(spacer(), Ui.lp(0, 1, 1f));
        buttons.addView(playBtn);
        buttons.addView(spacer(), Ui.lp(0, 1, 1f));
        buttons.addView(next);
        buttons.addView(spacer(), Ui.lp(0, 1, 1f));
        buttons.addView(repeatBtn);
        controls.addView(buttons, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(14), 0, 0));

        sleepLabel = ui.text("", 12, Theme.ACCENT, true);
        sleepLabel.setGravity(Gravity.CENTER);
        sleepLabel.setVisibility(View.GONE);
        controls.addView(sleepLabel, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));

        // нижний ряд
        LinearLayout tools = ui.row();
        tools.setGravity(Gravity.CENTER);
        ImageView queueBtn = ui.iconButton("queue", Theme.TEXT, 48, 12, v -> showQueue());
        lyricsBtn = ui.iconButton("lyrics", Theme.TEXT, 48, 12, v -> toggleLyrics());
        eqBtn = ui.iconButton("eq", Theme.TEXT, 48, 12, v -> showEq());
        timerBtn = ui.iconButton("timer", Theme.TEXT, 48, 12, v -> showTimer());
        FrameLayout speedBox = new FrameLayout(this);
        speedBtn = ui.iconButton("speed", Theme.TEXT, 48, 12, v -> showSpeed());
        speedBox.addView(speedBtn);
        speedBadge = ui.text("", 9, Theme.BG, true);
        speedBadge.setPadding(ui.dp(4), ui.dp(1), ui.dp(4), ui.dp(1));
        speedBadge.setBackground(Ui.round(Theme.ACCENT, ui.dp(6)));
        speedBadge.setVisibility(View.GONE);
        speedBox.addView(speedBadge, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.END));
        ImageView more = ui.iconButton("more", Theme.TEXT, 48, 12, v -> showMore());
        View[] tv = {queueBtn, lyricsBtn, eqBtn, timerBtn, speedBox, more};
        for (int i = 0; i < tv.length; i++) {
            if (i > 0) tools.addView(spacer(), Ui.lp(0, 1, 1f));
            tools.addView(tv[i]);
        }
        controls.addView(tools, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(12), 0, 0));

        // верхняя строка
        LinearLayout top = ui.row();
        top.setPadding(ui.dp(8), ui.dp(6), ui.dp(8), 0);
        top.addView(ui.iconButton("down", Theme.TEXT, 48, 12, v -> close()));
        LinearLayout tc = ui.col();
        tc.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView lbl = ui.label("СЕЙЧАС ИГРАЕТ");
        lbl.setGravity(Gravity.CENTER);
        tc.addView(lbl);
        topSub = ui.oneLine("", 13, Theme.TEXT, true);
        topSub.setGravity(Gravity.CENTER);
        topSub.setOnClickListener(v -> openInLibrary("album"));
        tc.addView(topSub, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, 0));
        top.addView(tc, Ui.lp(0, Ui.WRAP, 1f));
        top.addView(ui.iconButton("queue", Theme.TEXT, 48, 12, v -> showQueue()));

        LinearLayout page = ui.col();
        page.addView(top, Ui.lp(Ui.MATCH, Ui.WRAP));
        if (land) {
            mainBox.addView(artArea, Ui.lp(0, Ui.MATCH, 1f));
            mainBox.addView(controls, Ui.lp(0, Ui.MATCH, 1.15f));
        } else {
            mainBox.addView(artArea, Ui.lp(Ui.MATCH, 0, 1f));
            mainBox.addView(controls, Ui.lp(Ui.MATCH, Ui.WRAP));
        }
        page.addView(mainBox, Ui.lp(Ui.MATCH, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        // пустое состояние
        emptyBox = ui.col();
        emptyBox.setGravity(Gravity.CENTER);
        emptyBox.setVisibility(View.GONE);
        emptyBox.setBackgroundColor(Theme.BG);
        TextView et = ui.text("Сейчас ничего не играет", 18, Theme.TEXT, true);
        emptyBox.addView(et);
        emptyBox.addView(ui.button("К медиатеке", true, v -> {
            startActivity(new Intent(this, MainActivity.class));
            close();
        }), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(18), 0, 0));
        root.addView(emptyBox, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        panel = new SidePanel(this, ui);
        panel.setListener(() -> queueBox = null);
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
    }

    private View spacer() {
        return new View(this);
    }

    /** Свайп по обложке: влево/вправо — соседний трек, вниз — свернуть, тап — текст песни. */
    private void setupArtGestures() {
        final float[] start = new float[3];
        artArea.setOnTouchListener((v, e) -> {
            if (lyricsOn) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    start[0] = e.getRawX();
                    start[1] = e.getRawY();
                    start[2] = 0;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - start[0], dy = e.getRawY() - start[1];
                    if (start[2] == 0 && Math.hypot(dx, dy) > ui.dp(10)) start[2] = Math.abs(dx) > Math.abs(dy) ? 1 : 2;
                    if (start[2] == 1) {
                        artFrame.setTranslationX(dx);
                        artFrame.setRotation(dx / artFrame.getWidth() * 8f);
                        artFrame.setAlpha(1f - Math.min(0.6f, Math.abs(dx) / Math.max(1f, artFrame.getWidth())));
                    } else if (start[2] == 2 && dy > 0) {
                        artFrame.setTranslationY(dy * 0.5f);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    float dx = e.getRawX() - start[0], dy = e.getRawY() - start[1];
                    if (start[2] == 0 && e.getActionMasked() == MotionEvent.ACTION_UP) {
                        toggleLyrics();
                    } else if (start[2] == 1 && Math.abs(dx) > artFrame.getWidth() * 0.22f && svc != null) {
                        final boolean nextTrack = dx < 0;
                        float out = nextTrack ? -artFrame.getWidth() * 1.2f : artFrame.getWidth() * 1.2f;
                        artFrame.animate().translationX(out).alpha(0f).setDuration(150).withEndAction(() -> {
                            if (svc != null) {
                                if (nextTrack) svc.next();
                                else svc.prev();
                            }
                            artFrame.setTranslationX(-out * 0.5f);
                            artFrame.setRotation(0);
                            artFrame.animate().translationX(0).alpha(1f).setDuration(220).start();
                        }).start();
                    } else if (start[2] == 2 && dy > artArea.getHeight() * 0.25f) {
                        close();
                    } else {
                        artFrame.animate().translationX(0).translationY(0).rotation(0).alpha(1f).setDuration(200).start();
                    }
                    return true;
                }
                default:
                    return true;
            }
        });
    }

    private static int tone(int c) {
        return Theme.mix(Theme.BG, c, 0.85f);
    }

    private void setBgColor(int c) {
        if (c == bgColor) return;
        if (bgAnim != null) bgAnim.cancel();
        int from = bgColor;
        bgColor = c;
        bgAnim = ValueAnimator.ofArgb(from, c);
        bgAnim.setDuration(600);
        bgAnim.addUpdateListener(a -> {
            int v = (Integer) a.getAnimatedValue();
            bg.setColors(new int[]{tone(v), Theme.mix(Theme.BG, v, 0.25f), Theme.BG});
        });
        bgAnim.start();
    }

    // ================================================================== обновление

    @Override
    public void onPlaybackChanged() {
        if (svc == null) return;
        Track t = svc.current();
        emptyBox.setVisibility(t == null ? View.VISIBLE : View.GONE);
        if (t == null) return;
        if (!t.key().equals(shownKey)) {
            shownKey = t.key();
            shownArt = null;
            title.setText(t.title);
            artist.setText(t.isStream() ? String.valueOf(t.uri) : t.artistName());
            topSub.setText(t.isStream() ? "Поток" : t.albumName());
            art.setImageDrawable(new ArtCache.Placeholder(t.albumName(), Theme.ACCENT));
            loadLyrics(t);
            updateHeart();
        }
        Bitmap a = svc.art();
        if (a != null && a != shownArt) {
            shownArt = a;
            art.setImageBitmap(a);
            art.setAlpha(0.4f);
            art.animate().alpha(1f).setDuration(250).start();
        }
        setBgColor(a != null ? svc.artColor() : Theme.mix(0xFF2B2442, Theme.ACCENT, 0.35f));
        playBtn.setImageDrawable(new Glyph(svc.isPlaying() ? "pause" : "play", Theme.BG));
        Queue q = svc.queue();
        tint(shuffleBtn, q.shuffle);
        repeatBtn.setImageDrawable(new Glyph(q.repeat == Queue.REPEAT_ONE ? "repeatOne" : "repeat",
                q.repeat != Queue.REPEAT_OFF ? Theme.ACCENT : Theme.TEXT));
        tint(eqBtn, prefs.eqOn() || prefs.bass() > 0 || prefs.virtualizer() > 0 || prefs.loudness() > 0);
        tint(timerBtn, svc.sleepRemaining() > 0 || svc.sleepAfterTrack());
        tint(lyricsBtn, lyricsOn);
        float sp = svc.speed();
        tint(speedBtn, Math.abs(sp - 1f) > 0.01f);
        speedBadge.setVisibility(Math.abs(sp - 1f) > 0.01f ? View.VISIBLE : View.GONE);
        speedBadge.setText(Fmt.rate(sp));
        String err = svc.lastError();
        if (err != null && !err.equals(lastError)) toast(err);
        lastError = err;
        if (queueBox != null && queueBox.getParent() != null) fillQueue();
        updateTime();
    }

    private void tint(ImageView v, boolean on) {
        Glyph g = v.getDrawable() instanceof Glyph ? (Glyph) v.getDrawable() : null;
        if (g != null) {
            g.setColor(on ? Theme.ACCENT : Theme.TEXT);
            v.invalidate();
        }
    }

    private void updateTime() {
        if (svc == null || svc.current() == null) return;
        long pos = svc.position(), dur = svc.duration();
        boolean live = dur <= 0 && svc.current().isStream();
        seek.setAlpha(dur > 0 ? 1f : 0.35f);
        seek.setEnabled(dur > 0);
        if (!seek.isDragging()) {
            seek.setValue(dur > 0 ? pos / (float) dur : 0f);
            curTime.setText(Fmt.time(pos));
        }
        totalTime.setText(live ? "● эфир" : "−" + Fmt.time(Math.max(0, dur - pos)));
        if (lyricsOn) lyricsView.setTime(pos);
        long sl = svc.sleepRemaining();
        if (sl > 0) {
            sleepLabel.setVisibility(View.VISIBLE);
            sleepLabel.setText("Таймер сна: " + PlaybackService.sleepText(sl));
        } else if (svc.sleepAfterTrack()) {
            sleepLabel.setVisibility(View.VISIBLE);
            sleepLabel.setText("Остановится после этого трека");
        } else {
            sleepLabel.setVisibility(View.GONE);
        }
    }

    private void updateHeart() {
        Track t = svc != null ? svc.current() : null;
        boolean fav = t != null && prefs.isFavorite(t.key());
        heart.setImageDrawable(new Glyph(fav ? "heartFill" : "heart", fav ? Theme.ACCENT : Theme.TEXT));
    }

    private void toggleFavorite() {
        Track t = svc != null ? svc.current() : null;
        if (t == null) return;
        boolean now = prefs.toggleFavorite(t.key());
        updateHeart();
        heart.setScaleX(0.6f);
        heart.setScaleY(0.6f);
        heart.animate().scaleX(1f).scaleY(1f).setDuration(260).start();
        toast(now ? "В избранном" : "Убрано из избранного");
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void openInLibrary(String what) {
        Track t = svc != null ? svc.current() : null;
        if (t == null || t.isStream()) return;
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if ("album".equals(what)) i.putExtra("album", t.albumKey());
        else i.putExtra("artist", t.artistName());
        startActivity(i);
        close();
    }

    // ================================================================== текст песни

    private void toggleLyrics() {
        lyricsOn = !lyricsOn;
        if (lyricsOn) {
            lyricsView.setVisibility(View.VISIBLE);
            lyricsView.setAlpha(0f);
            lyricsView.animate().alpha(1f).setDuration(200).start();
            artFrame.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(200).start();
            if (svc != null) lyricsView.setTime(svc.position());
        } else {
            lyricsView.animate().alpha(0f).setDuration(160).withEndAction(() -> lyricsView.setVisibility(View.GONE)).start();
            artFrame.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start();
        }
        tint(lyricsBtn, lyricsOn);
    }

    private void loadLyrics(Track t) {
        lyricsView.setLyrics(null);
        new Thread(() -> {
            String text = LyricsStore.load(this, t);
            Lyrics l = Lyrics.parse(text);
            h.post(() -> {
                if (!t.key().equals(shownKey)) return;
                lyricsView.setLyrics(l);
                if (svc != null) lyricsView.setTime(svc.position());
            });
        }, "lyrics").start();
    }

    private void pickLyrics() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_LYRICS);
        } catch (Exception e) {
            toast("Нет приложения для выбора файлов");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_LYRICS || res != RESULT_OK || data == null || data.getData() == null || svc == null) return;
        Track t = svc.current();
        if (t == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            if (in == null) throw new Exception();
            String text = LyricsStore.decode(MainActivity.readAll(in));
            Lyrics l = Lyrics.parse(text);
            if (l.isEmpty()) {
                toast("В файле нет текста");
                return;
            }
            LyricsStore.save(this, t, text);
            lyricsView.setLyrics(l);
            if (!lyricsOn) toggleLyrics();
            toast(l.synced ? "Текст с таймингом загружен" : "Текст загружен");
        } catch (Exception e) {
            toast("Не удалось прочитать файл");
        }
    }

    // ================================================================== визуализатор

    private void startViz() {
        stopViz();
        if (svc == null || !prefs.visualizer()) {
            vizView.setVisibility(View.GONE);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            vizView.setVisibility(View.GONE);
            return;
        }
        try {
            viz = new Visualizer(svc.audioSession());
            int[] range = Visualizer.getCaptureSizeRange();
            viz.setCaptureSize(Math.max(range[0], Math.min(range[1], 1024)));
            viz.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer v, byte[] wave, int rate) {
                }

                @Override
                public void onFftDataCapture(Visualizer v, byte[] fft, int rate) {
                    vizView.setFft(fft);
                }
            }, Math.min(Visualizer.getMaxCaptureRate(), 20000), false, true);
            viz.setEnabled(true);
            vizView.setVisibility(View.VISIBLE);
        } catch (Throwable t) {
            viz = null;
            vizView.setVisibility(View.GONE);
        }
    }

    private void stopViz() {
        if (viz != null) {
            try {
                viz.setEnabled(false);
                viz.release();
            } catch (Throwable ignored) {
            }
            viz = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_MIC) {
            boolean ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            prefs.put("visualizer", ok);
            if (ok) startViz();
            else toast("Без разрешения визуализатор не может «слышать» звук плеера");
        }
    }

    // ================================================================== очередь

    private void showQueue() {
        if (svc == null) return;
        LinearLayout c = panel.open("Очередь");
        LinearLayout chips = panel.chipRow(c);
        Queue q = svc.queue();
        panel.chip(chips, q.shuffle ? "Перемешано" : "По порядку", q.shuffle, () -> {
            svc.setShuffle(!svc.queue().shuffle);
            showQueue();
        });
        String[] rep = {"Без повтора", "Повтор очереди", "Повтор трека"};
        panel.chip(chips, rep[q.repeat], q.repeat != Queue.REPEAT_OFF, () -> {
            svc.cycleRepeat();
            showQueue();
        });
        panel.chip(chips, "Очистить", false, () -> {
            svc.clearQueue();
            showQueue();
        });
        panel.chip(chips, "В плейлист", false, () -> saveQueueAsPlaylist());
        queueBox = ui.col();
        c.addView(queueBox, Ui.lp(Ui.MATCH, Ui.WRAP));
        fillQueue();
    }

    private void fillQueue() {
        if (queueBox == null || svc == null) return;
        queueBox.removeAllViews();
        Queue q = svc.queue();
        int from = Math.max(0, q.index - 3), to = Math.min(q.size(), q.index + 250);
        TextView sum = ui.text(Fmt.tracks(q.size()) + (q.index >= 0 ? " · сейчас " + (q.index + 1) : ""), 12, Theme.MUTED, false);
        queueBox.addView(sum, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(6), 0, ui.dp(6)));
        for (int i = from; i < to; i++) {
            final int idx = i;
            Track t = q.items.get(i);
            boolean cur = i == q.index;
            LinearLayout row = ui.row();
            row.setPadding(ui.dp(10), ui.dp(6), 0, ui.dp(6));
            row.setBackground(Ui.ripple(Ui.round(cur ? Theme.alpha(Theme.ACCENT, 38) : 0, ui.dp(12)),
                    Ui.round(0xFFFFFFFF, ui.dp(12))));
            TextView n = ui.text(cur ? "▶" : String.valueOf(i + 1), 12, cur ? Theme.ACCENT : Theme.MUTED, true);
            n.setGravity(Gravity.CENTER);
            row.addView(n, Ui.lp(ui.dp(30), Ui.WRAP));
            LinearLayout tx = ui.col();
            tx.addView(ui.oneLine(t.title, 14.5f, cur ? Theme.ACCENT : Theme.TEXT, cur));
            tx.addView(ui.oneLine(t.artistName(), 12, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
            row.addView(tx, Ui.margins(0, Ui.WRAP, ui.dp(6), 0, 0, 0));
            ((LinearLayout.LayoutParams) tx.getLayoutParams()).weight = 1f;
            if (!cur) {
                row.addView(ui.iconButton("up", Theme.MUTED, 36, 9, v -> svc.moveInQueue(idx, idx - 1)));
                row.addView(ui.iconButton("down", Theme.MUTED, 36, 9, v -> svc.moveInQueue(idx, idx + 1)));
                row.addView(ui.iconButton("close", Theme.MUTED, 36, 10, v -> svc.removeFromQueue(idx)));
            }
            row.setOnClickListener(v -> svc.jump(idx));
            queueBox.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(2), 0, 0));
        }
        if (to < q.size()) {
            panel.note(queueBox, "…и ещё " + Fmt.tracks(q.size() - to));
        }
    }

    private void saveQueueAsPlaylist() {
        if (svc == null) return;
        final List<Track> items = new java.util.ArrayList<>(svc.queue().items);
        askName("Сохранить очередь как плейлист", name -> {
            Playlists.Playlist p = Playlists.get(this).create(name);
            int n = Playlists.get(this).add(p, items);
            toast("«" + name + "»: " + Fmt.tracks(n));
        });
    }

    private void askName(String titleText, java.util.function.Consumer<String> done) {
        android.widget.EditText e = new android.widget.EditText(this);
        e.setSingleLine(true);
        e.setTextColor(Theme.TEXT);
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(ui.dp(22), ui.dp(8), ui.dp(22), 0);
        wrap.addView(e);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(titleText)
                .setView(wrap)
                .setPositiveButton("Готово", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (!s.isEmpty()) done.accept(s);
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ================================================================== эквалайзер

    private static final String[][] PRESET_RU = {
            {"Flat", "Ровно"}, {"Classical", "Классика"}, {"Club", "Клуб"}, {"Dance", "Танцевальная"},
            {"Full bass", "Много баса"}, {"Full bass and treble", "Бас и верха"}, {"Full treble", "Много верхов"},
            {"Headphones", "Наушники"}, {"Large Hall", "Большой зал"}, {"Live", "Концерт"}, {"Party", "Вечеринка"},
            {"Pop", "Поп"}, {"Reggae", "Регги"}, {"Rock", "Рок"}, {"Ska", "Ска"}, {"Soft", "Мягко"},
            {"Soft rock", "Софт-рок"}, {"Techno", "Техно"},
    };

    static String presetName(int i) {
        String n = MediaPlayer.Equalizer.getPresetName(i);
        if (n == null) return "Пресет " + (i + 1);
        for (String[] p : PRESET_RU) if (p[0].equalsIgnoreCase(n.trim())) return p[1];
        return n;
    }

    private static String freqLabel(float hz) {
        if (hz >= 1000) {
            float k = hz / 1000f;
            return (k == Math.round(k) ? String.valueOf(Math.round(k)) : String.format(Locale.US, "%.1f", k).replace('.', ',')) + "к";
        }
        return String.valueOf(Math.round(hz));
    }

    private float[] eqValues;
    private float eqPreamp;

    private void loadEqValues() {
        int n = MediaPlayer.Equalizer.getBandCount();
        eqValues = new float[n];
        MediaPlayer.Equalizer e = PlaybackService.buildEq(prefs.eqPreset(), prefs.eqBands());
        eqPreamp = e.getPreAmp();
        for (int i = 0; i < n; i++) eqValues[i] = e.getAmp(i);
    }

    private static String bandsString(float pre, float[] v) {
        StringBuilder sb = new StringBuilder(String.format(Locale.US, "%.1f", pre));
        for (float f : v) sb.append(',').append(String.format(Locale.US, "%.1f", f));
        return sb.toString();
    }

    private void pushCustomEq(boolean save) {
        MediaPlayer.Equalizer e = MediaPlayer.Equalizer.create();
        e.setPreAmp(eqPreamp);
        for (int i = 0; i < eqValues.length; i++) e.setAmp(i, eqValues[i]);
        if (svc != null && prefs.eqOn()) svc.setEqualizerLive(e);
        if (save) {
            prefs.put("eqPreset", -2);
            prefs.put("eqBands", bandsString(eqPreamp, eqValues));
        }
    }

    private void showEq() {
        if (svc == null) return;
        loadEqValues();
        LinearLayout c = panel.open("Эквалайзер");
        LinearLayout onRow = panel.chipRow(c);
        boolean on = prefs.eqOn();
        panel.chip(onRow, on ? "Включён" : "Выключен", on, () -> {
            prefs.put("eqOn", !prefs.eqOn());
            svc.applyEq();
            onPlaybackChanged();
            showEq();
        });
        panel.chip(onRow, "Сбросить", false, () -> {
            prefs.put("eqPreset", 0);
            prefs.put("eqBands", "");
            prefs.put("bass", 0);
            prefs.put("virt", 0);
            prefs.put("loud", 0);
            svc.effects().apply(prefs);
            svc.applyEq();
            onPlaybackChanged();
            showEq();
        });

        panel.section(c, "ПРЕСЕТЫ");
        LinearLayout presets = panel.chipRow(c);
        int cur = prefs.eqPreset();
        panel.chip(presets, "Свой", cur < 0, () -> {
            prefs.put("eqPreset", -2);
            prefs.put("eqOn", true);
            pushCustomEq(true);
            svc.applyEq();
            onPlaybackChanged();
            showEq();
        });
        for (int i = 0; i < MediaPlayer.Equalizer.getPresetCount(); i++) {
            final int idx = i;
            panel.chip(presets, presetName(i), cur == i, () -> {
                prefs.put("eqPreset", idx);
                prefs.put("eqOn", true);
                MediaPlayer.Equalizer pe = MediaPlayer.Equalizer.createFromPreset(idx);
                float[] v = new float[MediaPlayer.Equalizer.getBandCount()];
                for (int b = 0; b < v.length; b++) v[b] = pe.getAmp(b);
                prefs.put("eqBands", bandsString(pe.getPreAmp(), v));
                svc.applyEq();
                onPlaybackChanged();
                showEq();
            });
        }

        panel.section(c, "ПОЛОСЫ");
        EqView eq = new EqView(this);
        String[] labels = new String[eqValues.length];
        for (int i = 0; i < labels.length; i++) labels[i] = freqLabel(MediaPlayer.Equalizer.getBandFrequency(i));
        eq.setBands(eqValues, labels);
        eq.setActive(on);
        eq.setListener((band, db, done) -> {
            eqValues[band] = db;
            if (!prefs.eqOn()) {
                prefs.put("eqOn", true);
                eq.setActive(true);
            }
            pushCustomEq(done);
            if (done) {
                svc.applyEq();
                onPlaybackChanged();
            }
        });
        c.addView(eq, Ui.lp(Ui.MATCH, Ui.WRAP));

        TextView preLbl = ui.text(preampText(), 13, Theme.TEXT, false);
        c.addView(preLbl, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(14), 0, 0));
        SeekBar pre = panel.slider(c, 40, Math.round(eqPreamp + 20), Theme.ACCENT);
        pre.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                eqPreamp = p - 20;
                preLbl.setText(preampText());
                pushCustomEq(false);
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                if (!prefs.eqOn()) prefs.put("eqOn", true);
                pushCustomEq(true);
                svc.applyEq();
                onPlaybackChanged();
            }
        });

        Effects fx = svc.effects();
        panel.section(c, "ЗВУКОВЫЕ ЭФФЕКТЫ");
        if (fx.hasBass()) effectSlider(c, "Усиление баса", "bass", 1000, fx::setBass);
        if (fx.hasVirtualizer()) effectSlider(c, "Объёмный звук", "virt", 1000, fx::setVirtualizer);
        if (fx.hasLoudness()) effectSlider(c, "Громкость+ (до +15 дБ)", "loud", 1500, fx::setLoudness);
        if (!fx.hasBass() && !fx.hasVirtualizer() && !fx.hasLoudness()) {
            panel.note(c, "Телефон не дал доступ к системным эффектам — работает эквалайзер выше.");
        }
        panel.option(c, "Системный эквалайзер", "Встроенный в телефон или установленное приложение", false, () -> {
            Intent i = new Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL);
            i.putExtra(AudioEffect.EXTRA_AUDIO_SESSION, svc.audioSession());
            i.putExtra(AudioEffect.EXTRA_PACKAGE_NAME, getPackageName());
            i.putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC);
            try {
                startActivityForResult(i, 0);
            } catch (Exception e) {
                toast("Системный эквалайзер не найден");
            }
        });
        panel.note(c, "Эквалайзер на 10 полос встроен в движок VLC и работает на любом телефоне и с любыми наушниками.");
    }

    private String preampText() {
        return String.format(Locale.US, "Предусиление: %+.0f дБ", eqPreamp);
    }

    private interface IntSetter {
        void set(int v);
    }

    private void effectSlider(LinearLayout c, String name, String key, int max, IntSetter setter) {
        int val = "bass".equals(key) ? prefs.bass() : "virt".equals(key) ? prefs.virtualizer() : prefs.loudness();
        TextView lbl = ui.text(name + ": " + (val * 100 / max) + "%", 13, Theme.TEXT, false);
        c.addView(lbl, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(10), 0, 0));
        SeekBar s = panel.slider(c, max, val, Theme.ACCENT2);
        s.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean user) {
                if (!user) return;
                lbl.setText(name + ": " + (p * 100 / max) + "%");
                setter.set(p);
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                prefs.put(key, sb.getProgress());
                onPlaybackChanged();
            }
        });
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }

    // ================================================================== таймер и скорость

    private void showTimer() {
        if (svc == null) return;
        LinearLayout c = panel.open("Таймер сна");
        long left = svc.sleepRemaining();
        if (left > 0) panel.note(c, "Музыка остановится через " + PlaybackService.sleepText(left));
        else if (svc.sleepAfterTrack()) panel.note(c, "Музыка остановится, когда закончится этот трек");
        panel.option(c, "В конце трека", null, svc.sleepAfterTrack(), () -> {
            svc.setSleepAfterTrack();
            panel.close();
            toast("Остановлю после этого трека");
            onPlaybackChanged();
        });
        for (int m : SLEEP) {
            panel.option(c, m < 60 ? m + " мин" : (m % 60 == 0 ? m / 60 + " ч" : m / 60 + " ч " + m % 60 + " мин"), null, false, () -> {
                svc.setSleep(m);
                panel.close();
                toast("Таймер: " + m + " мин");
                onPlaybackChanged();
            });
        }
        if (left > 0 || svc.sleepAfterTrack()) {
            panel.option(c, "Выключить таймер", null, false, () -> {
                svc.setSleep(0);
                panel.close();
                onPlaybackChanged();
            });
        }
        panel.note(c, "В последние 20 секунд громкость плавно уменьшается, чтобы не разбудить.");
    }

    private void showSpeed() {
        if (svc == null) return;
        LinearLayout c = panel.open("Скорость");
        LinearLayout chips = panel.chipRow(c);
        float cur = svc.speed();
        for (float s : SPEEDS) {
            panel.chip(chips, Fmt.rate(s), Math.abs(s - cur) < 0.01f, () -> {
                svc.setSpeed(s);
                onPlaybackChanged();
                showSpeed();
            });
        }
        panel.stepper(c, "Точно", Fmt.rate(cur), () -> {
            svc.setSpeed(Math.round((svc.speed() - 0.05f) * 20f) / 20f);
            onPlaybackChanged();
            showSpeed();
        }, () -> {
            svc.setSpeed(Math.round((svc.speed() + 0.05f) * 20f) / 20f);
            onPlaybackChanged();
            showSpeed();
        }, () -> {
            svc.setSpeed(1f);
            onPlaybackChanged();
            showSpeed();
        });
        panel.section(c, "ТОН");
        boolean keep = prefs.keepPitch();
        panel.option(c, "Сохранять высоту голоса", "Без эффекта «бурундука» при ускорении", keep, () -> {
            prefs.put("keepPitch", true);
            svc.rebuildEngine();
            showSpeed();
        });
        panel.option(c, "Как на пластинке", "Тон меняется вместе со скоростью", !keep, () -> {
            prefs.put("keepPitch", false);
            svc.rebuildEngine();
            showSpeed();
        });
    }

    // ================================================================== ещё

    private void showMore() {
        if (svc == null || svc.current() == null) return;
        Track t = svc.current();
        LinearLayout c = panel.open(t.title);
        panel.option(c, "В плейлист…", null, false, () -> pickPlaylist(t));
        if (!t.isStream()) {
            panel.option(c, "К альбому", t.albumName(), false, () -> {
                panel.close();
                openInLibrary("album");
            });
            panel.option(c, "К исполнителю", t.artistName(), false, () -> {
                panel.close();
                openInLibrary("artist");
            });
        }
        panel.section(c, "ТЕКСТ ПЕСНИ");
        panel.option(c, "Загрузить текст (.lrc, .txt)", "Свой файл — он сохранится для этого трека", false, () -> {
            panel.close();
            pickLyrics();
        });
        if (LyricsStore.hasOwn(this, t)) {
            panel.option(c, "Удалить загруженный текст", null, false, () -> {
                panel.close();
                LyricsStore.delete(this, t);
                loadLyrics(t);
            });
        }
        panel.section(c, "ЕЩЁ");
        panel.option(c, "Визуализатор спектра", prefs.visualizer() ? "Включён" : "Нужно разрешение на запись звука",
                prefs.visualizer(), () -> {
                    panel.close();
                    toggleVisualizer();
                });
        panel.option(c, "Поделиться", null, false, () -> {
            panel.close();
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                if (t.isStream()) {
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, String.valueOf(t.uri));
                } else {
                    i.setType("audio/*");
                    i.putExtra(Intent.EXTRA_STREAM, t.uri);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
                startActivity(Intent.createChooser(i, "Поделиться"));
            } catch (Exception e) {
                toast("Не получилось поделиться");
            }
        });
        panel.option(c, "Сведения о треке", null, false, () -> {
            panel.close();
            MainActivity.showInfo(this, t, new Stats(this));
        });
        panel.option(c, "Настройки", null, false, () -> {
            panel.close();
            startActivity(new Intent(this, SettingsActivity.class));
        });
    }

    private void toggleVisualizer() {
        if (prefs.visualizer()) {
            prefs.put("visualizer", false);
            stopViz();
            vizView.setVisibility(View.GONE);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            prefs.put("visualizer", true);
            startViz();
            return;
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Визуализатор")
                .setMessage("Чтобы рисовать спектр, Android требует разрешение «Микрофон». "
                        + "Плеер анализирует только собственный звук и ничего не записывает с микрофона.")
                .setPositiveButton("Продолжить", (d, w) -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC))
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void pickPlaylist(Track t) {
        LinearLayout c = panel.open("В плейлист");
        panel.option(c, "＋ Новый плейлист", null, false, () -> {
            panel.close();
            askName("Новый плейлист", name -> {
                Playlists.Playlist p = Playlists.get(this).create(name);
                Playlists.get(this).add(p, Collections.singletonList(t));
                toast("Добавлено в «" + name + "»");
            });
        });
        for (Playlists.Playlist p : Playlists.get(this).all()) {
            panel.option(c, p.name, Fmt.tracks(p.keys.size()), false, () -> {
                panel.close();
                int n = Playlists.get(this).add(p, Collections.singletonList(t));
                toast(n > 0 ? "Добавлено в «" + p.name + "»" : "Уже есть в «" + p.name + "»");
            });
        }
    }

    @SuppressWarnings("unused")
    private static ColorStateList csl(int c) {
        return ColorStateList.valueOf(c);
    }
}
