package com.neondrift.music;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

/** Векторные иконки, нарисованные кодом в сетке 24×24. */
final class Glyph extends Drawable {
    private final String name;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path p = new Path();
    private final RectF r = new RectF();

    Glyph(String name, int color) {
        this.name = name;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL_AND_STROKE);
        fill.setStrokeWidth(1.2f);
        fill.setStrokeJoin(Paint.Join.ROUND);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        setColor(color);
    }

    void setColor(int color) {
        stroke.setColor(color);
        fill.setColor(color);
        text.setColor(color);
        invalidateSelf();
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height()) / 24f;
        if (s <= 0) return;
        c.save();
        c.translate(b.left + (b.width() - 24f * s) / 2f, b.top + (b.height() - 24f * s) / 2f);
        c.scale(s, s);
        paint(c);
        c.restore();
    }

    private void tri(float x0, float y0, float x1, float y1, float x2, float y2) {
        p.reset();
        p.moveTo(x0, y0);
        p.lineTo(x1, y1);
        p.lineTo(x2, y2);
        p.close();
    }

    private void line(Canvas c, float x0, float y0, float x1, float y1) {
        c.drawLine(x0, y0, x1, y1, stroke);
    }

    private void poly(Canvas c, float... xy) {
        p.reset();
        p.moveTo(xy[0], xy[1]);
        for (int i = 2; i + 1 < xy.length; i += 2) p.lineTo(xy[i], xy[i + 1]);
        c.drawPath(p, stroke);
    }

    private void arcArrow(Canvas c, boolean clockwise) {
        r.set(5f, 6f, 19f, 20f);
        p.reset();
        if (clockwise) {
            p.addArc(r, -100f, 300f);
            c.drawPath(p, stroke);
            tri(12.5f, 2.6f, 16.2f, 6f, 12.5f, 9.4f);
        } else {
            p.addArc(r, -80f, -300f);
            c.drawPath(p, stroke);
            tri(11.5f, 2.6f, 7.8f, 6f, 11.5f, 9.4f);
        }
        c.drawPath(p, fill);
    }

    private void paint(Canvas c) {
        switch (name) {
            case "play":
                tri(8f, 5f, 19.5f, 12f, 8f, 19f);
                c.drawPath(p, fill);
                break;
            case "pause":
                r.set(6f, 5f, 10f, 19f);
                c.drawRoundRect(r, 1f, 1f, fill);
                r.set(14f, 5f, 18f, 19f);
                c.drawRoundRect(r, 1f, 1f, fill);
                break;
            case "replay":
                arcArrow(c, true);
                break;
            case "next":
                tri(5f, 6f, 14.5f, 12f, 5f, 18f);
                c.drawPath(p, fill);
                r.set(16f, 6f, 18.5f, 18f);
                c.drawRoundRect(r, 0.8f, 0.8f, fill);
                break;
            case "prev":
                tri(19f, 6f, 9.5f, 12f, 19f, 18f);
                c.drawPath(p, fill);
                r.set(5.5f, 6f, 8f, 18f);
                c.drawRoundRect(r, 0.8f, 0.8f, fill);
                break;
            case "rewind":
            case "forward": {
                boolean fwd = name.equals("forward");
                arcArrow(c, fwd);
                text.setTextSize(6.4f);
                c.drawText("10", 12f, 15.6f, text);
                break;
            }
            case "back":
                poly(c, 15f, 5f, 8f, 12f, 15f, 19f);
                break;
            case "close":
                line(c, 6f, 6f, 18f, 18f);
                line(c, 18f, 6f, 6f, 18f);
                break;
            case "more":
                c.drawCircle(12f, 5.5f, 1.9f, fill);
                c.drawCircle(12f, 12f, 1.9f, fill);
                c.drawCircle(12f, 18.5f, 1.9f, fill);
                break;
            case "lock":
            case "unlock": {
                r.set(5.5f, 11f, 18.5f, 20.5f);
                c.drawRoundRect(r, 2f, 2f, fill);
                p.reset();
                if (name.equals("lock")) {
                    p.moveTo(8.5f, 11f);
                    p.lineTo(8.5f, 8f);
                    r.set(8.5f, 4f, 15.5f, 11f);
                    p.arcTo(r, 180f, 180f);
                    p.lineTo(15.5f, 11f);
                } else {
                    p.moveTo(8.5f, 11f);
                    p.lineTo(8.5f, 8f);
                    r.set(8.5f, 4f, 15.5f, 11f);
                    p.arcTo(r, 180f, 160f);
                }
                c.drawPath(p, stroke);
                break;
            }
            case "rotate":
                r.set(4.5f, 4.5f, 19.5f, 19.5f);
                p.reset();
                p.addArc(r, 200f, 290f);
                c.drawPath(p, stroke);
                tri(3.2f, 8.6f, 6.1f, 4.8f, 8.4f, 9.6f);
                c.drawPath(p, fill);
                r.set(9.5f, 8.5f, 14.5f, 15.5f);
                c.drawRoundRect(r, 1f, 1f, stroke);
                break;
            case "aspect":
                r.set(3f, 5.5f, 21f, 18.5f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                poly(c, 7f, 12f, 7f, 9f, 10f, 9f);
                poly(c, 17f, 12f, 17f, 15f, 14f, 15f);
                break;
            case "subs":
                r.set(3f, 5f, 21f, 19f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                line(c, 7f, 11f, 13f, 11f);
                line(c, 15.5f, 11f, 17f, 11f);
                line(c, 7f, 15f, 9f, 15f);
                line(c, 11.5f, 15f, 17f, 15f);
                break;
            case "audio":
                c.drawCircle(8f, 17f, 2.8f, fill);
                line(c, 10.8f, 17f, 10.8f, 5f);
                p.reset();
                p.moveTo(10.8f, 5f);
                p.lineTo(18f, 7f);
                p.lineTo(18f, 10f);
                p.lineTo(10.8f, 8f);
                p.close();
                c.drawPath(p, fill);
                break;
            case "speed":
                r.set(3.5f, 5f, 20.5f, 22f);
                p.reset();
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                line(c, 12f, 13.5f, 16.5f, 8.5f);
                c.drawCircle(12f, 13.5f, 1.8f, fill);
                break;
            case "pip":
                r.set(3f, 5f, 21f, 19f);
                c.drawRoundRect(r, 2f, 2f, stroke);
                r.set(12f, 11.5f, 18.5f, 16.5f);
                c.drawRoundRect(r, 1f, 1f, fill);
                break;
            case "eq":
                line(c, 6f, 4f, 6f, 20f);
                line(c, 12f, 4f, 12f, 20f);
                line(c, 18f, 4f, 18f, 20f);
                c.drawCircle(6f, 9f, 2.4f, fill);
                c.drawCircle(12f, 15f, 2.4f, fill);
                c.drawCircle(18f, 7.5f, 2.4f, fill);
                break;
            case "timer":
                c.drawCircle(12f, 13.5f, 7.5f, stroke);
                line(c, 12f, 13.5f, 12f, 9.5f);
                line(c, 12f, 13.5f, 15f, 15.5f);
                line(c, 9.5f, 3f, 14.5f, 3f);
                break;
            case "repeat":
            case "repeatOne":
                poly(c, 5f, 12f, 5f, 8f, 17f, 8f);
                tri(16f, 5f, 19.5f, 8f, 16f, 11f);
                c.drawPath(p, fill);
                poly(c, 19f, 12f, 19f, 16f, 7f, 16f);
                tri(8f, 13f, 4.5f, 16f, 8f, 19f);
                c.drawPath(p, fill);
                if (name.equals("repeatOne")) {
                    text.setTextSize(6f);
                    c.drawText("1", 12f, 14.2f, text);
                }
                break;
            case "ab":
                text.setTextSize(9f);
                c.drawText("A-B", 12f, 15.3f, text);
                break;
            case "info":
                c.drawCircle(12f, 12f, 9f, stroke);
                c.drawCircle(12f, 7.8f, 1.3f, fill);
                line(c, 12f, 11f, 12f, 16.8f);
                break;
            case "folder":
                p.reset();
                p.moveTo(3f, 7f);
                p.lineTo(3f, 18f);
                p.lineTo(21f, 18f);
                p.lineTo(21f, 8.5f);
                p.lineTo(11.5f, 8.5f);
                p.lineTo(9.5f, 6f);
                p.lineTo(4f, 6f);
                p.close();
                c.drawPath(p, stroke);
                break;
            case "file":
                poly(c, 14f, 3f, 6f, 3f, 6f, 21f, 18f, 21f, 18f, 7f, 14f, 3f, 14f, 7f, 18f, 7f);
                line(c, 9f, 12f, 15f, 12f);
                line(c, 9f, 16f, 15f, 16f);
                break;
            case "search":
                c.drawCircle(10.5f, 10.5f, 6f, stroke);
                line(c, 15f, 15f, 20f, 20f);
                break;
            case "sort":
                line(c, 4f, 7f, 20f, 7f);
                line(c, 4f, 12f, 15f, 12f);
                line(c, 4f, 17f, 10f, 17f);
                break;
            case "link":
                c.save();
                c.rotate(-45f, 12f, 12f);
                r.set(2.5f, 9f, 13f, 15f);
                c.drawRoundRect(r, 3f, 3f, stroke);
                r.set(11f, 9f, 21.5f, 15f);
                c.drawRoundRect(r, 3f, 3f, stroke);
                c.restore();
                break;
            case "settings":
                line(c, 4f, 7f, 20f, 7f);
                line(c, 4f, 17f, 20f, 17f);
                c.drawCircle(9f, 7f, 2.6f, fill);
                c.drawCircle(15f, 17f, 2.6f, fill);
                break;
            case "check":
                poly(c, 5f, 12.5f, 10f, 17.5f, 19f, 7f);
                break;
            case "plus":
                line(c, 12f, 5f, 12f, 19f);
                line(c, 5f, 12f, 19f, 12f);
                break;
            case "minus":
                line(c, 5f, 12f, 19f, 12f);
                break;
            case "video":
                r.set(3f, 5f, 21f, 19f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                tri(10f, 9f, 15.5f, 12f, 10f, 15f);
                c.drawPath(p, fill);
                break;
            case "playlist":
                line(c, 4f, 6f, 16f, 6f);
                line(c, 4f, 11f, 16f, 11f);
                line(c, 4f, 16f, 11f, 16f);
                tri(14f, 14f, 20f, 17f, 14f, 20f);
                c.drawPath(p, fill);
                break;
            case "sun":
                c.drawCircle(12f, 12f, 4f, fill);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    float cx = (float) Math.cos(a), sy = (float) Math.sin(a);
                    line(c, 12f + cx * 7f, 12f + sy * 7f, 12f + cx * 9.2f, 12f + sy * 9.2f);
                }
                break;
            case "volume":
            case "mute": {
                p.reset();
                p.moveTo(4f, 9.5f);
                p.lineTo(8f, 9.5f);
                p.lineTo(13f, 5f);
                p.lineTo(13f, 19f);
                p.lineTo(8f, 14.5f);
                p.lineTo(4f, 14.5f);
                p.close();
                c.drawPath(p, fill);
                if (name.equals("mute")) {
                    line(c, 16f, 9f, 21f, 15f);
                    line(c, 21f, 9f, 16f, 15f);
                } else {
                    r.set(10f, 7.5f, 19f, 16.5f);
                    p.reset();
                    p.addArc(r, -50f, 100f);
                    c.drawPath(p, stroke);
                    r.set(9f, 4f, 22f, 20f);
                    p.reset();
                    p.addArc(r, -50f, 100f);
                    c.drawPath(p, stroke);
                }
                break;
            }
            case "heart":
            case "heartFill": {
                p.reset();
                p.moveTo(12f, 20f);
                p.cubicTo(5f, 15.2f, 2.5f, 12f, 2.5f, 8.6f);
                p.cubicTo(2.5f, 5.8f, 4.7f, 3.8f, 7.3f, 3.8f);
                p.cubicTo(9.2f, 3.8f, 11f, 4.9f, 12f, 6.6f);
                p.cubicTo(13f, 4.9f, 14.8f, 3.8f, 16.7f, 3.8f);
                p.cubicTo(19.3f, 3.8f, 21.5f, 5.8f, 21.5f, 8.6f);
                p.cubicTo(21.5f, 12f, 19f, 15.2f, 12f, 20f);
                p.close();
                c.drawPath(p, name.equals("heartFill") ? fill : stroke);
                break;
            }
            case "shuffle":
                poly(c, 4f, 7f, 8f, 7f, 16f, 17f, 19f, 17f);
                poly(c, 4f, 17f, 8f, 17f, 10.5f, 13.8f);
                poly(c, 13.5f, 10.2f, 16f, 7f, 19f, 7f);
                tri(17.5f, 4f, 21f, 7f, 17.5f, 10f);
                c.drawPath(p, fill);
                tri(17.5f, 14f, 21f, 17f, 17.5f, 20f);
                c.drawPath(p, fill);
                break;
            case "queue":
                line(c, 4f, 6f, 20f, 6f);
                line(c, 4f, 11f, 20f, 11f);
                line(c, 4f, 16f, 12f, 16f);
                c.drawCircle(17.5f, 17.5f, 2.6f, fill);
                line(c, 20f, 17.5f, 20f, 11.5f);
                break;
            case "lyrics":
                r.set(4f, 3.5f, 20f, 20.5f);
                c.drawRoundRect(r, 2.5f, 2.5f, stroke);
                line(c, 8f, 8.5f, 16f, 8.5f);
                line(c, 8f, 12f, 16f, 12f);
                line(c, 8f, 15.5f, 12.5f, 15.5f);
                break;
            case "album":
                c.drawCircle(12f, 12f, 9f, stroke);
                c.drawCircle(12f, 12f, 2.6f, fill);
                break;
            case "artist":
                c.drawCircle(12f, 8f, 4f, stroke);
                p.reset();
                r.set(4.5f, 13.5f, 19.5f, 26f);
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                break;
            case "genre":
                p.reset();
                p.moveTo(12f, 3f);
                p.lineTo(21f, 12f);
                p.lineTo(12f, 21f);
                p.lineTo(3f, 12f);
                p.close();
                c.drawPath(p, stroke);
                c.drawCircle(12f, 12f, 2f, fill);
                break;
            case "note":
                c.drawCircle(8.5f, 17.5f, 3f, fill);
                c.drawCircle(17f, 15.5f, 3f, fill);
                line(c, 11.3f, 17.5f, 11.3f, 5.5f);
                line(c, 19.8f, 15.5f, 19.8f, 3.5f);
                p.reset();
                p.moveTo(11.3f, 5.5f);
                p.lineTo(19.8f, 3.5f);
                p.lineTo(19.8f, 6.5f);
                p.lineTo(11.3f, 8.5f);
                p.close();
                c.drawPath(p, fill);
                break;
            case "playlistAdd":
                line(c, 4f, 6f, 15f, 6f);
                line(c, 4f, 11f, 15f, 11f);
                line(c, 4f, 16f, 10f, 16f);
                line(c, 17.5f, 12f, 17.5f, 20f);
                line(c, 13.5f, 16f, 21.5f, 16f);
                break;
            case "trash":
                line(c, 4f, 6.5f, 20f, 6.5f);
                poly(c, 9f, 6.5f, 9.5f, 3.5f, 14.5f, 3.5f, 15f, 6.5f);
                poly(c, 6f, 6.5f, 7f, 20.5f, 17f, 20.5f, 18f, 6.5f);
                line(c, 10f, 10f, 10.3f, 17f);
                line(c, 14f, 10f, 13.7f, 17f);
                break;
            case "up":
                poly(c, 6f, 15f, 12f, 9f, 18f, 15f);
                break;
            case "down":
            case "collapse":
                poly(c, 6f, 9f, 12f, 15f, 18f, 9f);
                break;
            case "share":
                c.drawCircle(18f, 5.5f, 2.6f, fill);
                c.drawCircle(6f, 12f, 2.6f, fill);
                c.drawCircle(18f, 18.5f, 2.6f, fill);
                line(c, 8.3f, 10.8f, 15.7f, 6.7f);
                line(c, 8.3f, 13.2f, 15.7f, 17.3f);
                break;
            case "chart":
                line(c, 4f, 20f, 20f, 20f);
                r.set(5.5f, 12f, 8.5f, 18f);
                c.drawRoundRect(r, 1f, 1f, fill);
                r.set(10.5f, 7f, 13.5f, 18f);
                c.drawRoundRect(r, 1f, 1f, fill);
                r.set(15.5f, 4f, 18.5f, 18f);
                c.drawRoundRect(r, 1f, 1f, fill);
                break;
            case "radio":
                c.drawCircle(12f, 13f, 2.4f, fill);
                r.set(6.5f, 7.5f, 17.5f, 18.5f);
                p.reset();
                p.addArc(r, 200f, 140f);
                c.drawPath(p, stroke);
                r.set(2.5f, 3.5f, 21.5f, 22.5f);
                p.reset();
                p.addArc(r, 205f, 130f);
                c.drawPath(p, stroke);
                break;
            case "bars":
                for (int i = 0; i < 5; i++) {
                    float hgt = new float[]{8f, 14f, 18f, 11f, 6f}[i];
                    r.set(3.5f + i * 3.6f, 20f - hgt, 5.9f + i * 3.6f, 20f);
                    c.drawRoundRect(r, 1f, 1f, fill);
                }
                break;
            case "headphones":
                p.reset();
                r.set(4f, 4f, 20f, 20f);
                p.addArc(r, 180f, 180f);
                c.drawPath(p, stroke);
                r.set(3f, 12f, 8f, 20f);
                c.drawRoundRect(r, 2f, 2f, fill);
                r.set(16f, 12f, 21f, 20f);
                c.drawRoundRect(r, 2f, 2f, fill);
                break;
            case "cast":
            default:
                c.drawCircle(12f, 12f, 3f, fill);
                break;
        }
    }

    @Override
    public void setAlpha(int alpha) {
        stroke.setAlpha(alpha);
        fill.setAlpha(alpha);
        text.setAlpha(alpha);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        stroke.setColorFilter(cf);
        fill.setColorFilter(cf);
        text.setColorFilter(cf);
        invalidateSelf();
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
