package com.neondrift.music;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.function.Consumer;

/** Медиатека: вкладки, подборки, поиск, плейлисты и мини-плеер. */
public class MainActivity extends Activity implements PlaybackService.Listener {
    private static final int REQ_PERM = 1, REQ_IMPORT = 2, REQ_EXPORT = 3;
    private static final String[] TABS = {"Для вас", "Треки", "Альбомы", "Исполнители", "Жанры", "Папки", "Плейлисты"};
    private static final String[] TRACK_SORTS = {"По названию", "По исполнителю", "По альбому", "Сначала новые", "Сначала длинные"};
    private static final String[] ALBUM_SORTS = {"По названию", "По исполнителю", "По году"};

    private Ui ui;
    private Prefs prefs;
    private Stats stats;
    private final Handler h = new Handler(Looper.getMainLooper());

    private FrameLayout root;
    private LinearLayout topBar, searchBar, detailBar;
    private HorizontalScrollView tabScroll;
    private final ArrayList<TextView> tabViews = new ArrayList<>();
    private TextView detailTitle;
    private ImageView sortButton;
    private EditText searchField;
    private ListView list;
    private final RowAdapter adapter = new RowAdapter();
    private SidePanel panel;

    private FrameLayout mini;
    private ImageView miniArt, miniPlay;
    private TextView miniTitle, miniArtist;
    private ProgressLine miniProgress;

    private PlaybackService svc;
    private boolean bound;
    private String currentKey;
    private int tab;
    private boolean searching;
    private int accentAtStart;
    private final ArrayList<Screen> stack = new ArrayList<>();
    private Uri pendingOpen;
    private Playlists.Playlist exporting;
    private boolean scanning;
    private ContentObserver observer;

    /** Экран внутри медиатеки: альбом, исполнитель, плейлист и т. д. */
    private static final class Screen {
        static final int ALBUM = 0, ARTIST = 1, GENRE = 2, FOLDER = 3, PLAYLIST = 4, SMART = 5;
        int kind;
        String title, sub, icon;
        Library.Group group;
        Playlists.Playlist playlist;
        int smart;
        int scrollPos, scrollTop;
    }

    // ================================================================== жизненный цикл

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Theme.load(this);
        accentAtStart = Theme.ACCENT;
        ui = new Ui(this);
        prefs = new Prefs(this);
        stats = new Stats(this);
        tab = Math.max(0, Math.min(TABS.length - 1, prefs.tab()));
        Window w = getWindow();
        w.setStatusBarColor(Theme.BG);
        w.setNavigationBarColor(Theme.BG);
        buildUi();
        setContentView(root);
        bindService(new Intent(this, PlaybackService.class), conn, BIND_AUTO_CREATE);
        handleIntent(getIntent());
        if (hasAudioPermission()) {
            scan();
        } else {
            requestAudioPermission();
            refresh();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Theme.load(this);
        if (Theme.ACCENT != accentAtStart) {
            recreate();
            return;
        }
        if (svc != null) onPlaybackChanged();
        if (Library.get().isLoaded() || hasAudioPermission()) refresh();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
        prefs.put("tab", tab);
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        refresh(); // число колонок альбомов зависит от ширины экрана
    }

    @Override
    protected void onDestroy() {
        if (svc != null) svc.removeListener(this);
        if (bound) unbindService(conn);
        if (observer != null) getContentResolver().unregisterContentObserver(observer);
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (panel.isOpen()) {
            panel.close();
        } else if (searching) {
            closeSearch();
        } else if (!stack.isEmpty()) {
            popScreen();
        } else {
            super.onBackPressed();
        }
    }

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder b) {
            svc = ((PlaybackService.LocalBinder) b).service();
            bound = true;
            svc.addListener(MainActivity.this);
            onPlaybackChanged();
            if (pendingOpen != null) {
                Uri u = pendingOpen;
                pendingOpen = null;
                openExternal(u);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            svc = null;
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (svc != null && svc.current() != null) {
                long d = svc.duration();
                miniProgress.setProgress(d > 0 ? svc.position() / (float) d : 0f);
            }
            h.postDelayed(this, 500);
        }
    };

    @Override
    public void onPlaybackChanged() {
        Track t = svc != null ? svc.current() : null;
        if (t == null) {
            mini.setVisibility(View.GONE);
        } else {
            if (mini.getVisibility() != View.VISIBLE) {
                mini.setVisibility(View.VISIBLE);
                mini.setTranslationY(ui.dp(40));
                mini.animate().translationY(0).setDuration(220).start();
            }
            miniTitle.setText(t.title);
            miniArtist.setText(t.artistName());
            ArtCache.get(this).load(t, miniArt, 160);
            miniPlay.setImageDrawable(new Glyph(svc.isPlaying() ? "pause" : "play", Theme.BG));
        }
        String key = t != null ? t.key() : null;
        if (key == null ? currentKey != null : !key.equals(currentKey)) {
            currentKey = key;
            adapter.notifyDataSetChanged();
        }
    }

    // ================================================================== разрешения и сканирование

    private String audioPermission() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private boolean hasAudioPermission() {
        return checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{audioPermission(), Manifest.permission.POST_NOTIFICATIONS}, REQ_PERM);
        } else {
            requestPermissions(new String[]{audioPermission()}, REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM && hasAudioPermission()) scan();
        else refresh();
    }

    void scan() {
        if (scanning) return;
        scanning = true;
        if (!Library.get().isLoaded()) refresh();
        final int min = prefs.minDuration();
        final Set<String> hidden = prefs.hiddenFolders();
        new Thread(() -> {
            List<Track> found = Library.scan(this, min, hidden);
            h.post(() -> {
                scanning = false;
                if (isDestroyed()) return;
                Library.get().set(found);
                ArtCache.get(this).clearMissing();
                refresh();
            });
        }, "scan").start();
        if (observer == null) {
            observer = new ContentObserver(h) {
                @Override
                public void onChange(boolean selfChange) {
                    h.removeCallbacks(rescan);
                    h.postDelayed(rescan, 2500);
                }
            };
            try {
                getContentResolver().registerContentObserver(Library.collection(), true, observer);
            } catch (Exception ignored) {
            }
        }
    }

    private final Runnable rescan = this::scan;

    // ================================================================== каркас интерфейса

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Theme.BG);
        LinearLayout column = ui.col();
        root.addView(column, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        // верхняя строка
        topBar = ui.row();
        topBar.setPadding(ui.dp(20), ui.dp(14), ui.dp(8), ui.dp(4));
        TextView logo = ui.text("Neon Music", 26, Theme.TEXT, true);
        logo.getPaint().setShader(new LinearGradient(0, 0, ui.dp(170), 0, Theme.ACCENT, Theme.ACCENT2, Shader.TileMode.CLAMP));
        logo.setLetterSpacing(-0.01f);
        topBar.addView(logo, Ui.lp(0, Ui.WRAP, 1f));
        topBar.addView(ui.iconButton("search", Theme.TEXT, 44, 11, v -> openSearch()));
        sortButton = ui.iconButton("sort", Theme.TEXT, 44, 11, v -> showSort());
        topBar.addView(sortButton);
        topBar.addView(ui.iconButton("more", Theme.TEXT, 44, 11, v -> showMainMenu()));
        column.addView(topBar, Ui.lp(Ui.MATCH, Ui.WRAP));

        // строка поиска
        searchBar = ui.row();
        searchBar.setPadding(ui.dp(8), ui.dp(10), ui.dp(12), ui.dp(4));
        searchBar.addView(ui.iconButton("back", Theme.TEXT, 44, 11, v -> closeSearch()));
        searchField = new EditText(this);
        searchField.setHint("Треки, альбомы, исполнители");
        searchField.setHintTextColor(Theme.MUTED);
        searchField.setTextColor(Theme.TEXT);
        searchField.setTextSize(16);
        searchField.setSingleLine(true);
        searchField.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchField.setBackground(Ui.round(Theme.SURFACE2, ui.dp(14)));
        searchField.setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10));
        searchField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { refresh(); }
        });
        searchBar.addView(searchField, Ui.lp(0, Ui.WRAP, 1f));
        searchBar.setVisibility(View.GONE);
        column.addView(searchBar, Ui.lp(Ui.MATCH, Ui.WRAP));

        // строка экрана внутри (альбом, исполнитель…)
        detailBar = ui.row();
        detailBar.setPadding(ui.dp(8), ui.dp(10), ui.dp(12), ui.dp(2));
        detailBar.addView(ui.iconButton("back", Theme.TEXT, 44, 11, v -> popScreen()));
        detailTitle = ui.oneLine("", 17, Theme.TEXT, true);
        detailBar.addView(detailTitle, Ui.margins(0, Ui.WRAP, ui.dp(6), 0, 0, 0));
        ((LinearLayout.LayoutParams) detailTitle.getLayoutParams()).weight = 1f;
        detailBar.setVisibility(View.GONE);
        column.addView(detailBar, Ui.lp(Ui.MATCH, Ui.WRAP));

        // вкладки
        tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = ui.row();
        tabs.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8));
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = ui.chip(TABS[i], i == tab, v -> selectTab(idx));
            LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
            lp.rightMargin = ui.dp(8);
            tabs.addView(t, lp);
            tabViews.add(t);
        }
        tabScroll.addView(tabs);
        column.addView(tabScroll, Ui.lp(Ui.MATCH, Ui.WRAP));

        // список
        list = new ListView(this);
        list.setDivider(null);
        list.setSelector(new GradientDrawable());
        list.setCacheColorHint(0);
        list.setClipToPadding(false);
        list.setPadding(0, ui.dp(4), 0, ui.dp(96));
        list.setFastScrollEnabled(true);
        list.setAdapter(adapter);
        column.addView(list, Ui.lp(Ui.MATCH, 0, 1f));

        buildMini();
        panel = new SidePanel(this, ui);
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        updateBars();
    }

    private void buildMini() {
        mini = new FrameLayout(this);
        mini.setBackground(Ui.stroke(Theme.SURFACE2, Theme.alpha(Theme.ACCENT, 90), ui.dp(1), ui.dp(20)));
        mini.setElevation(ui.dp(10));
        mini.setClipToOutline(true);
        mini.setOutlineProvider(Ui.rounded(ui.dp(20)));
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(8), ui.dp(8), ui.dp(6), ui.dp(8));
        miniArt = new ImageView(this);
        miniArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        miniArt.setClipToOutline(true);
        miniArt.setOutlineProvider(Ui.rounded(ui.dp(12)));
        row.addView(miniArt, Ui.lp(ui.dp(48), ui.dp(48)));
        LinearLayout texts = ui.col();
        miniTitle = ui.oneLine("", 15, Theme.TEXT, true);
        miniArtist = ui.oneLine("", 12, Theme.MUTED, false);
        texts.addView(miniTitle);
        texts.addView(miniArtist, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        row.addView(texts, Ui.margins(0, Ui.WRAP, ui.dp(12), 0, ui.dp(6), 0));
        ((LinearLayout.LayoutParams) texts.getLayoutParams()).weight = 1f;
        miniPlay = ui.iconButton("play", Theme.BG, 44, 11, v -> {
            if (svc != null) svc.playPause();
        });
        miniPlay.setBackground(Ui.ripple(Ui.oval(Theme.ACCENT), Ui.oval(0xFFFFFFFF)));
        row.addView(miniPlay);
        View gap = new View(this);
        row.addView(gap, Ui.lp(ui.dp(4), 1));
        row.addView(ui.iconButton("next", Theme.TEXT, 44, 11, v -> {
            if (svc != null) svc.next();
        }));
        mini.addView(row, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        miniProgress = new ProgressLine(this);
        mini.addView(miniProgress, new FrameLayout.LayoutParams(Ui.MATCH, ui.dp(2), Gravity.BOTTOM));
        mini.setOnClickListener(v -> openNowPlaying());
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM);
        lp.setMargins(ui.dp(10), 0, ui.dp(10), ui.dp(10));
        mini.setVisibility(View.GONE);
        root.addView(mini, lp);
    }

    private void openNowPlaying() {
        startActivity(new Intent(this, NowPlayingActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void updateBars() {
        boolean detail = !stack.isEmpty() && !searching;
        topBar.setVisibility(!searching && !detail ? View.VISIBLE : View.GONE);
        tabScroll.setVisibility(!searching && !detail ? View.VISIBLE : View.GONE);
        searchBar.setVisibility(searching ? View.VISIBLE : View.GONE);
        detailBar.setVisibility(detail ? View.VISIBLE : View.GONE);
        if (detail) detailTitle.setText(top().title);
        sortButton.setVisibility(tab == 1 || tab == 2 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < tabViews.size(); i++) ui.styleChip(tabViews.get(i), i == tab);
    }

    private void selectTab(int i) {
        if (i == tab) {
            list.smoothScrollToPosition(0);
            return;
        }
        tab = i;
        updateBars();
        refresh();
        list.setSelection(0);
        list.setAlpha(0.3f);
        list.animate().alpha(1f).setDuration(160).start();
    }

    private Screen top() {
        return stack.get(stack.size() - 1);
    }

    private void pushScreen(Screen s) {
        Screen cur = stack.isEmpty() ? null : top();
        int pos = list.getFirstVisiblePosition();
        View first = list.getChildAt(0);
        int topOff = first != null ? first.getTop() : 0;
        if (cur != null) {
            cur.scrollPos = pos;
            cur.scrollTop = topOff;
        } else {
            rootScrollPos = pos;
            rootScrollTop = topOff;
        }
        stack.add(s);
        updateBars();
        refresh();
        list.setSelection(0);
        list.setTranslationX(ui.dp(30));
        list.setAlpha(0f);
        list.animate().translationX(0).alpha(1f).setDuration(180).start();
    }

    private int rootScrollPos, rootScrollTop;

    private void popScreen() {
        if (stack.isEmpty()) return;
        stack.remove(stack.size() - 1);
        updateBars();
        refresh();
        if (stack.isEmpty()) list.setSelectionFromTop(rootScrollPos, rootScrollTop);
        else list.setSelectionFromTop(top().scrollPos, top().scrollTop);
        list.setAlpha(0.4f);
        list.animate().alpha(1f).setDuration(150).start();
    }

    private void openSearch() {
        searching = true;
        updateBars();
        searchField.setText("");
        searchField.requestFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.showSoftInput(searchField, InputMethodManager.SHOW_IMPLICIT);
        refresh();
    }

    private void closeSearch() {
        searching = false;
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(searchField.getWindowToken(), 0);
        updateBars();
        refresh();
    }

    // ================================================================== содержимое

    /** Строка списка. */
    private static final class Item {
        static final int LABEL = 0, TRACK = 1, GROUP = 2, ALBUMS = 3, HEADER = 4, EMPTY = 5, BUTTONS = 6, HERO = 7;
        final int type;
        String title, sub, icon;
        Track track;          // трек или обложка группы
        List<Track> list;     // для TRACK: из какого списка играть
        int pos;              // для TRACK: позиция в list
        int number;           // номер дорожки в альбоме
        boolean round;        // круглая обложка (исполнитель)
        Library.Group[] albums;
        String[] buttons;
        Runnable[] actions;
        Runnable click, more;
        Screen screen;        // для HEADER

        Item(int type) {
            this.type = type;
        }
    }

    private final ArrayList<Item> items = new ArrayList<>();

    private int columns() {
        int wdp = Math.round(getResources().getDisplayMetrics().widthPixels / ui.density);
        return Math.max(2, Math.min(6, wdp / 175));
    }

    void refresh() {
        items.clear();
        if (!hasAudioPermission()) {
            Item e = new Item(Item.EMPTY);
            e.icon = "headphones";
            e.title = "Нужен доступ к музыке";
            e.sub = "Neon Music Player показывает только аудиофайлы на этом устройстве. Ничего никуда не отправляется.";
            e.buttons = new String[]{"Разрешить доступ"};
            e.actions = new Runnable[]{this::requestAudioPermission};
            items.add(e);
        } else if (searching) {
            buildSearch(searchField.getText().toString());
        } else if (!stack.isEmpty()) {
            buildScreen(top());
        } else if (!Library.get().isLoaded()) {
            Item e = new Item(Item.EMPTY);
            e.icon = "search";
            e.title = "Ищу музыку…";
            e.sub = "Сканирую память устройства";
            items.add(e);
        } else {
            switch (tab) {
                case 0: buildHome(); break;
                case 1: buildTracks(); break;
                case 2: buildAlbums(); break;
                case 3: buildGroups(Library.get().artists(), Screen.ARTIST); break;
                case 4: buildGroups(Library.get().genres(), Screen.GENRE); break;
                case 5: buildGroups(Library.get().folders(), Screen.FOLDER); break;
                default: buildPlaylists(); break;
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void label(String s) {
        Item l = new Item(Item.LABEL);
        l.title = s;
        items.add(l);
    }

    private void tracks(List<Track> list, boolean numbers) {
        for (int i = 0; i < list.size(); i++) {
            Item it = new Item(Item.TRACK);
            it.track = list.get(i);
            it.list = list;
            it.pos = i;
            if (numbers) it.number = it.track.trackNo > 0 ? it.track.trackNo : i + 1;
            items.add(it);
        }
    }

    private void albumRows(List<Library.Group> albums) {
        int cols = columns();
        for (int i = 0; i < albums.size(); i += cols) {
            Item r = new Item(Item.ALBUMS);
            r.albums = new Library.Group[cols];
            for (int j = 0; j < cols && i + j < albums.size(); j++) r.albums[j] = albums.get(i + j);
            items.add(r);
        }
    }

    private void empty(String icon, String title, String sub) {
        Item e = new Item(Item.EMPTY);
        e.icon = icon;
        e.title = title;
        e.sub = sub;
        items.add(e);
    }

    private Item group(String icon, Track cover, String title, String sub, Runnable click) {
        Item g = new Item(Item.GROUP);
        g.icon = icon;
        g.track = cover;
        g.title = title;
        g.sub = sub;
        g.click = click;
        items.add(g);
        return g;
    }

    private void buildHome() {
        Library lib = Library.get();
        List<Track> all = lib.tracks();
        if (all.isEmpty()) {
            empty("note", "Музыка не найдена",
                    "Положите аудиофайлы в память телефона (например, в папку Music) — они появятся здесь сами.");
            addStreams();
            return;
        }
        long total = 0;
        for (Track t : all) total += t.duration;
        Item hero = new Item(Item.HERO);
        hero.title = "Ваша музыка";
        hero.sub = Fmt.tracks(all.size()) + " · " + Fmt.albums(lib.albums().size()) + " · " + Fmt.total(total);
        Track cur = svc != null ? svc.current() : null;
        if (cur != null) {
            hero.buttons = new String[]{"Перемешать всё", "Продолжить"};
            hero.actions = new Runnable[]{this::shuffleAll, this::openNowPlaying};
        } else {
            hero.buttons = new String[]{"Перемешать всё"};
            hero.actions = new Runnable[]{this::shuffleAll};
        }
        items.add(hero);

        label("ПОДБОРКИ");
        smartRow(0);
        smartRow(1);
        smartRow(2);
        smartRow(3);

        ArrayList<Library.Group> fresh = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        for (Track t : Stats.recentlyAdded(400)) {
            if (seen.add(t.albumKey())) {
                Library.Group g = lib.album(t.albumKey());
                if (g != null) fresh.add(g);
            }
            if (fresh.size() >= columns() * 2) break;
        }
        if (!fresh.isEmpty()) {
            label("НОВЫЕ АЛЬБОМЫ");
            albumRows(fresh);
        }
        addStreams();
    }

    private static final String[] SMART_TITLES = {"Избранное", "Часто слушаю", "Недавно игравшие", "Недавно добавленные"};
    private static final String[] SMART_ICONS = {"heartFill", "chart", "replay", "plus"};

    private List<Track> smartTracks(int i) {
        switch (i) {
            case 0: {
                ArrayList<Track> out = new ArrayList<>();
                Set<String> fav = prefs.favorites();
                for (Track t : Library.get().tracks()) if (fav.contains(t.key())) out.add(t);
                return out;
            }
            case 1: return stats.mostPlayed(100);
            case 2: return stats.recentlyPlayed(100);
            default: return Stats.recentlyAdded(100);
        }
    }

    private void smartRow(int i) {
        List<Track> l = smartTracks(i);
        group(SMART_ICONS[i], null, SMART_TITLES[i], l.isEmpty() ? "Пока пусто" : Fmt.tracks(l.size()), () -> {
            Screen s = new Screen();
            s.kind = Screen.SMART;
            s.smart = i;
            s.title = SMART_TITLES[i];
            s.icon = SMART_ICONS[i];
            pushScreen(s);
        });
    }

    private void addStreams() {
        label("РАДИО И ПОТОКИ");
        List<String[]> streams = loadStreams();
        for (String[] s : streams) {
            Item g = group("radio", null, s[0], s[1], () -> playStream(s[0], s[1]));
            g.more = () -> {
                LinearLayout c = panel.open(s[0]);
                panel.option(c, "Слушать", null, false, () -> {
                    panel.close();
                    playStream(s[0], s[1]);
                });
                panel.option(c, "Удалить из списка", null, false, () -> {
                    panel.close();
                    removeStream(s[1]);
                    refresh();
                });
            };
        }
        Item b = new Item(Item.BUTTONS);
        b.buttons = new String[]{"Открыть ссылку на поток"};
        b.actions = new Runnable[]{this::askStream};
        items.add(b);
    }

    private void buildTracks() {
        ArrayList<Track> all = new ArrayList<>(Library.get().tracks());
        if (all.isEmpty()) {
            empty("note", "Треков нет", "Аудиофайлы из памяти телефона появятся здесь.");
            return;
        }
        Library.sortTracks(all, prefs.trackSort());
        group("shuffle", null, "Перемешать все", Fmt.tracks(all.size()), this::shuffleAll);
        tracks(all, false);
    }

    private void buildAlbums() {
        ArrayList<Library.Group> albums = new ArrayList<>(Library.get().albums());
        if (albums.isEmpty()) {
            empty("album", "Альбомов нет", "Альбомы собираются из тегов файлов.");
            return;
        }
        Library.sortAlbums(albums, prefs.albumSort());
        albumRows(albums);
    }

    private void buildGroups(List<Library.Group> groups, int kind) {
        if (groups.isEmpty()) {
            empty("note", "Пусто", "Здесь пока ничего нет.");
            return;
        }
        for (Library.Group g : groups) {
            String sub;
            String icon;
            if (kind == Screen.ARTIST) {
                sub = Fmt.albums(g.albums.size()) + " · " + Fmt.tracks(g.tracks.size());
                icon = "artist";
            } else if (kind == Screen.GENRE) {
                sub = Fmt.tracks(g.tracks.size());
                icon = "genre";
            } else {
                sub = Fmt.tracks(g.tracks.size()) + " · " + g.sub;
                icon = "folder";
            }
            Item it = group(icon, kind == Screen.ARTIST ? g.cover() : null, g.name, sub, () -> openGroup(g, kind));
            it.round = kind == Screen.ARTIST;
            it.more = () -> groupMenu(g, kind);
        }
    }

    private void buildPlaylists() {
        Item b = new Item(Item.BUTTONS);
        b.buttons = new String[]{"Новый плейлист", "Импорт M3U"};
        b.actions = new Runnable[]{() -> askText("Новый плейлист", "", name -> {
            Playlists.get(this).create(name);
            refresh();
        }), this::importM3u};
        items.add(b);
        List<Playlists.Playlist> all = Playlists.get(this).all();
        if (all.isEmpty()) {
            empty("playlist", "Плейлистов пока нет",
                    "Создайте плейлист или добавьте в него трек через меню ⋮ рядом с треком.");
            return;
        }
        for (Playlists.Playlist p : all) {
            List<Track> tr = Playlists.tracks(p);
            Item it = group("playlist", tr.isEmpty() ? null : tr.get(0), p.name, Fmt.tracks(tr.size()), () -> openPlaylist(p));
            it.more = () -> playlistMenu(p);
        }
    }

    private void buildSearch(String q) {
        if (q.trim().isEmpty()) {
            empty("search", "Поиск по медиатеке", "Начните вводить название трека, альбома или имя исполнителя.");
            return;
        }
        Library lib = Library.get();
        String s = q.toLowerCase(Locale.ROOT).trim();
        ArrayList<Library.Group> artists = new ArrayList<>();
        for (Library.Group g : lib.artists()) if (g.name.toLowerCase(Locale.ROOT).contains(s)) artists.add(g);
        ArrayList<Library.Group> albums = new ArrayList<>();
        for (Library.Group g : lib.albums()) {
            if (g.name.toLowerCase(Locale.ROOT).contains(s) || g.sub.toLowerCase(Locale.ROOT).contains(s)) albums.add(g);
        }
        List<Track> found = lib.search(q);
        if (artists.isEmpty() && albums.isEmpty() && found.isEmpty()) {
            empty("search", "Ничего не найдено", "Попробуйте другое слово.");
            return;
        }
        if (!artists.isEmpty()) {
            label("ИСПОЛНИТЕЛИ");
            for (int i = 0; i < Math.min(5, artists.size()); i++) {
                Library.Group g = artists.get(i);
                Item it = group("artist", g.cover(), g.name, Fmt.tracks(g.tracks.size()), () -> openGroup(g, Screen.ARTIST));
                it.round = true;
            }
        }
        if (!albums.isEmpty()) {
            label("АЛЬБОМЫ");
            albumRows(albums.size() > columns() * 2 ? albums.subList(0, columns() * 2) : albums);
        }
        if (!found.isEmpty()) {
            label("ТРЕКИ");
            tracks(found.size() > 300 ? new ArrayList<>(found.subList(0, 300)) : found, false);
        }
    }

    private void openGroup(Library.Group g, int kind) {
        Screen s = new Screen();
        s.kind = kind;
        s.group = g;
        s.title = g.name;
        s.icon = kind == Screen.ARTIST ? "artist" : kind == Screen.GENRE ? "genre" : kind == Screen.FOLDER ? "folder" : "album";
        if (searching) {
            searching = false;
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(searchField.getWindowToken(), 0);
        }
        pushScreen(s);
    }

    private void openPlaylist(Playlists.Playlist p) {
        Screen s = new Screen();
        s.kind = Screen.PLAYLIST;
        s.playlist = p;
        s.title = p.name;
        s.icon = "playlist";
        pushScreen(s);
    }

    private List<Track> screenTracks(Screen s) {
        switch (s.kind) {
            case Screen.PLAYLIST: return Playlists.tracks(s.playlist);
            case Screen.SMART: return smartTracks(s.smart);
            default: return s.group != null ? s.group.tracks : new ArrayList<>();
        }
    }

    private void buildScreen(Screen s) {
        if (s.kind == Screen.PLAYLIST && Playlists.get(this).byId(s.playlist.id) == null) {
            empty("playlist", "Плейлист удалён", "");
            return;
        }
        List<Track> tr = screenTracks(s);
        long dur = 0;
        for (Track t : tr) dur += t.duration;
        Item head = new Item(Item.HEADER);
        head.screen = s;
        head.track = tr.isEmpty() ? null : tr.get(0);
        head.icon = s.icon;
        head.round = s.kind == Screen.ARTIST;
        if (s.kind == Screen.PLAYLIST) s.title = s.playlist.name;
        head.title = s.title;
        switch (s.kind) {
            case Screen.ALBUM:
                Library.Group g = s.group;
                head.sub = g.sub + (g.year > 0 ? " · " + g.year : "") + "\n" + Fmt.tracks(tr.size()) + " · " + Fmt.total(dur);
                break;
            case Screen.ARTIST:
                head.sub = Fmt.albums(s.group.albums.size()) + " · " + Fmt.tracks(tr.size()) + " · " + Fmt.total(dur);
                break;
            case Screen.FOLDER:
                head.sub = s.group.id + "\n" + Fmt.tracks(tr.size()) + " · " + Fmt.total(dur);
                break;
            default:
                head.sub = Fmt.tracks(tr.size()) + (dur > 0 ? " · " + Fmt.total(dur) : "");
                break;
        }
        head.list = tr;
        if (s.kind == Screen.PLAYLIST) head.more = () -> playlistMenu(s.playlist);
        else if (s.group != null) head.more = () -> groupMenu(s.group, s.kind);
        items.add(head);
        if (tr.isEmpty()) {
            empty("note", "Здесь пока пусто",
                    s.kind == Screen.PLAYLIST ? "Добавляйте треки через меню ⋮ → «В плейлист»."
                            : s.kind == Screen.SMART && s.smart == 0 ? "Нажмите ♥ на экране плеера, чтобы добавить трек." : "");
            return;
        }
        if (s.kind == Screen.ARTIST && s.group.albums.size() > 1) {
            ArrayList<Library.Group> al = new ArrayList<>();
            for (String k : s.group.albums) {
                Library.Group a = Library.get().album(k);
                if (a != null) al.add(a);
            }
            Library.sortAlbums(al, 2);
            label("АЛЬБОМЫ");
            albumRows(al);
            label("ВСЕ ТРЕКИ");
        }
        tracks(tr, s.kind == Screen.ALBUM);
    }

    // ================================================================== воспроизведение

    private void play(List<Track> list, int pos, boolean shuffle) {
        if (svc == null || list.isEmpty()) return;
        svc.playList(list, pos, shuffle);
    }

    private void shuffleAll() {
        List<Track> all = Library.get().tracks();
        if (all.isEmpty()) return;
        play(all, new Random().nextInt(all.size()), true);
        toast("Перемешано: " + Fmt.tracks(all.size()));
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ================================================================== меню

    private void showSort() {
        boolean albums = tab == 2;
        String[] names = albums ? ALBUM_SORTS : TRACK_SORTS;
        int cur = albums ? prefs.albumSort() : prefs.trackSort();
        LinearLayout c = panel.open("Сортировка");
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            panel.option(c, names[i], null, i == cur, () -> {
                prefs.put(albums ? "albumSort" : "trackSort", idx);
                panel.close();
                refresh();
            });
        }
    }

    private void showMainMenu() {
        LinearLayout c = panel.open("Neon Music Player");
        panel.option(c, "Перемешать всё", "Случайный порядок по всей медиатеке", false, () -> {
            panel.close();
            shuffleAll();
        });
        panel.option(c, "Открыть ссылку на поток", "Интернет-радио, подкаст, файл по адресу", false, () -> {
            panel.close();
            askStream();
        });
        panel.option(c, "Обновить медиатеку", "Найти новые файлы", false, () -> {
            panel.close();
            toast("Сканирую…");
            scan();
        });
        panel.option(c, "Настройки", "Оформление, переходы, эквалайзер, папки", false, () -> {
            panel.close();
            startActivity(new Intent(this, SettingsActivity.class));
        });
    }

    void trackMenu(Track t, Screen in, int posInList) {
        LinearLayout c = panel.open(t.title);
        panel.note(c, t.artistName() + " · " + t.albumName());
        panel.section(c, "ВОСПРОИЗВЕДЕНИЕ");
        panel.option(c, "Играть следующим", null, false, () -> {
            panel.close();
            if (svc != null) svc.playNext(t);
            toast("Будет следующим");
        });
        panel.option(c, "Добавить в очередь", null, false, () -> {
            panel.close();
            if (svc != null) svc.addToQueue(Collections.singletonList(t));
            toast("Добавлено в очередь");
        });
        panel.section(c, "КОЛЛЕКЦИЯ");
        boolean fav = prefs.isFavorite(t.key());
        panel.option(c, fav ? "Убрать из избранного" : "В избранное", null, false, () -> {
            panel.close();
            prefs.toggleFavorite(t.key());
            refresh();
        });
        panel.option(c, "В плейлист…", null, false, () -> pickPlaylist(Collections.singletonList(t)));
        if (in != null && in.kind == Screen.PLAYLIST) {
            Playlists.Playlist p = in.playlist;
            panel.option(c, "Выше", null, false, () -> {
                Playlists.get(this).move(p, posInList, posInList - 1);
                panel.close();
                refresh();
            });
            panel.option(c, "Ниже", null, false, () -> {
                Playlists.get(this).move(p, posInList, posInList + 1);
                panel.close();
                refresh();
            });
            panel.option(c, "Убрать из плейлиста", null, false, () -> {
                Playlists.get(this).remove(p, posInList);
                panel.close();
                refresh();
            });
        }
        panel.section(c, "ПЕРЕЙТИ");
        Library.Group album = Library.get().album(t.albumKey());
        if (album != null && (in == null || in.kind != Screen.ALBUM)) {
            panel.option(c, "К альбому", t.albumName(), false, () -> {
                panel.close();
                openGroup(album, Screen.ALBUM);
            });
        }
        Library.Group artist = Library.get().artist(t.artistName());
        if (artist != null && (in == null || in.kind != Screen.ARTIST)) {
            panel.option(c, "К исполнителю", t.artistName(), false, () -> {
                panel.close();
                openGroup(artist, Screen.ARTIST);
            });
        }
        panel.option(c, "Поделиться", null, false, () -> {
            panel.close();
            share(t);
        });
        panel.option(c, "Сведения", null, false, () -> {
            panel.close();
            showInfo(this, t, stats);
        });
    }

    private void groupMenu(Library.Group g, int kind) {
        LinearLayout c = panel.open(g.name);
        panel.option(c, "Слушать", Fmt.tracks(g.tracks.size()), false, () -> {
            panel.close();
            play(g.tracks, 0, false);
        });
        panel.option(c, "Перемешать", null, false, () -> {
            panel.close();
            play(g.tracks, new Random().nextInt(Math.max(1, g.tracks.size())), true);
        });
        panel.option(c, "Играть следующими", null, false, () -> {
            panel.close();
            if (svc == null) return;
            for (int i = g.tracks.size() - 1; i >= 0; i--) svc.playNext(g.tracks.get(i));
            toast("Будут следующими");
        });
        panel.option(c, "Добавить в очередь", null, false, () -> {
            panel.close();
            if (svc != null) svc.addToQueue(g.tracks);
            toast("Добавлено: " + Fmt.tracks(g.tracks.size()));
        });
        panel.option(c, "В плейлист…", null, false, () -> pickPlaylist(g.tracks));
        if (kind == Screen.FOLDER) {
            panel.option(c, "Скрыть папку", "Вернуть можно в настройках", false, () -> {
                panel.close();
                prefs.setHidden(g.id, true);
                if (!stack.isEmpty()) popScreen();
                toast("Папка скрыта");
                scan();
            });
        }
    }

    private void playlistMenu(Playlists.Playlist p) {
        LinearLayout c = panel.open(p.name);
        List<Track> tr = Playlists.tracks(p);
        panel.option(c, "Слушать", Fmt.tracks(tr.size()), false, () -> {
            panel.close();
            play(tr, 0, false);
        });
        panel.option(c, "Перемешать", null, false, () -> {
            panel.close();
            if (!tr.isEmpty()) play(tr, new Random().nextInt(tr.size()), true);
        });
        panel.option(c, "Переименовать", null, false, () -> {
            panel.close();
            askText("Название плейлиста", p.name, name -> {
                Playlists.get(this).rename(p, name);
                refresh();
            });
        });
        panel.option(c, "Экспорт в M3U", "Сохранить файл плейлиста", false, () -> {
            panel.close();
            exporting = p;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("audio/x-mpegurl");
            i.putExtra(Intent.EXTRA_TITLE, p.name + ".m3u");
            try {
                startActivityForResult(i, REQ_EXPORT);
            } catch (Exception e) {
                toast("Нет приложения для сохранения файлов");
            }
        });
        panel.option(c, "Удалить плейлист", null, false, () -> {
            panel.close();
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Удалить «" + p.name + "»?")
                    .setMessage("Сами треки останутся на устройстве.")
                    .setPositiveButton("Удалить", (d, w) -> {
                        Playlists.get(this).delete(p);
                        if (!stack.isEmpty() && top().kind == Screen.PLAYLIST) popScreen();
                        else refresh();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
        });
    }

    private void pickPlaylist(List<Track> tracks) {
        LinearLayout c = panel.open("В плейлист");
        panel.option(c, "＋ Новый плейлист", null, false, () -> {
            panel.close();
            askText("Новый плейлист", "", name -> {
                Playlists.Playlist p = Playlists.get(this).create(name);
                int n = Playlists.get(this).add(p, tracks);
                toast("«" + name + "»: добавлено " + Fmt.tracks(n));
                refresh();
            });
        });
        for (Playlists.Playlist p : Playlists.get(this).all()) {
            panel.option(c, p.name, Fmt.tracks(p.keys.size()), false, () -> {
                panel.close();
                int n = Playlists.get(this).add(p, tracks);
                toast(n > 0 ? "«" + p.name + "»: добавлено " + Fmt.tracks(n) : "Уже есть в «" + p.name + "»");
                refresh();
            });
        }
    }

    private void share(Track t) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("audio/*");
            i.putExtra(Intent.EXTRA_STREAM, t.uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Поделиться треком"));
        } catch (Exception e) {
            toast("Не получилось поделиться");
        }
    }

    static void showInfo(Activity a, Track t, Stats stats) {
        StringBuilder sb = new StringBuilder();
        sb.append("Исполнитель: ").append(t.artistName()).append('\n');
        sb.append("Альбом: ").append(t.albumName()).append('\n');
        if (t.genre != null && !t.genre.trim().isEmpty()) sb.append("Жанр: ").append(t.genreName()).append('\n');
        if (t.year > 0) sb.append("Год: ").append(t.year).append('\n');
        if (t.trackNo > 0) sb.append("Номер: ").append(t.trackNo).append('\n');
        if (t.duration > 0) sb.append("Длительность: ").append(Fmt.time(t.duration)).append('\n');
        if (t.size > 0) sb.append("Размер: ").append(Fmt.size(t.size)).append('\n');
        String p = t.path != null ? t.path : String.valueOf(t.uri);
        int dot = p.lastIndexOf('.');
        if (dot > 0 && p.length() - dot <= 6) sb.append("Формат: ").append(p.substring(dot + 1).toUpperCase(Locale.ROOT)).append('\n');
        sb.append("Прослушано: ").append(Fmt.plays(stats.plays(t))).append("\n\n");
        sb.append(p);
        new AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(t.title)
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    private void askText(String title, String initial, Consumer<String> done) {
        EditText e = new EditText(this);
        e.setText(initial);
        e.setSingleLine(true);
        e.setSelection(e.getText().length());
        e.setTextColor(Theme.TEXT);
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(ui.dp(22), ui.dp(8), ui.dp(22), 0);
        wrap.addView(e);
        AlertDialog d = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title)
                .setView(wrap)
                .setPositiveButton("Готово", (di, w) -> {
                    String s = e.getText().toString().trim();
                    if (!s.isEmpty()) done.accept(s);
                })
                .setNegativeButton("Отмена", null)
                .create();
        d.show();
        e.requestFocus();
        if (d.getWindow() != null) d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    // ================================================================== потоки

    private SharedPreferences streamPrefs() {
        return getSharedPreferences("streams", MODE_PRIVATE);
    }

    private List<String[]> loadStreams() {
        ArrayList<String[]> out = new ArrayList<>();
        String raw = streamPrefs().getString("list", "");
        for (String line : raw.split("\n")) {
            int tabPos = line.indexOf('\t');
            if (tabPos > 0) out.add(new String[]{line.substring(0, tabPos), line.substring(tabPos + 1)});
        }
        return out;
    }

    private void saveStreams(List<String[]> l) {
        StringBuilder sb = new StringBuilder();
        for (String[] s : l) sb.append(s[0].replace('\t', ' ').replace('\n', ' ')).append('\t').append(s[1]).append('\n');
        streamPrefs().edit().putString("list", sb.toString()).apply();
    }

    private void removeStream(String url) {
        List<String[]> l = loadStreams();
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i)[1].equals(url)) l.remove(i);
        saveStreams(l);
    }

    private void askStream() {
        LinearLayout box = ui.col();
        box.setPadding(ui.dp(22), ui.dp(8), ui.dp(22), 0);
        EditText url = new EditText(this);
        url.setHint("https://… (mp3, aac, ogg, m3u, pls, HLS)");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setTextColor(Theme.TEXT);
        EditText name = new EditText(this);
        name.setHint("Название (необязательно)");
        name.setSingleLine(true);
        name.setTextColor(Theme.TEXT);
        box.addView(url);
        box.addView(name);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Ссылка на поток")
                .setView(box)
                .setPositiveButton("Слушать", (d, w) -> {
                    String u = url.getText().toString().trim();
                    if (u.isEmpty()) return;
                    if (!u.contains("://")) u = "http://" + u;
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) {
                        Uri p = Uri.parse(u);
                        n = p.getHost() != null ? p.getHost() : u;
                    }
                    List<String[]> l = loadStreams();
                    for (int i = l.size() - 1; i >= 0; i--) if (l.get(i)[1].equals(u)) l.remove(i);
                    l.add(0, new String[]{n, u});
                    while (l.size() > 20) l.remove(l.size() - 1);
                    saveStreams(l);
                    playStream(n, u);
                    refresh();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void playStream(String name, String url) {
        if (StreamResolver.needsResolve(url)) toast("Открываю «" + name + "»…");
        new Thread(() -> {
            String real = StreamResolver.resolve(url);
            h.post(() -> {
                if (isDestroyed()) return;
                Track t = new Track();
                t.uri = Uri.parse(real);
                t.title = name;
                t.artist = "Поток";
                t.album = name;
                play(Collections.singletonList(t), 0, false);
                openNowPlaying();
            });
        }, "stream").start();
    }

    // ================================================================== открыть файл извне

    private void handleIntent(Intent i) {
        if (i == null) return;
        String albumKey = i.getStringExtra("album"), artistName = i.getStringExtra("artist");
        if (albumKey != null || artistName != null) {
            i.removeExtra("album");
            i.removeExtra("artist");
            Library.Group g = albumKey != null ? Library.get().album(albumKey) : Library.get().artist(artistName);
            if (g != null) {
                if (panel.isOpen()) panel.close();
                if (searching) closeSearch();
                stack.clear();
                openGroup(g, albumKey != null ? Screen.ALBUM : Screen.ARTIST);
            }
            return;
        }
        if (!Intent.ACTION_VIEW.equals(i.getAction()) || i.getData() == null) return;
        Uri u = i.getData();
        setIntent(new Intent(this, MainActivity.class));
        if (svc != null) openExternal(u);
        else pendingOpen = u;
    }

    private void openExternal(Uri u) {
        new Thread(() -> {
            Track t = describe(u);
            h.post(() -> {
                play(Collections.singletonList(t), 0, false);
                openNowPlaying();
            });
        }, "open").start();
    }

    private Track describe(Uri u) {
        Track t = new Track();
        t.uri = u;
        String scheme = u.getScheme();
        if ("file".equals(scheme)) t.path = u.getPath();
        String name = u.getLastPathSegment();
        if ("content".equals(scheme)) {
            try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE},
                    null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String n = c.getString(0);
                    if (n != null) name = n;
                    if (!c.isNull(1)) t.size = c.getLong(1);
                }
            } catch (Exception ignored) {
            }
        }
        t.title = Track.cleanTitle(name != null ? name : "Аудио");
        if (scheme != null && (scheme.equals("content") || scheme.equals("file"))) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                if (t.path != null) r.setDataSource(t.path);
                else r.setDataSource(this, u);
                String title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                if (title != null && !title.trim().isEmpty()) t.title = title.trim();
                t.artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                t.album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                if (d != null) t.duration = Long.parseLong(d);
            } catch (Exception ignored) {
            } finally {
                try {
                    r.release();
                } catch (Exception ignored) {
                }
            }
        } else {
            t.artist = "Поток";
            String real = StreamResolver.resolve(String.valueOf(u));
            if (!real.equals(String.valueOf(u))) t.uri = Uri.parse(real);
        }
        return t;
    }

    // ================================================================== импорт и экспорт M3U

    private void importM3u() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/x-mpegurl", "audio/mpegurl", "application/vnd.apple.mpegurl",
                "application/x-mpegurl", "text/plain", "application/octet-stream"});
        try {
            startActivityForResult(i, REQ_IMPORT);
        } catch (Exception e) {
            toast("Нет приложения для выбора файлов");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (req == REQ_IMPORT) {
            try (InputStream in = getContentResolver().openInputStream(u)) {
                if (in == null) throw new Exception();
                byte[] buf = readAll(in);
                String text = new String(buf, StandardCharsets.UTF_8);
                List<Track> found = Playlists.fromM3u(text);
                String name = u.getLastPathSegment();
                try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (c != null && c.moveToFirst() && c.getString(0) != null) name = c.getString(0);
                } catch (Exception ignored) {
                }
                name = Track.cleanTitle(name != null ? name : "Плейлист");
                Playlists.Playlist p = Playlists.get(this).create(name);
                Playlists.get(this).add(p, found);
                toast("Импортировано: " + Fmt.tracks(found.size()));
                refresh();
            } catch (Exception e) {
                toast("Не удалось прочитать плейлист");
            }
        } else if (req == REQ_EXPORT && exporting != null) {
            try (OutputStream out = getContentResolver().openOutputStream(u)) {
                if (out == null) throw new Exception();
                out.write(Playlists.toM3u(Playlists.tracks(exporting)).getBytes(StandardCharsets.UTF_8));
                toast("Плейлист сохранён");
            } catch (Exception e) {
                toast("Не удалось сохранить");
            }
            exporting = null;
        }
    }

    static byte[] readAll(InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) {
            bo.write(b, 0, n);
            if (bo.size() > 8 * 1024 * 1024) break;
        }
        return bo.toByteArray();
    }

    // ================================================================== адаптер

    private final class RowAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int p) { return items.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public int getViewTypeCount() { return 8; }
        @Override public int getItemViewType(int p) { return items.get(p).type; }
        @Override public boolean isEnabled(int p) { return false; }

        @Override
        public View getView(int p, View v, ViewGroup parent) {
            Item it = items.get(p);
            switch (it.type) {
                case Item.TRACK: return trackRow(it, v);
                case Item.GROUP: return groupRow(it, v);
                case Item.ALBUMS: return albumsRow(it, v);
                case Item.HEADER: return headerRow(it);
                case Item.EMPTY: return emptyRow(it);
                case Item.BUTTONS: return buttonsRow(it);
                case Item.HERO: return heroRow(it);
                default: return labelRow(it, v);
            }
        }
    }

    private View labelRow(Item it, View v) {
        TextView t = v instanceof TextView ? (TextView) v : ui.label("");
        t.setText(it.title);
        t.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(8));
        return t;
    }

    private static final class TrackHolder {
        ImageView art, bars, more;
        TextView num, title, sub, dur;
    }

    private View trackRow(Item it, View v) {
        TrackHolder hd;
        if (v == null || !(v.getTag() instanceof TrackHolder)) {
            hd = new TrackHolder();
            LinearLayout row = ui.row();
            row.setPadding(ui.dp(16), ui.dp(7), ui.dp(4), ui.dp(7));
            row.setBackground(Ui.ripple(null, Ui.round(0xFFFFFFFF, 0)));
            FrameLayout slot = new FrameLayout(this);
            hd.art = new ImageView(this);
            hd.art.setScaleType(ImageView.ScaleType.CENTER_CROP);
            hd.art.setClipToOutline(true);
            hd.art.setOutlineProvider(Ui.rounded(ui.dp(10)));
            slot.addView(hd.art, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            hd.num = ui.text("", 15, Theme.MUTED, true);
            hd.num.setGravity(Gravity.CENTER);
            slot.addView(hd.num, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            hd.bars = new ImageView(this);
            hd.bars.setImageDrawable(new Glyph("bars", Theme.ACCENT));
            hd.bars.setBackground(Ui.round(0xB0000000, ui.dp(10)));
            hd.bars.setPadding(ui.dp(12), ui.dp(12), ui.dp(12), ui.dp(12));
            slot.addView(hd.bars, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            row.addView(slot, Ui.lp(ui.dp(48), ui.dp(48)));
            LinearLayout texts = ui.col();
            hd.title = ui.oneLine("", 15, Theme.TEXT, false);
            hd.sub = ui.oneLine("", 12.5f, Theme.MUTED, false);
            texts.addView(hd.title);
            texts.addView(hd.sub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
            row.addView(texts, Ui.margins(0, Ui.WRAP, ui.dp(14), 0, ui.dp(8), 0));
            ((LinearLayout.LayoutParams) texts.getLayoutParams()).weight = 1f;
            hd.dur = ui.text("", 12, Theme.MUTED, false);
            row.addView(hd.dur);
            hd.more = ui.iconButton("more", Theme.MUTED, 40, 10, null);
            row.addView(hd.more);
            row.setTag(hd);
            v = row;
        } else {
            hd = (TrackHolder) v.getTag();
        }
        Track t = it.track;
        boolean playing = currentKey != null && currentKey.equals(t.key());
        hd.title.setText(t.title);
        hd.title.setTextColor(playing ? Theme.ACCENT : Theme.TEXT);
        hd.title.setTypeface(playing ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
        if (it.number > 0) {
            hd.art.setVisibility(View.GONE);
            hd.num.setVisibility(View.VISIBLE);
            hd.num.setText(String.valueOf(it.number));
            hd.sub.setText(t.artistName());
        } else {
            hd.art.setVisibility(View.VISIBLE);
            hd.num.setVisibility(View.GONE);
            ArtCache.get(this).load(t, hd.art, 160);
            hd.sub.setText(t.isStream() ? String.valueOf(t.uri) : t.artistName() + " · " + t.albumName());
        }
        hd.bars.setVisibility(playing ? View.VISIBLE : View.GONE);
        hd.dur.setText(t.duration > 0 ? Fmt.time(t.duration) : "");
        Screen in = stack.isEmpty() || searching ? null : top();
        v.setOnClickListener(x -> {
            if (playing && svc != null) {
                openNowPlaying();
                return;
            }
            play(it.list, it.pos, false);
        });
        v.setOnLongClickListener(x -> {
            trackMenu(t, in, it.pos);
            return true;
        });
        hd.more.setOnClickListener(x -> trackMenu(t, in, it.pos));
        return v;
    }

    private static final class GroupHolder {
        ImageView art, icon, more;
        TextView title, sub;
    }

    private View groupRow(Item it, View v) {
        GroupHolder hd;
        if (v == null || !(v.getTag() instanceof GroupHolder)) {
            hd = new GroupHolder();
            LinearLayout row = ui.row();
            row.setPadding(ui.dp(16), ui.dp(8), ui.dp(4), ui.dp(8));
            row.setBackground(Ui.ripple(null, Ui.round(0xFFFFFFFF, 0)));
            FrameLayout slot = new FrameLayout(this);
            hd.icon = new ImageView(this);
            hd.icon.setPadding(ui.dp(13), ui.dp(13), ui.dp(13), ui.dp(13));
            slot.addView(hd.icon, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            hd.art = new ImageView(this);
            hd.art.setScaleType(ImageView.ScaleType.CENTER_CROP);
            hd.art.setClipToOutline(true);
            slot.addView(hd.art, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            row.addView(slot, Ui.lp(ui.dp(52), ui.dp(52)));
            LinearLayout texts = ui.col();
            hd.title = ui.oneLine("", 15.5f, Theme.TEXT, true);
            hd.sub = ui.oneLine("", 12.5f, Theme.MUTED, false);
            texts.addView(hd.title);
            texts.addView(hd.sub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
            row.addView(texts, Ui.margins(0, Ui.WRAP, ui.dp(14), 0, ui.dp(8), 0));
            ((LinearLayout.LayoutParams) texts.getLayoutParams()).weight = 1f;
            hd.more = ui.iconButton("more", Theme.MUTED, 40, 10, null);
            row.addView(hd.more);
            row.setTag(hd);
            v = row;
        } else {
            hd = (GroupHolder) v.getTag();
        }
        hd.title.setText(it.title);
        hd.sub.setText(it.sub);
        float r = it.round ? ui.dp(26) : ui.dp(12);
        if (it.track != null) {
            hd.art.setVisibility(View.VISIBLE);
            hd.icon.setVisibility(View.GONE);
            hd.art.setOutlineProvider(Ui.rounded(r));
            hd.art.invalidateOutline();
            ArtCache.get(this).load(it.track, hd.art, 160);
        } else {
            hd.art.setVisibility(View.GONE);
            hd.icon.setVisibility(View.VISIBLE);
            hd.icon.setImageDrawable(new Glyph(it.icon != null ? it.icon : "note", Theme.ACCENT));
            hd.icon.setBackground(Ui.round(Theme.alpha(Theme.ACCENT, 34), r));
        }
        hd.more.setVisibility(it.more != null ? View.VISIBLE : View.GONE);
        hd.more.setOnClickListener(x -> {
            if (it.more != null) it.more.run();
        });
        v.setOnClickListener(x -> {
            if (it.click != null) it.click.run();
        });
        v.setOnLongClickListener(x -> {
            if (it.more == null) return false;
            it.more.run();
            return true;
        });
        return v;
    }

    /** Квадратная картинка: высота равна ширине. */
    static final class SquareImage extends ImageView {
        SquareImage(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, w);
        }
    }

    private View albumsRow(Item it, View v) {
        int cols = it.albums.length;
        LinearLayout row;
        if (v instanceof LinearLayout && ((LinearLayout) v).getChildCount() == cols && "albums".equals(v.getTag())) {
            row = (LinearLayout) v;
        } else {
            row = ui.row();
            row.setTag("albums");
            row.setGravity(Gravity.TOP);
            row.setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4));
            for (int i = 0; i < cols; i++) {
                LinearLayout card = ui.col();
                card.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(8));
                card.setBackground(Ui.ripple(null, Ui.round(0xFFFFFFFF, ui.dp(16))));
                SquareImage art = new SquareImage(this);
                art.setScaleType(ImageView.ScaleType.CENTER_CROP);
                art.setClipToOutline(true);
                art.setOutlineProvider(Ui.rounded(ui.dp(14)));
                card.addView(art, Ui.lp(Ui.MATCH, Ui.WRAP));
                card.addView(ui.oneLine("", 14, Theme.TEXT, true), Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(2), ui.dp(8), 0, 0));
                card.addView(ui.oneLine("", 12, Theme.MUTED, false), Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(2), ui.dp(3), 0, 0));
                row.addView(card, Ui.lp(0, Ui.WRAP, 1f));
            }
        }
        for (int i = 0; i < cols; i++) {
            LinearLayout card = (LinearLayout) row.getChildAt(i);
            Library.Group g = it.albums[i];
            if (g == null) {
                card.setVisibility(View.INVISIBLE);
                card.setOnClickListener(null);
                continue;
            }
            card.setVisibility(View.VISIBLE);
            ArtCache.get(this).load(g.cover(), (ImageView) card.getChildAt(0), 400);
            ((TextView) card.getChildAt(1)).setText(g.name);
            ((TextView) card.getChildAt(2)).setText(g.sub + (g.year > 0 ? " · " + g.year : ""));
            card.setOnClickListener(x -> openGroup(g, Screen.ALBUM));
            card.setOnLongClickListener(x -> {
                groupMenu(g, Screen.ALBUM);
                return true;
            });
        }
        return row;
    }

    private View headerRow(Item it) {
        LinearLayout box = ui.col();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(20), ui.dp(8), ui.dp(20), ui.dp(14));
        int size = Math.min(ui.dp(220), getResources().getDisplayMetrics().widthPixels / 2);
        ImageView art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setClipToOutline(true);
        art.setElevation(ui.dp(12));
        float r = it.round ? size / 2f : ui.dp(20);
        art.setOutlineProvider(Ui.rounded(r));
        if (it.track != null && (it.screen.kind == Screen.ALBUM || it.screen.kind == Screen.ARTIST
                || it.screen.kind == Screen.PLAYLIST)) {
            ArtCache.get(this).load(it.track, art, 512);
        } else {
            art.setImageDrawable(new Glyph(it.icon != null ? it.icon : "note", Theme.ACCENT));
            art.setPadding(size / 4, size / 4, size / 4, size / 4);
            art.setBackground(Ui.round(Theme.alpha(Theme.ACCENT, 34), r));
        }
        box.addView(art, Ui.lp(size, size));
        TextView title = ui.text(it.title, 22, Theme.TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setMaxLines(3);
        box.addView(title, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(18), 0, 0));
        TextView sub = ui.text(it.sub, 13, Theme.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(0, 1.3f);
        box.addView(sub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(8), 0, 0));
        LinearLayout buttons = ui.row();
        buttons.setGravity(Gravity.CENTER);
        TextView playB = ui.button("▶  Слушать", true, v -> play(it.list, 0, false));
        TextView shufB = ui.button("Перемешать", false, v -> {
            if (!it.list.isEmpty()) play(it.list, new Random().nextInt(it.list.size()), true);
        });
        buttons.addView(playB, Ui.lp(0, Ui.WRAP, 1f));
        View gap = new View(this);
        buttons.addView(gap, Ui.lp(ui.dp(10), 1));
        buttons.addView(shufB, Ui.lp(0, Ui.WRAP, 1f));
        if (it.more != null) {
            buttons.addView(new View(this), Ui.lp(ui.dp(6), 1));
            ImageView more = ui.iconButton("more", Theme.TEXT, 48, 12, v -> it.more.run());
            more.setBackground(Ui.ripple(Ui.stroke(Theme.SURFACE, Theme.LINE, ui.dp(1), ui.dp(14)), null));
            buttons.addView(more);
        }
        if (it.list.isEmpty()) buttons.setVisibility(View.GONE);
        box.addView(buttons, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(18), 0, 0));

        // фон шапки — в цвет обложки
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Theme.alpha(Theme.ACCENT, 40), Theme.BG});
        box.setBackground(bg);
        if (it.track != null) {
            final Track cover = it.track;
            new Thread(() -> {
                Bitmap b = ArtCache.get(this).loadSync(cover, 512);
                if (b == null) return;
                int c = Colors.dominant(b, Theme.SURFACE2);
                h.post(() -> box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{Theme.alpha(c, 150), Theme.BG})));
            }, "tint").start();
        }
        return box;
    }

    private View emptyRow(Item it) {
        LinearLayout box = ui.col();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(32), ui.dp(48), ui.dp(32), ui.dp(32));
        ImageView ic = new ImageView(this);
        ic.setImageDrawable(new Glyph(it.icon, Theme.ACCENT));
        ic.setPadding(ui.dp(18), ui.dp(18), ui.dp(18), ui.dp(18));
        ic.setBackground(Ui.oval(Theme.alpha(Theme.ACCENT, 30)));
        box.addView(ic, Ui.lp(ui.dp(76), ui.dp(76)));
        TextView t = ui.text(it.title, 18, Theme.TEXT, true);
        t.setGravity(Gravity.CENTER);
        box.addView(t, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(18), 0, 0));
        if (it.sub != null && !it.sub.isEmpty()) {
            TextView s = ui.text(it.sub, 14, Theme.MUTED, false);
            s.setGravity(Gravity.CENTER);
            s.setLineSpacing(0, 1.3f);
            box.addView(s, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(8), 0, 0));
        }
        if (it.buttons != null) {
            for (int i = 0; i < it.buttons.length; i++) {
                final Runnable r = it.actions[i];
                box.addView(ui.button(it.buttons[i], i == 0, v -> r.run()), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(20), 0, 0));
            }
        }
        return box;
    }

    private View buttonsRow(Item it) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8));
        for (int i = 0; i < it.buttons.length; i++) {
            final Runnable r = it.actions[i];
            if (i > 0) row.addView(new View(this), Ui.lp(ui.dp(10), 1));
            row.addView(ui.button(it.buttons[i], false, v -> r.run()), Ui.lp(0, Ui.WRAP, 1f));
        }
        return row;
    }

    private View heroRow(Item it) {
        LinearLayout card = ui.col();
        card.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(18));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Theme.alpha(Theme.ACCENT, 90), Theme.alpha(Theme.ACCENT2, 60), Theme.SURFACE});
        g.setCornerRadius(ui.dp(24));
        card.setBackground(g);
        card.addView(ui.text(it.title, 22, Theme.TEXT, true));
        TextView sub = ui.text(it.sub, 13.5f, 0xDDF2EEFF, false);
        card.addView(sub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(8), 0, 0));
        int plays = stats.totalPlays();
        if (plays > 0) {
            card.addView(ui.text("Всего " + Fmt.plays(plays), 12, Theme.MUTED, false),
                    Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        }
        LinearLayout row = ui.row();
        for (int i = 0; i < it.buttons.length; i++) {
            final Runnable r = it.actions[i];
            if (i > 0) row.addView(new View(this), Ui.lp(ui.dp(10), 1));
            row.addView(ui.button(it.buttons[i], i == 0, v -> r.run()), Ui.lp(0, Ui.WRAP, 1f));
        }
        card.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(18), 0, 0));
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(ui.dp(16), ui.dp(6), ui.dp(16), ui.dp(4));
        wrap.addView(card, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        return wrap;
    }
}
