package com.neondrift.music;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/** Эквалайзер-кривая: тянете точку пальцем вверх или вниз. */
final class EqView extends View {
    interface Listener {
        void onBand(int band, float db, boolean done);
    }

    static final float MIN = -20f, MAX = 20f;

    private float[] values = new float[10];
    private String[] labels = new String[10];
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bubble = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path curve = new Path(), area = new Path();
    private final float dp;
    private int active = -1;
    private boolean enabled = true;
    private Listener listener;
    private int shaderH = -1;

    EqView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        grid.setColor(0x22FFFFFF);
        grid.setStrokeWidth(1 * dp);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(3 * dp);
        line.setStrokeCap(Paint.Cap.ROUND);
        knob.setColor(0xFFFFFFFF);
        knobRing.setStyle(Paint.Style.STROKE);
        knobRing.setStrokeWidth(2 * dp);
        text.setColor(Theme.MUTED);
        text.setTextSize(10 * dp);
        text.setTextAlign(Paint.Align.CENTER);
        bubble.setColor(Theme.TEXT);
        bubble.setTextSize(12 * dp);
        bubble.setTextAlign(Paint.Align.CENTER);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
    }

    void setBands(float[] v, String[] l) {
        values = v.clone();
        labels = l;
        invalidate();
    }

    void setValues(float[] v) {
        values = v.clone();
        invalidate();
    }

    float[] values() {
        return values.clone();
    }

    void setActive(boolean on) {
        enabled = on;
        shaderH = -1;
        invalidate();
    }

    void setListener(Listener l) {
        listener = l;
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(200 * dp));
    }

    private float xAt(int i) {
        float pad = 18 * dp;
        int n = values.length;
        return n <= 1 ? getWidth() / 2f : pad + (getWidth() - pad * 2) * i / (n - 1f);
    }

    private float top() { return 26 * dp; }

    private float bottom() { return getHeight() - 24 * dp; }

    private float yAt(float db) {
        float f = (db - MIN) / (MAX - MIN);
        return bottom() - (bottom() - top()) * f;
    }

    @Override
    protected void onDraw(Canvas c) {
        int n = values.length;
        if (n == 0) return;
        int a1 = enabled ? Theme.ACCENT : 0xFF6B6385, a2 = enabled ? Theme.ACCENT2 : 0xFF4A4460;
        if (shaderH != getHeight()) {
            shaderH = getHeight();
            line.setShader(new LinearGradient(0, 0, getWidth(), 0, a1, a2, Shader.TileMode.CLAMP));
            fill.setShader(new LinearGradient(0, top(), 0, bottom(), Theme.alpha(a1, 90), Theme.alpha(a2, 0),
                    Shader.TileMode.CLAMP));
            knobRing.setColor(a1);
        }
        // сетка: 0 дБ и ±10 дБ
        for (float db : new float[]{-10f, 0f, 10f}) {
            float y = yAt(db);
            grid.setColor(db == 0f ? 0x40FFFFFF : 0x18FFFFFF);
            c.drawLine(xAt(0), y, xAt(n - 1), y, grid);
        }
        grid.setColor(0x14FFFFFF);
        for (int i = 0; i < n; i++) c.drawLine(xAt(i), top(), xAt(i), bottom(), grid);

        // плавная кривая через точки
        curve.reset();
        curve.moveTo(xAt(0), yAt(values[0]));
        for (int i = 0; i < n - 1; i++) {
            float x0 = xAt(i), y0 = yAt(values[i]), x1 = xAt(i + 1), y1 = yAt(values[i + 1]);
            float mx = (x0 + x1) / 2f;
            curve.cubicTo(mx, y0, mx, y1, x1, y1);
        }
        area.reset();
        area.addPath(curve);
        area.lineTo(xAt(n - 1), bottom());
        area.lineTo(xAt(0), bottom());
        area.close();
        c.drawPath(area, fill);
        c.drawPath(curve, line);

        for (int i = 0; i < n; i++) {
            float x = xAt(i), y = yAt(values[i]);
            float r = (i == active ? 9 : 6) * dp;
            c.drawCircle(x, y, r, knob);
            c.drawCircle(x, y, r + 2 * dp, knobRing);
            if (labels != null && i < labels.length && labels[i] != null) {
                c.drawText(labels[i], x, getHeight() - 6 * dp, text);
            }
        }
        if (active >= 0 && active < n) {
            String s = String.format(Locale.US, "%+.1f дБ", values[active]).replace('.', ',');
            c.drawText(s, Math.max(30 * dp, Math.min(getWidth() - 30 * dp, xAt(active))), 16 * dp, bubble);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int n = values.length;
        if (n == 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                int best = 0;
                float bd = Float.MAX_VALUE;
                for (int i = 0; i < n; i++) {
                    float d = Math.abs(e.getX() - xAt(i));
                    if (d < bd) {
                        bd = d;
                        best = i;
                    }
                }
                active = best;
                move(e.getY(), false);
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (active >= 0) move(e.getY(), false);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (active >= 0) move(e.getY(), true);
                active = -1;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void move(float y, boolean done) {
        float f = (bottom() - y) / Math.max(1f, bottom() - top());
        float db = MIN + (MAX - MIN) * Math.max(0f, Math.min(1f, f));
        db = Math.round(db * 2f) / 2f; // шаг 0,5 дБ
        if (Math.abs(db) < 0.6f) db = 0f; // «прилипание» к нулю
        values[active] = db;
        invalidate();
        if (listener != null) listener.onBand(active, db, done);
    }
}
