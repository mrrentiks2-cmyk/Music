package com.neondrift.music;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/** Спектр звука: неоновые столбики с отражением. Данные — из системного Visualizer. */
final class VisualizerView extends View {
    private static final int BARS = 36;
    private final float[] level = new float[BARS];
    private final float[] peak = new float[BARS];
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mirror = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cap = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float dp;
    private long lastData;
    private int shaderH = -1;

    VisualizerView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        cap.setColor(0xEEFFFFFF);
    }

    /** FFT от Visualizer: пары (re, im) байтами. */
    void setFft(byte[] fft) {
        if (fft == null || fft.length < 8) return;
        int n = fft.length / 2;
        double minF = 1, maxF = n - 1;
        for (int b = 0; b < BARS; b++) {
            // логарифмическая шкала частот: басов больше, как слышит ухо
            int from = (int) Math.floor(minF * Math.pow(maxF / minF, b / (double) BARS));
            int to = (int) Math.ceil(minF * Math.pow(maxF / minF, (b + 1) / (double) BARS));
            from = Math.max(1, Math.min(n - 1, from));
            to = Math.max(from + 1, Math.min(n, to));
            double sum = 0;
            for (int k = from; k < to; k++) {
                double re = fft[2 * k], im = fft[2 * k + 1];
                sum = Math.max(sum, Math.hypot(re, im));
            }
            double db = 20 * Math.log10(Math.max(1e-3, sum));
            float v = (float) Math.max(0, Math.min(1, (db - 6) / 36.0));
            level[b] = Math.max(v, level[b] * 0.78f);
            peak[b] = Math.max(peak[b], level[b]);
        }
        lastData = SystemClock.uptimeMillis();
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (shaderH != getHeight()) {
            shaderH = getHeight();
            bar.setShader(new LinearGradient(0, 0, w, 0, Theme.ACCENT, Theme.ACCENT2, Shader.TileMode.CLAMP));
            mirror.setShader(new LinearGradient(0, 0, w, 0, Theme.alpha(Theme.ACCENT, 60),
                    Theme.alpha(Theme.ACCENT2, 60), Shader.TileMode.CLAMP));
        }
        float base = h * 0.72f;
        float gap = 3 * dp, bw = (w - gap * (BARS - 1)) / BARS;
        boolean stale = SystemClock.uptimeMillis() - lastData > 120;
        boolean moving = false;
        for (int i = 0; i < BARS; i++) {
            if (stale) level[i] *= 0.85f;
            peak[i] = Math.max(level[i], peak[i] - 0.012f);
            if (level[i] > 0.01f || peak[i] > 0.01f) moving = true;
            float x = i * (bw + gap);
            float bh = Math.max(2 * dp, level[i] * base);
            r.set(x, base - bh, x + bw, base);
            c.drawRoundRect(r, bw / 2, bw / 2, bar);
            float mh = bh * 0.35f;
            r.set(x, base + 2 * dp, x + bw, base + 2 * dp + mh);
            c.drawRoundRect(r, bw / 2, bw / 2, mirror);
            float py = base - peak[i] * base - 4 * dp;
            r.set(x, py, x + bw, py + 2 * dp);
            c.drawRect(r, cap);
        }
        if (stale && moving) postInvalidateDelayed(16);
    }
}
