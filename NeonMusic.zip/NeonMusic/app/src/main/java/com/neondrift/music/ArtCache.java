package com.neondrift.music;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;

import java.io.File;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Обложки: из MediaStore, из тегов файла, с кэшем в памяти. Если обложки нет — цветная заглушка. */
final class ArtCache {
    private static ArtCache instance;

    static synchronized ArtCache get(Context c) {
        if (instance == null) instance = new ArtCache(c.getApplicationContext());
        return instance;
    }

    private final Context ctx;
    private final ContentResolver cr;
    private final LruCache<String, Bitmap> cache;
    private final LruCache<String, Boolean> missing = new LruCache<>(2000);
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());

    private ArtCache(Context c) {
        ctx = c;
        cr = c.getContentResolver();
        int kb = (int) Math.min(Runtime.getRuntime().maxMemory() / 1024 / 6, 64 * 1024);
        cache = new LruCache<String, Bitmap>(kb) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };
    }

    /** Асинхронно поставить обложку в ImageView; пока грузится — заглушка. */
    void load(final Track t, final ImageView target, final int size) {
        if (t == null) {
            target.setImageDrawable(new Placeholder("", Theme.ACCENT));
            return;
        }
        final String key = t.albumKey() + "@" + (size > 300 ? "L" : "S");
        target.setTag(key);
        Bitmap b = cache.get(key);
        if (b != null) {
            target.setImageBitmap(b);
            return;
        }
        target.setImageDrawable(new Placeholder(t.albumName(), Theme.ACCENT));
        if (missing.get(key) != null) return;
        pool.execute(() -> {
            Bitmap bmp = fetch(t, size);
            if (bmp == null) {
                missing.put(key, Boolean.TRUE);
                return;
            }
            cache.put(key, bmp);
            main.post(() -> {
                if (key.equals(target.getTag())) target.setImageBitmap(bmp);
            });
        });
    }

    /** Синхронно (только не в главном потоке): для уведомления, виджета и экрана плеера. */
    Bitmap loadSync(Track t, int size) {
        if (t == null) return null;
        String key = t.albumKey() + "@" + (size > 300 ? "L" : "S");
        Bitmap b = cache.get(key);
        if (b != null) return b;
        if (missing.get(key) != null) return null;
        b = fetch(t, size);
        if (b != null) cache.put(key, b);
        else missing.put(key, Boolean.TRUE);
        return b;
    }

    void clearMissing() {
        missing.evictAll();
    }

    @SuppressWarnings("deprecation")
    private Bitmap fetch(Track t, int size) {
        try {
            if (t.id >= 0 && Build.VERSION.SDK_INT >= 29) {
                Bitmap b = cr.loadThumbnail(t.uri, new Size(size, size), null);
                if (b != null) return b;
            }
        } catch (Throwable ignored) {
        }
        if (t.albumId >= 0 && Build.VERSION.SDK_INT < 29) {
            Uri art = Uri.parse("content://media/external/audio/albumart/" + t.albumId);
            try (InputStream in = cr.openInputStream(art)) {
                if (in != null) {
                    Bitmap b = BitmapFactory.decodeStream(in);
                    if (b != null) return scale(b, size);
                }
            } catch (Throwable ignored) {
            }
        }
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            if (t.path != null && new File(t.path).canRead()) r.setDataSource(t.path);
            else if (!t.isStream()) r.setDataSource(ctx, t.uri);
            else return null;
            byte[] pic = r.getEmbeddedPicture();
            if (pic == null) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(pic, 0, pic.length, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= size && o.outHeight / (sample * 2) >= size) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeByteArray(pic, 0, pic.length, o2);
            return b == null ? null : scale(b, size);
        } catch (Throwable e) {
            return null;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
    }

    private static Bitmap scale(Bitmap b, int size) {
        int m = Math.max(b.getWidth(), b.getHeight());
        if (m <= size * 1.3f) return b;
        float s = size / (float) m;
        return Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * s)),
                Math.max(1, Math.round(b.getHeight() * s)), true);
    }

    /** Заглушка обложки: градиент из названия альбома и нота. */
    static final class Placeholder extends Drawable {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Glyph note;
        private final int c1, c2;

        Placeholder(String seed, int accent) {
            int h = seed == null ? 0 : seed.hashCode();
            float[] hsv = {((h & 0x7fffffff) % 360), 0.55f, 0.42f};
            c1 = android.graphics.Color.HSVToColor(hsv);
            hsv[0] = (hsv[0] + 40f) % 360f;
            hsv[2] = 0.2f;
            c2 = android.graphics.Color.HSVToColor(hsv);
            note = new Glyph("note", Theme.mix(c1, 0xFFFFFFFF, 0.55f)); // непрозрачный: без швов на пересечениях
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            bg.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom, c1, c2, Shader.TileMode.CLAMP));
            c.drawRect(b, bg);
            int s = Math.min(b.width(), b.height()) * 2 / 5;
            int x = b.centerX() - s / 2, y = b.centerY() - s / 2;
            note.setBounds(x, y, x + s, y + s);
            note.draw(c);
        }

        @Override public void setAlpha(int alpha) { bg.setAlpha(alpha); }
        @Override public void setColorFilter(ColorFilter cf) { bg.setColorFilter(cf); }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
