package com.neondrift.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;
import org.videolan.libvlc.MediaPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Фоновое воспроизведение: очередь, уведомление, экран блокировки, гарнитура, таймер сна, эффекты. */
public class PlaybackService extends Service implements Engine.Callback {
    static final String ACTION_TOGGLE = "com.neondrift.music.TOGGLE";
    static final String ACTION_NEXT = "com.neondrift.music.NEXT";
    static final String ACTION_PREV = "com.neondrift.music.PREV";
    static final String ACTION_CLOSE = "com.neondrift.music.CLOSE";
    private static final String CHANNEL = "playback";
    private static final int NOTIF_ID = 7;
    private static final long SLEEP_FADE_MS = 20_000;

    interface Listener {
        void onPlaybackChanged();
    }

    final class LocalBinder extends Binder {
        PlaybackService service() {
            return PlaybackService.this;
        }
    }

    private final LocalBinder binder = new LocalBinder();
    private final ArrayList<Listener> listeners = new ArrayList<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Queue queue = new Queue();

    private Engine engine;
    private Effects effects;
    private Prefs prefs;
    private Stats stats;
    private MediaSession session;
    private NotificationManager nm;
    private AudioManager am;
    private AudioFocusRequest focus;
    private BroadcastReceiver noisy, plug;

    private int audioSession;
    private boolean selfStarted, foreground, focusPaused, ducked, counted, pausedByNoisy, restoring;
    private float speed = 1f;
    private MediaPlayer.Equalizer eq;
    private Bitmap art;
    private int artColor = 0xFF2B2442;
    private Track artFor;
    private long sleepAt;
    private boolean sleepAfterTrack;
    private long lastSave;
    private String error;
    private int errorsInRow;
    private boolean wantPlay; // пользователь хочет, чтобы играло (а не просто трек подготовлен)

    private final Runnable sleepTick = new Runnable() {
        @Override
        public void run() {
            if (sleepAt <= 0) return;
            long left = sleepAt - SystemClock.elapsedRealtime();
            if (left <= 0) {
                sleepAt = 0;
                pause();
                engine.setVolume(ducked ? 30 : 100);
                notifyListeners();
                return;
            }
            if (left < SLEEP_FADE_MS && engine.isPlaying()) {
                engine.setVolume(Math.round(100f * left / SLEEP_FADE_MS));
            }
            h.postDelayed(this, 500);
        }
    };

    // ================================================================== жизненный цикл

    @Override
    public void onCreate() {
        super.onCreate();
        Theme.load(this);
        prefs = new Prefs(this);
        stats = new Stats(this);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Воспроизведение", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);

        audioSession = am.generateAudioSessionId();
        speed = prefs.speed();
        createEngine();
        effects = new Effects(this, audioSession);
        effects.apply(prefs);
        setupSession();
        setupFocus();
        setupReceivers();
        restoreState();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (!engine.isPlaying() && !selfStarted) stopSelf();
        return true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        selfStarted = true;
        String a = intent != null ? intent.getAction() : null;
        if (a != null) {
            startForegroundNow();
            switch (a) {
                case ACTION_TOGGLE: playPause(); break;
                case ACTION_NEXT: next(); break;
                case ACTION_PREV: prev(); break;
                case ACTION_CLOSE:
                    pause();
                    stopForeground(STOP_FOREGROUND_REMOVE);
                    foreground = false;
                    nm.cancel(NOTIF_ID);
                    selfStarted = false;
                    stopSelf();
                    return START_NOT_STICKY;
                default: break;
            }
            if (!engine.isPlaying()) h.postDelayed(this::dropForegroundIfPaused, 1500);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (!engine.isPlaying()) {
            saveState();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        saveState();
        h.removeCallbacksAndMessages(null);
        engine.release();
        effects.release();
        session.release();
        try {
            unregisterReceiver(noisy);
            unregisterReceiver(plug);
        } catch (Exception ignored) {
        }
        am.abandonAudioFocusRequest(focus);
        super.onDestroy();
    }

    // ================================================================== движок

    private ArrayList<String> options() {
        ArrayList<String> o = new ArrayList<>();
        o.add(prefs.keepPitch() ? "--audio-time-stretch" : "--no-audio-time-stretch");
        o.add("--audiotrack-session-id=" + audioSession);
        int rg = prefs.replayGain();
        o.add("--audio-replay-gain-mode=" + (rg == 1 ? "track" : rg == 2 ? "album" : "none"));
        if (rg > 0) o.add("--audio-replay-gain-preamp=0.0");
        return o;
    }

    private void createEngine() {
        engine = new Engine(this, this, options());
        engine.setRate(speed);
        applyEq();
    }

    /** Пересоздать движок после смены ReplayGain или тона — с того же места. */
    void rebuildEngine() {
        Track t = queue.current();
        long pos = engine.time();
        boolean playing = engine.isPlaying();
        engine.release();
        createEngine();
        if (t != null) engine.load(t, pos, playing);
        notifyListeners();
    }

    void applyEq() {
        if (!prefs.eqOn()) {
            eq = null;
            engine.setEqualizer(null);
            return;
        }
        eq = buildEq(prefs.eqPreset(), prefs.eqBands());
        engine.setEqualizer(eq);
    }

    static MediaPlayer.Equalizer buildEq(int preset, String bands) {
        if (preset >= 0 && preset < MediaPlayer.Equalizer.getPresetCount()) {
            return MediaPlayer.Equalizer.createFromPreset(preset);
        }
        MediaPlayer.Equalizer e = MediaPlayer.Equalizer.create();
        String[] parts = bands.split(",");
        int n = MediaPlayer.Equalizer.getBandCount();
        if (parts.length >= n + 1) {
            try {
                e.setPreAmp(Float.parseFloat(parts[0]));
                for (int i = 0; i < n; i++) e.setAmp(i, Float.parseFloat(parts[i + 1]));
            } catch (NumberFormatException ignored) {
            }
        }
        return e;
    }

    MediaPlayer.Equalizer equalizer() {
        return eq;
    }

    /** Применить живое изменение полос без пересоздания. */
    void setEqualizerLive(MediaPlayer.Equalizer e) {
        eq = e;
        engine.setEqualizer(e);
    }

    Effects effects() {
        return effects;
    }

    int audioSession() {
        return audioSession;
    }

    // ================================================================== события движка

    @Override
    public void onStateChanged() {
        boolean playing = engine.isPlaying();
        if (playing) {
            engine.setRate(speed);
            error = null;
            errorsInRow = 0;
            startForegroundNow();
        } else {
            saveState();
            dropForegroundIfPaused();
        }
        updateSession();
        updateNotification();
        WidgetProvider.update(this, queue.current(), playing, art);
        notifyListeners();
    }

    @Override
    public void onTime(long t) {
        Track cur = queue.current();
        if (cur == null) return;
        long len = engine.length();
        if (!counted && (t > 30_000 || (len > 0 && t > len / 2))) {
            counted = true;
            stats.count(cur);
        }
        long now = SystemClock.uptimeMillis();
        if (now - lastSave > 5000) {
            lastSave = now;
            savePosition();
            if (prefs.rememberLong() && cur.duration > 20 * 60_000) prefs.saveLongPosition(cur.key(), t, len);
            updateSession();
        }
        int cf = prefs.crossfade() * 1000;
        if (cf > 0 && !engine.isFading() && !sleepAfterTrack && len > cf * 2L + 5000 && t >= len - cf
                && queue.repeat != Queue.REPEAT_ONE) {
            int ni = queue.peekNext(false);
            if (ni >= 0 && ni != queue.index) {
                queue.jump(ni);
                counted = false;
                engine.crossfadeTo(queue.current(), cf);
                onTrackChanged();
            }
        }
    }

    @Override
    public void onLength(long length) {
        updateSession();
        notifyListeners();
    }

    @Override
    public void onTrackEnded() {
        Track cur = queue.current();
        if (cur != null && prefs.rememberLong()) prefs.saveLongPosition(cur.key(), 0, cur.duration);
        if (sleepAfterTrack) {
            sleepAfterTrack = false;
            int ni = queue.peekNext(false);
            if (ni >= 0) queue.jump(ni);
            loadCurrent(0, false);
            return;
        }
        int ni = queue.peekNext(false);
        if (ni < 0) {
            // очередь закончилась: встаём на первый трек и ждём
            queue.jump(0);
            loadCurrent(0, false);
            return;
        }
        queue.jump(ni);
        loadCurrent(0, true);
    }

    @Override
    public void onError() {
        Track cur = queue.current();
        error = cur != null ? "Не удалось воспроизвести «" + cur.title + "»" : "Ошибка воспроизведения";
        notifyListeners();
        // пропускаем битый файл, но не зацикливаемся на очереди из одних битых
        errorsInRow++;
        int ni = queue.peekNext(true);
        if (wantPlay && ni >= 0 && ni != queue.index && queue.size() > 1 && errorsInRow < Math.min(queue.size(), 12)) {
            h.postDelayed(() -> {
                queue.jump(ni);
                loadCurrent(0, true);
            }, 600);
        }
    }

    String lastError() {
        return error;
    }

    // ================================================================== управление

    Queue queue() {
        return queue;
    }

    Track current() {
        return queue.current();
    }

    boolean isPlaying() {
        return engine.isPlaying();
    }

    long position() {
        return engine.time();
    }

    long duration() {
        long l = engine.length();
        Track t = queue.current();
        return l > 0 ? l : (t != null ? t.duration : 0);
    }

    float speed() {
        return speed;
    }

    Bitmap art() {
        return art;
    }

    int artColor() {
        return artColor;
    }

    void playList(List<Track> list, int index, boolean shuffle) {
        if (list.isEmpty()) return;
        queue.set(new ArrayList<>(list), index, shuffle);
        loadCurrent(-1, true);
    }

    void playPause() {
        if (engine.isPlaying()) pause();
        else play();
    }

    void play() {
        Track t = queue.current();
        if (t == null) return;
        wantPlay = true;
        requestFocus();
        ensureStarted();
        if (!engine.hasMedia()) {
            loadCurrent(getSharedPreferences("state", MODE_PRIVATE).getLong("pos", -1), true);
            return;
        }
        engine.setVolume(ducked ? 30 : 100);
        engine.play();
    }

    void pause() {
        wantPlay = false;
        engine.pause();
        savePosition();
    }

    void next() {
        int ni = queue.peekNext(true);
        if (ni < 0) return;
        queue.jump(ni);
        loadCurrent(-1, true);
    }

    void prev() {
        if (engine.time() > 3000) {
            seek(0);
            return;
        }
        int pi = queue.peekPrev();
        if (pi < 0) return;
        queue.jump(pi);
        loadCurrent(-1, true);
    }

    void seek(long ms) {
        if (!engine.hasMedia()) {
            loadCurrent(ms, false);
            return;
        }
        engine.seek(ms);
        updateSession();
        notifyListeners();
    }

    void jump(int i) {
        queue.jump(i);
        loadCurrent(-1, true);
    }

    void setShuffle(boolean on) {
        queue.setShuffle(on);
        saveState();
        notifyListeners();
    }

    void cycleRepeat() {
        queue.cycleRepeat();
        saveState();
        notifyListeners();
    }

    void playNext(Track t) {
        boolean empty = queue.isEmpty();
        queue.playNext(t);
        if (empty) loadCurrent(0, true);
        saveState();
        notifyListeners();
    }

    void addToQueue(List<Track> list) {
        boolean empty = queue.isEmpty();
        queue.addAll(list);
        if (empty) loadCurrent(0, true);
        saveState();
        notifyListeners();
    }

    void removeFromQueue(int i) {
        boolean wasCurrent = i == queue.index;
        boolean playing = engine.isPlaying();
        queue.remove(i);
        if (wasCurrent) {
            if (queue.current() != null) loadCurrent(0, playing);
            else engine.stop();
        }
        saveState();
        notifyListeners();
    }

    void moveInQueue(int from, int to) {
        queue.move(from, to);
        saveState();
        notifyListeners();
    }

    void clearQueue() {
        queue.clearOthers();
        saveState();
        notifyListeners();
    }

    void setSpeed(float s) {
        speed = Math.max(0.25f, Math.min(3f, s));
        engine.setRate(speed);
        prefs.put("speed", speed);
        updateSession();
        notifyListeners();
    }

    void setSleep(int minutes) {
        h.removeCallbacks(sleepTick);
        engine.setVolume(ducked ? 30 : 100);
        sleepAfterTrack = false;
        if (minutes <= 0) {
            sleepAt = 0;
        } else {
            sleepAt = SystemClock.elapsedRealtime() + minutes * 60_000L;
            h.post(sleepTick);
        }
        notifyListeners();
    }

    void setSleepAfterTrack() {
        setSleep(0);
        sleepAfterTrack = true;
        notifyListeners();
    }

    long sleepRemaining() {
        return sleepAt > 0 ? Math.max(0, sleepAt - SystemClock.elapsedRealtime()) : 0;
    }

    boolean sleepAfterTrack() {
        return sleepAfterTrack;
    }

    private void loadCurrent(long start, boolean play) {
        Track t = queue.current();
        if (t == null) {
            engine.stop();
            notifyListeners();
            return;
        }
        counted = false;
        wantPlay = play;
        long s = start;
        if (s < 0) {
            s = 0;
            if (prefs.rememberLong() && t.duration > 20 * 60_000) s = prefs.longPosition(t.key());
        }
        if (play) {
            requestFocus();
            ensureStarted();
        }
        engine.setVolume(ducked ? 30 : 100);
        engine.load(t, s, play);
        onTrackChanged();
    }

    private void onTrackChanged() {
        saveState();
        updateSession();
        updateNotification();
        notifyListeners();
        final Track t = queue.current();
        if (t == null || t == artFor) return;
        artFor = t;
        new Thread(() -> {
            Bitmap b = ArtCache.get(this).loadSync(t, 512);
            int color = Colors.dominant(b, 0xFF2B2442);
            h.post(() -> {
                if (t != queue.current()) return;
                art = b;
                artColor = color;
                updateSession();
                updateNotification();
                WidgetProvider.update(this, t, engine.isPlaying(), b);
                notifyListeners();
            });
        }, "art").start();
        art = null;
        WidgetProvider.update(this, t, engine.isPlaying(), null);
    }

    private void ensureStarted() {
        if (!selfStarted) {
            try {
                startService(new Intent(this, PlaybackService.class));
                selfStarted = true;
            } catch (Exception ignored) {
            }
        }
    }

    // ================================================================== слушатели интерфейса

    void addListener(Listener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    void removeListener(Listener l) {
        listeners.remove(l);
    }

    private void notifyListeners() {
        for (Listener l : new ArrayList<>(listeners)) l.onPlaybackChanged();
    }

    // ================================================================== уведомление и сессия

    private void setupSession() {
        session = new MediaSession(this, "NeonMusic");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { play(); }
            @Override public void onPause() { pause(); }
            @Override public void onStop() { pause(); }
            @Override public void onSkipToNext() { next(); }
            @Override public void onSkipToPrevious() { prev(); }
            @Override public void onSeekTo(long pos) { seek(pos); }
            @Override public void onFastForward() { seek(engine.time() + 15_000); }
            @Override public void onRewind() { seek(Math.max(0, engine.time() - 15_000)); }
        });
        session.setSessionActivity(PendingIntent.getActivity(this, 1, new Intent(this, NowPlayingActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        session.setActive(true);
    }

    private void updateSession() {
        boolean playing = engine.isPlaying();
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                        | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                        | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP
                        | PlaybackState.ACTION_FAST_FORWARD | PlaybackState.ACTION_REWIND)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        engine.time(), playing ? speed : 0f)
                .build());
        Track t = queue.current();
        if (t == null) return;
        MediaMetadata.Builder m = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artistName())
                .putString(MediaMetadata.METADATA_KEY_ALBUM, t.albumName())
                .putLong(MediaMetadata.METADATA_KEY_DURATION, duration());
        if (art != null) m.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
        session.setMetadata(m.build());
    }

    private PendingIntent pending(String action) {
        Intent i = new Intent(this, PlaybackService.class).setAction(action);
        return PendingIntent.getForegroundService(this, action.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification.Action action(int icon, String title, String act) {
        return new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, icon),
                title, pending(act)).build();
    }

    private Notification buildNotification() {
        Track t = queue.current();
        boolean playing = engine.isPlaying();
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_note)
                .setContentTitle(t != null ? t.title : "Neon Music Player")
                .setContentText(t != null ? t.artistName() : "")
                .setSubText(t != null ? t.albumName() : null)
                .setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, NowPlayingActivity.class),
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(playing)
                .setColor(artColor)
                .addAction(action(R.drawable.ic_n_prev, "Назад", ACTION_PREV))
                .addAction(action(playing ? R.drawable.ic_n_pause : R.drawable.ic_n_play,
                        playing ? "Пауза" : "Играть", ACTION_TOGGLE))
                .addAction(action(R.drawable.ic_n_next, "Вперёд", ACTION_NEXT))
                .addAction(action(R.drawable.ic_n_close, "Закрыть", ACTION_CLOSE))
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2));
        if (art != null) b.setLargeIcon(art);
        return b.build();
    }

    private void startForegroundNow() {
        Notification n = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
            foreground = true;
        } catch (Exception e) {
            nm.notify(NOTIF_ID, n);
        }
    }

    private void dropForegroundIfPaused() {
        if (engine.isPlaying() || !foreground) return;
        if (queue.current() == null) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            foreground = false;
            return;
        }
        stopForeground(STOP_FOREGROUND_DETACH);
        foreground = false;
        nm.notify(NOTIF_ID, buildNotification());
    }

    private void updateNotification() {
        if (queue.current() == null) return;
        if (foreground || engine.isPlaying()) nm.notify(NOTIF_ID, buildNotification());
    }

    // ================================================================== аудиофокус и гарнитура

    private void setupFocus() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(this::onFocusChange)
                .setWillPauseWhenDucked(false)
                .build();
    }

    private void requestFocus() {
        am.requestAudioFocus(focus);
    }

    private void onFocusChange(int change) {
        switch (change) {
            case AudioManager.AUDIOFOCUS_LOSS:
                focusPaused = false;
                pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                if (engine.isPlaying()) {
                    focusPaused = true;
                    pause();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                ducked = true;
                engine.setVolume(30);
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                ducked = false;
                engine.setVolume(100);
                if (focusPaused) {
                    focusPaused = false;
                    play();
                }
                break;
            default:
                break;
        }
    }

    private void setupReceivers() {
        noisy = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                if (engine.isPlaying()) {
                    pause();
                    pausedByNoisy = true;
                }
            }
        };
        registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        plug = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                if (isInitialStickyBroadcast()) return;
                boolean connected = i.getIntExtra("state", 0) == 1;
                if (connected && pausedByNoisy && prefs.resumeOnPlug()) {
                    pausedByNoisy = false;
                    play();
                }
            }
        };
        registerReceiver(plug, new IntentFilter(AudioManager.ACTION_HEADSET_PLUG));
    }

    // ================================================================== сохранение очереди

    private static JSONObject toJson(Track t) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", t.id);
        o.put("u", String.valueOf(t.uri));
        if (t.path != null) o.put("p", t.path);
        o.put("t", t.title);
        if (t.artist != null) o.put("a", t.artist);
        if (t.album != null) o.put("al", t.album);
        o.put("ai", t.albumId);
        o.put("d", t.duration);
        return o;
    }

    private static Track fromJson(JSONObject o) {
        Track t = new Track();
        t.id = o.optLong("id", -1);
        t.uri = Uri.parse(o.optString("u"));
        t.path = o.has("p") ? o.optString("p") : null;
        t.title = o.optString("t", "");
        t.artist = o.has("a") ? o.optString("a") : null;
        t.album = o.has("al") ? o.optString("al") : null;
        t.albumId = o.optLong("ai", -1);
        t.duration = o.optLong("d", 0);
        return t;
    }

    private void saveState() {
        if (restoring) return;
        try {
            JSONArray items = new JSONArray();
            int n = Math.min(queue.size(), 3000);
            int start = Math.max(0, Math.min(queue.index - n / 2, queue.size() - n));
            for (int i = start; i < start + n; i++) items.put(toJson(queue.items.get(i)));
            JSONArray orig = new JSONArray();
            for (Track t : queue.originalOrder()) {
                if (orig.length() >= 3000) break;
                orig.put(t.key());
            }
            Track cur = queue.current();
            getSharedPreferences("state", MODE_PRIVATE).edit()
                    .putString("queue", items.toString())
                    .putString("orig", orig.toString())
                    .putInt("index", queue.index - start)
                    .putBoolean("shuffle", queue.shuffle)
                    .putInt("repeat", queue.repeat)
                    .putLong("pos", engine.time())
                    .putString("lastTitle", cur != null ? cur.title : null)
                    .putString("lastArtist", cur != null ? cur.artistName() : null)
                    .apply();
        } catch (Exception ignored) {
        }
    }

    private void savePosition() {
        getSharedPreferences("state", MODE_PRIVATE).edit().putLong("pos", engine.time()).apply();
    }

    private void restoreState() {
        SharedPreferences sp = getSharedPreferences("state", MODE_PRIVATE);
        String q = sp.getString("queue", null);
        if (q == null) return;
        restoring = true;
        try {
            JSONArray items = new JSONArray(q);
            ArrayList<Track> list = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) list.add(fromJson(items.getJSONObject(i)));
            java.util.HashMap<String, Track> byKey = new java.util.HashMap<>();
            for (Track t : list) byKey.put(t.key(), t);
            ArrayList<Track> orig = new ArrayList<>();
            JSONArray oa = new JSONArray(sp.getString("orig", "[]"));
            for (int i = 0; i < oa.length(); i++) {
                Track t = byKey.get(oa.getString(i));
                if (t != null && !orig.contains(t)) orig.add(t);
            }
            queue.restore(list, orig, sp.getInt("index", 0), sp.getBoolean("shuffle", false), sp.getInt("repeat", 0));
        } catch (Exception ignored) {
        }
        restoring = false;
        Track t = queue.current();
        if (t != null) {
            artFor = null;
            // готовим трек на паузе с того же места — «Играть» продолжит, а не начнёт сначала
            engine.load(t, Math.max(0, sp.getLong("pos", 0)), false);
            onTrackChanged();
        }
    }

    static String sleepText(long ms) {
        long m = ms / 60_000, s = (ms / 1000) % 60;
        return String.format(Locale.US, "%d:%02d", m, s);
    }
}
